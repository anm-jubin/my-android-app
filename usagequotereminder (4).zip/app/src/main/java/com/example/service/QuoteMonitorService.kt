package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.NagMode
import com.example.model.Profile
import com.example.storage.StorageManager
import java.util.Random

class QuoteMonitorService : Service() {

    companion object {
        const val ACTION_START = "com.example.service.START"
        const val ACTION_STOP = "com.example.service.STOP"
        const val ACTION_REFRESH = "com.example.service.REFRESH"
        const val ACTION_STOP_ALARM = "com.example.service.STOP_ALARM"

        private const val NOTIFICATION_ID_FOREGROUND = 1001
        private const val NOTIFICATION_ID_QUOTE = 1002

        private const val CHANNEL_ID_FOREGROUND = "quote_monitor_fg_channel_v2"
        private const val CHANNEL_ID_QUOTE = "quote_monitor_quote_channel_v2"
        private const val CHANNEL_ID_ALARM = "quote_monitor_alarm_channel"

        private const val CHECK_INTERVAL = 15000L // 15 seconds
        
        var isServiceRunning = false
            private set
    }

    private var backgroundThread: android.os.HandlerThread? = null
    private var backgroundHandler: Handler? = null
    private val random = Random()

    // State Maps
    private val appToProfileMap = HashMap<String, Profile>()
    private val appStartTimers = HashMap<String, Long>()
    private val appCooldownEndTimes = HashMap<String, Long>()
    private val appNotificationScheduled = HashMap<String, Boolean>()
    
    // Time Period State Maps
    private val timePeriodProfiles = ArrayList<Profile>()
    private val timePeriodTargetTimes = HashMap<String, Long>()
    private val timePeriodLastDayFired = HashMap<String, Int>()

    private val activeAlarms = HashMap<Int, MediaPlayer>()

    private val checkRunnable = object : Runnable {
        override fun run() {
            if (!isServiceRunning) return
            try {
                performAppCheck()
                performTimePeriodCheck()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            backgroundHandler?.postDelayed(this, CHECK_INTERVAL)
        }
    }

    override fun onCreate() {
        super.onCreate()
        backgroundThread = android.os.HandlerThread("QuoteMonitorThread").apply { start() }
        backgroundHandler = Handler(backgroundThread!!.looper)
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_START -> {
                isServiceRunning = true
                refreshMappings()
                startStealthForeground()
                
                // Start the check loop
                backgroundHandler?.removeCallbacks(checkRunnable)
                backgroundHandler?.post(checkRunnable)
            }
            ACTION_REFRESH -> {
                refreshMappings()
            }
            ACTION_STOP_ALARM -> {
                val alarmId = intent?.getIntExtra("alarm_id", -1) ?: -1
                activeAlarms.remove(alarmId)?.let {
                    if (it.isPlaying) it.stop()
                    it.release()
                }
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(alarmId)
            }
            ACTION_STOP -> {
                stopServiceInternal()
            }
        }

        return START_STICKY
    }

    private fun stopServiceInternal() {
        isServiceRunning = false
        backgroundHandler?.removeCallbacksAndMessages(null)
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        isServiceRunning = false
        backgroundHandler?.removeCallbacksAndMessages(null)
        backgroundThread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun refreshMappings() {
        appToProfileMap.clear()
        timePeriodProfiles.clear()
        val profiles = StorageManager.getAllProfiles(this)
        for (profile in profiles) {
            if (profile.isEnabled) {
                if (profile.triggerType == com.example.model.TriggerType.APP_USAGE) {
                    for (app in profile.monitoredApps) {
                        appToProfileMap[app] = profile
                    }
                } else if (profile.triggerType == com.example.model.TriggerType.TIME_PERIOD) {
                    timePeriodProfiles.add(profile)
                }
            }
        }
    }

    private fun startStealthForeground() {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID_FOREGROUND)
            .setContentTitle("")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_notification_clear_all) // Minimalist/stealth icon
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setSilent(true)

        val notification = builder.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
            try {
                startForeground(NOTIFICATION_ID_FOREGROUND, notification, type)
            } catch (e: Exception) {
                // Fallback if specialUse is restricted or fails
                startForeground(NOTIFICATION_ID_FOREGROUND, notification)
            }
        } else {
            startForeground(NOTIFICATION_ID_FOREGROUND, notification)
        }
    }

    private val appLastSeenActive = HashMap<String, Long>()

    private fun performAppCheck() {
        val currentApp = getForegroundApp()
        val nowForCheck = System.currentTimeMillis()
        
        if (currentApp != null) {
            appLastSeenActive[currentApp] = nowForCheck
        }
        if (currentApp != null && appToProfileMap.containsKey(currentApp)) {
            val profile = appToProfileMap[currentApp]!!
            
            // Check cooldown
            val cooldownEnd = appCooldownEndTimes[currentApp] ?: 0L
            val now = System.currentTimeMillis()
            
            if (now >= cooldownEnd) {
                // Store/retrieve the app's open time
                if (!appStartTimers.containsKey(currentApp)) {
                    appStartTimers[currentApp] = now
                }
                
                val firstOpenTime = appStartTimers[currentApp]!!
                val timeOpenMs = now - firstOpenTime
                val initialDelayMs = profile.initialDelayMinutes * 60L * 1000L
                
                val isScheduled = appNotificationScheduled[currentApp] ?: false
                
                if (timeOpenMs >= initialDelayMs && !isScheduled) {
                    // Calculate random delay
                    val min = profile.rangeStartMinutes
                    val max = profile.rangeEndMinutes
                    
                    val randomMin = if (max > min) {
                        min + random.nextInt(max - min + 1)
                    } else {
                        min
                    }
                    val randomDelayMs = randomMin * 60L * 1000L
                    
                    appNotificationScheduled[currentApp] = true
                    
                    val capturedApp = currentApp // Thread-safety / logical closure capture
                    
                    backgroundHandler?.postDelayed({
                        // Only fire if user is still in the app (cleanup step hasn't removed it)
                        if (appStartTimers.containsKey(capturedApp)) {
                            fireQuoteNotification(profile)
                            
                            // Check profile nagMode
                            val updatedNow = System.currentTimeMillis()
                            if (profile.nagMode == NagMode.CONSTANT) {
                                // Reset scheduled to allow next delayed run
                                appNotificationScheduled[capturedApp] = false
                                appStartTimers[capturedApp] = updatedNow // Reset time so it has to wait initial delay again
                            } else {
                                // Cooldown mode
                                val cooldownEndMs = updatedNow + (profile.cooldownMinutes * 60L * 1000L)
                                appCooldownEndTimes[capturedApp] = cooldownEndMs
                                appNotificationScheduled[capturedApp] = false
                            }
                        } else {
                            // User left the app during the delay
                            appNotificationScheduled.remove(capturedApp)
                        }
                    }, randomDelayMs)
                }
            }
        }

        // Cleanup Step (Every 3 seconds):
        // Only remove if an app hasn't been seen for 10 seconds (avoids drops on brief UI pauses)
        val appsInTimer = appStartTimers.keys.toList()
        for (app in appsInTimer) {
            val lastSeen = appLastSeenActive[app] ?: 0L
            if (nowForCheck - lastSeen > 10000L) {
                appStartTimers.remove(app)
                appNotificationScheduled.remove(app)
                appCooldownEndTimes.remove(app)
                appLastSeenActive.remove(app)
            }
        }
    }

    private fun performTimePeriodCheck() {
        val calendar = java.util.Calendar.getInstance()
        val currentDay = calendar.get(java.util.Calendar.DAY_OF_YEAR)
        val now = System.currentTimeMillis()
        
        for (profile in timePeriodProfiles) {
            val lastDay = timePeriodLastDayFired[profile.id] ?: -1
            if (lastDay == currentDay) continue
            
            // Calculate today's time period
            val c = java.util.Calendar.getInstance()
            c.set(java.util.Calendar.HOUR_OF_DAY, profile.timePeriodStartTime / 60)
            c.set(java.util.Calendar.MINUTE, profile.timePeriodStartTime % 60)
            c.set(java.util.Calendar.SECOND, 0)
            val startMs = c.timeInMillis
            
            c.set(java.util.Calendar.HOUR_OF_DAY, profile.timePeriodEndTime / 60)
            c.set(java.util.Calendar.MINUTE, profile.timePeriodEndTime % 60)
            val endMs = c.timeInMillis
            
            if (endMs <= startMs) {
                // Invalid period handling: skip or assume it's next day? We'll just skip for simplicity
                continue 
            }
            
            var targetMs = timePeriodTargetTimes[profile.id]
            if (targetMs == null || targetMs < startMs || targetMs > endMs) {
                // Generate a random time between startMs and endMs
                val diff = endMs - startMs
                if (diff > 0) {
                    val randomOffset = (Math.random() * diff).toLong()
                    targetMs = startMs + randomOffset
                    timePeriodTargetTimes[profile.id] = targetMs
                }
            }
            
            if (targetMs != null && now >= targetMs && now <= endMs + 90_000) {
                // It's time!
                fireQuoteNotification(profile)
                timePeriodLastDayFired[profile.id] = currentDay
            } else if (targetMs != null && now > endMs + 90_000) {
                // We missed it today (e.g., phone was off), mark it as fired for today
                timePeriodLastDayFired[profile.id] = currentDay
            }
        }
    }

    private var lastFireTime = 0L

    private fun fireQuoteNotification(profile: Profile) {
        val now = System.currentTimeMillis()
        if (now - lastFireTime < 2000L) {
            return // Debounce to prevent double notifications
        }
        lastFireTime = now

        if (profile.quotes.isEmpty()) return
        
        // Pick a random quote
        val randomQuote = profile.quotes[random.nextInt(profile.quotes.size)]
        
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        // Use a unique notification ID instead of replacing the old one
        val notificationId = NOTIFICATION_ID_QUOTE + random.nextInt(100000)
        
        var disguiseIcon: androidx.core.graphics.drawable.IconCompat? = null
        
        // Try to disguise notification
        if (profile.disguiseApps.isNotEmpty()) {
            val pm = packageManager
            val pkgToDisguise = if (profile.randomizeDisguise) {
                profile.disguiseApps[random.nextInt(profile.disguiseApps.size)]
            } else {
                profile.disguiseApps[0]
            }

            try {
                val appInfo = pm.getApplicationInfo(pkgToDisguise, 0)
                
                // Fallback to bitmap
                val iconDrawable = pm.getApplicationIcon(appInfo)
                if (iconDrawable != null) {
                    val width = if (iconDrawable.intrinsicWidth > 0) iconDrawable.intrinsicWidth else 192
                    val height = if (iconDrawable.intrinsicHeight > 0) iconDrawable.intrinsicHeight else 192
                    val bitmap = android.graphics.Bitmap.createBitmap(
                        width,
                        height,
                        android.graphics.Bitmap.Config.ARGB_8888
                    )
                    val canvas = android.graphics.Canvas(bitmap)
                    iconDrawable.setBounds(0, 0, canvas.width, canvas.height)
                    iconDrawable.draw(canvas)
                    disguiseIcon = androidx.core.graphics.drawable.IconCompat.createWithBitmap(bitmap)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID_QUOTE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setAutoCancel(true)

        builder.setContentText(randomQuote)
        builder.setStyle(NotificationCompat.BigTextStyle().bigText(randomQuote))
        builder.setSmallIcon(android.R.drawable.ic_dialog_alert)
        
        if (disguiseIcon != null) {
            // disguiseIcon is IconCompat, we need to extract bitmap if we want to use setLargeIcon
            // or just use it if setLargeIcon takes IconCompat (it does in newer Android, but setLargeIcon(Bitmap) is safer)
            builder.setLargeIcon(disguiseIcon.toIcon(this))
        }

        notificationManager.notify(notificationId, builder.build())
        
        // Handle custom/random sound
        try {
            val uriToPlay: Uri? = if (profile.randomizeSound && profile.selectedSoundUris.isNotEmpty()) {
                val idx = random.nextInt(profile.selectedSoundUris.size)
                Uri.parse(profile.selectedSoundUris[idx])
            } else if (!profile.randomizeSound && profile.selectedSoundUris.isNotEmpty()) {
                Uri.parse(profile.selectedSoundUris[0])
            } else if (profile.soundUri != null) {
                Uri.parse(profile.soundUri)
            } else {
                android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            }
            
            if (uriToPlay != null) {
                val player = MediaPlayer().apply {
                    setDataSource(this@QuoteMonitorService, uriToPlay)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_DELAYED)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build())
                    } else {
                        @Suppress("DEPRECATION")
                        setAudioStreamType(android.media.AudioManager.STREAM_NOTIFICATION)
                    }
                    prepare()
                    start()
                }
                player.setOnCompletionListener { it.release() }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // Handle custom/random vibration
        try {
            var vType = profile.vibrationType
            if (profile.randomizeVibration) {
                vType = random.nextInt(4) // 0, 1, 2, or 3
            }
            
            if (vType != 3) {
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vibrator != null && vibrator.hasVibrator()) {
                    val pattern = when (vType) {
                        0 -> longArrayOf(0, 300) // Single
                        1 -> longArrayOf(0, 150, 150, 150) // Double
                        2 -> longArrayOf(0, 500, 200, 500) // Heavy
                        else -> longArrayOf(0, 300)
                    }
                    
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(pattern, -1)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // end fireQuoteNotification

    private var lastForegroundApp: String? = null
    private var lastCheckedTime: Long = System.currentTimeMillis() - 1000 * 60 // initially query last 1 min

    private fun getForegroundApp(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return lastForegroundApp
        val endTime = System.currentTimeMillis()
        val startTime = lastCheckedTime
        
        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        val event = android.app.usage.UsageEvents.Event()
        
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                 lastForegroundApp = event.packageName
            } else if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED) {
                 if (lastForegroundApp == event.packageName) {
                     lastForegroundApp = null
                 }
            }
        }
        
        lastCheckedTime = endTime
        return lastForegroundApp
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Channel for foreground service (low priority)
            val fgChannel = NotificationChannel(
                CHANNEL_ID_FOREGROUND,
                "Stealth Monitor Service",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Keeps the quote monitoring service running in background"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(fgChannel)
            
            // Channel for quote notifications (high priority)
            val qChannel = NotificationChannel(
                CHANNEL_ID_QUOTE,
                "Disruptive Digital Well-Being Quotes",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows high-priority quotes when addictive apps are open too long"
                enableVibration(false)
                setSound(null, null)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(qChannel)
            
            val aChannel = NotificationChannel(
                CHANNEL_ID_ALARM,
                "Quote Monitor Alarms",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Morning alarm mode"
                enableVibration(false)
                setSound(null, null)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(aChannel)
        }
    }
}
