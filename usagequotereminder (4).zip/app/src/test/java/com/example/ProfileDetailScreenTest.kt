package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import com.example.ui.screens.ProfileDetailScreen
import com.example.viewmodel.ProfileViewModel
import com.example.model.Profile
import androidx.test.core.app.ApplicationProvider

@RunWith(AndroidJUnit4::class)
@Config(sdk = [33])
class ProfileDetailScreenTest {
    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testProfileDetailScreen_doesNotCrash() {
        val viewModel = ProfileViewModel()
        val profile = Profile(id = "1", profileName = "Test", quotes = arrayListOf())
        viewModel.setActiveProfile(profile)
        composeTestRule.setContent {
            ProfileDetailScreen(
                viewModel = viewModel,
                onNavigateToAddApp = {},
                onNavigateToAddDisguiseApp = {},
                onNavigateBack = {}
            )
        }
    }
}
