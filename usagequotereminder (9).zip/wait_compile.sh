while true; do
    if grep -q "Task :app:compileDebugKotlin" build/reports/profile/* 2>/dev/null; then
        echo "Done"
        break
    fi
    sleep 2
done
