#!/bin/bash
sed -i 's/builder.setSmallIcon(smallIconResId)/builder.setSmallIcon(R.drawable.ic_message_silhouette)\n            val largeIconBitmap = createDisguisedLargeIcon(this, pkgToDisguise, disguiseBitmap)\n            if (largeIconBitmap != null) {\n                builder.setLargeIcon(largeIconBitmap)\n            }/1' app/src/main/java/com/example/service/QuoteMonitorService.kt
