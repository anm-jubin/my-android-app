#!/bin/bash
cat << 'INNER_EOF' > snippet.kt
    private fun createDisguisedLargeIcon(context: Context, packageName: String, customBitmap: Bitmap?): Bitmap? {
        try {
            val size = 150
            val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)

            // Draw base image (customBitmap or default silhouette)
            if (customBitmap != null) {
                val scaledBase = Bitmap.createScaledBitmap(customBitmap, size, size, true)
                
                // Crop to circle
                val path = android.graphics.Path()
                path.addCircle(size / 2f, size / 2f, size / 2f, android.graphics.Path.Direction.CCW)
                canvas.clipPath(path)
                canvas.drawBitmap(scaledBase, 0f, 0f, null)
            } else {
                // Draw default grey circle
                val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                paint.color = 0xFF555555.toInt()
                canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
                
                paint.color = android.graphics.Color.WHITE
                // Draw head
                canvas.drawCircle(size / 2f, size * 0.35f, size * 0.2f, paint)
                // Draw body
                val path = android.graphics.Path()
                path.addArc(
                    size * 0.15f, size * 0.55f,
                    size * 0.85f, size * 1.55f,
                    180f, 180f
                )
                canvas.drawPath(path, paint)
            }

            // Reset clip if it was set
            canvas.clipRect(0, 0, size, size, android.graphics.Region.Op.REPLACE)

            // Get actual app icon
            val appIconDrawable = context.packageManager.getApplicationIcon(packageName)
            val appIconSize = (size * 0.35f).toInt()
            
            // Convert drawable to bitmap
            val appIconBitmap = Bitmap.createBitmap(appIconSize, appIconSize, Bitmap.Config.ARGB_8888)
            val appIconCanvas = android.graphics.Canvas(appIconBitmap)
            appIconDrawable.setBounds(0, 0, appIconSize, appIconSize)
            appIconDrawable.draw(appIconCanvas)
            
            // Draw badge background (dark circle for border)
            val badgeRadius = appIconSize / 2f + 4f
            val badgeCx = size - badgeRadius + 4f
            val badgeCy = size - badgeRadius + 4f
            
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            paint.color = 0xFF222222.toInt()
            canvas.drawCircle(badgeCx, badgeCy, badgeRadius, paint)
            
            // Draw app icon as circle
            val path = android.graphics.Path()
            path.addCircle(badgeCx, badgeCy, appIconSize / 2f, android.graphics.Path.Direction.CCW)
            canvas.clipPath(path)
            
            canvas.drawBitmap(appIconBitmap, size - appIconSize.toFloat(), size - appIconSize.toFloat(), null)
            
            return bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            return customBitmap
        }
    }
INNER_EOF

# insert snippet right before private fun createNotificationChannels
sed -i '/private fun createNotificationChannels/e cat snippet.kt' app/src/main/java/com/example/service/QuoteMonitorService.kt
rm snippet.kt
