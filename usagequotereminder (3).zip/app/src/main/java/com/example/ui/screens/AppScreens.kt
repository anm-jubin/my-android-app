package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.example.model.AppInfo
import com.example.model.NagMode
import com.example.model.Profile
import com.example.viewmodel.ProfileViewModel

import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

@Composable
fun AppIconImage(packageName: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var iconBitmap by remember(packageName) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var isLoading by remember(packageName) { mutableStateOf(true) }

    LaunchedEffect(packageName) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val drawable = context.packageManager.getApplicationIcon(packageName)
                val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
                val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
                val bmp = drawable.toBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
                iconBitmap = bmp.asImageBitmap()
            } catch (e: Exception) {
                // Ignore
            } finally {
                isLoading = false
            }
        }
    }

    if (iconBitmap != null) {
        androidx.compose.foundation.Image(
            bitmap = iconBitmap!!,
            contentDescription = null,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier
                .background(MaterialTheme.colorScheme.primaryContainer, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(12.dp),
                    strokeWidth = 1.5.dp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            } else {
                Text(
                    text = packageName.take(2).uppercase(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

@Composable
fun MainScreen(
    viewModel: ProfileViewModel,
    onNavigateToDetail: () -> Unit,
    onNavigateToSettings: () -> Unit,
    hasUsagePermission: Boolean
) {
    val context = LocalContext.current
    val profiles by viewModel.profiles.collectAsState()
    val isRunning by viewModel.isServiceRunning.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var newProfileName by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("UsageQuoteReminder", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_profile_fab")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Profile")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            // Permission Warning Banner
            if (!hasUsagePermission) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                        contentColor = MaterialTheme.colorScheme.onErrorContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = "Warning", tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "System Permission Required",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "App tracking access is needed to detect background apps. Please enable this in system settings.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onNavigateToSettings,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.fillMaxWidth().testTag("grant_permission_button")
                        ) {
                            Text("Grant Permission in Settings")
                        }
                    }
                }
            }

            // Foreground Service Dashboard Status Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isRunning) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "Disruption Engine Status",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(
                                            if (isRunning) Color.Green else Color.Gray,
                                            shape = CircleShape
                                        )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isRunning) "ACTIVE MONITORING" else "MUTED",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isRunning) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = {
                                if (isRunning) {
                                    viewModel.stopService(context)
                                } else {
                                    if (hasUsagePermission) {
                                        viewModel.startService(context)
                                    } else {
                                        onNavigateToSettings()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRunning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("service_toggle_button")
                        ) {
                            Text(if (isRunning) "Stop" else "Start")
                        }
                    }
                }
            }

            Text(
                "Your Detox Profiles",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (profiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No profiles config. Click + to add your first profile.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(profiles) { profile ->
                        ProfileListItem(
                            profile = profile,
                            onItemClick = {
                                viewModel.setActiveProfile(profile)
                                onNavigateToDetail()
                            },
                            onToggleEnabled = { isEnabled ->
                                viewModel.toggleProfileEnabled(context, profile.id, isEnabled)
                            }
                        )
                    }
                }
            }
        }
    }

    // New Profile Dialog
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = {
                showCreateDialog = false
                newProfileName = ""
            },
            title = { Text("Create Profile") },
            text = {
                Column {
                    Text("Enter a unique name for this screen-time regulation group:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newProfileName,
                        onValueChange = { newProfileName = it },
                        placeholder = { Text("e.g. Social Media Detox") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_field")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newProfileName.isNotBlank()) {
                            viewModel.createAndSetActiveProfile(newProfileName.trim())
                            showCreateDialog = false
                            newProfileName = ""
                            onNavigateToDetail()
                        }
                    },
                    modifier = Modifier.testTag("submit_profile_button")
                ) {
                    Text("Next")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showCreateDialog = false
                    newProfileName = ""
                }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileListItem(
    profile: Profile,
    onItemClick: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("profile_card_info"),
        onClick = onItemClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = profile.profileName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Metadata tags row using FlowRow to allow beautiful wrapping
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SuggestionChip(
                        onClick = {},
                        label = { Text("${profile.monitoredApps.size} Apps") },
                        icon = { Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                    SuggestionChip(
                        onClick = {},
                        label = { Text("${profile.quotes.size} Quotes") },
                        icon = { Icon(Icons.Default.FormatQuote, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                    SuggestionChip(
                        onClick = {},
                        label = {
                            Text(
                                if (profile.nagMode == NagMode.CONSTANT) "Constant"
                                else "Cooldown: ${profile.cooldownMinutes}m"
                            )
                        },
                        icon = { Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }
            }

            Switch(
                checked = profile.isEnabled,
                onCheckedChange = onToggleEnabled,
                modifier = Modifier
                    .padding(start = 12.dp)
                    .testTag("toggle_profile_switch")
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ProfileDetailScreen(
    viewModel: ProfileViewModel,
    onNavigateToAddApp: () -> Unit,
    onNavigateToAddDisguiseApp: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val activeProfileState by viewModel.activeProfile.collectAsState()

    if (activeProfileState == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No profile loaded")
        }
        return
    }

    val profile = activeProfileState!!

    // Edit form inputs
    var profileName by remember(profile.id) { mutableStateOf(profile.profileName) }
    var initialDelay by remember(profile.id) { mutableStateOf(profile.initialDelayMinutes.toString()) }
    var rangeMin by remember(profile.id) { mutableStateOf(profile.rangeStartMinutes.toString()) }
    var rangeMax by remember(profile.id) { mutableStateOf(profile.rangeEndMinutes.toString()) }
    var cooldownMin by remember(profile.id) { mutableStateOf(profile.cooldownMinutes.toString()) }
    var isCooldownMode by remember(profile.id) { mutableStateOf(profile.nagMode == NagMode.COOLDOWN) }
    
    // Notification & Sound State
    var soundUri by remember(profile.id) { mutableStateOf(profile.soundUri) }
    var selectedSoundUris by remember(profile.id) { mutableStateOf(profile.selectedSoundUris) }
    var randomizeSound by remember(profile.id) { mutableStateOf(profile.randomizeSound) }
    var randomizeVibration by remember(profile.id) { mutableStateOf(profile.randomizeVibration) }
    var vibrationType by remember(profile.id) { mutableStateOf(profile.vibrationType) }
    
    // Time Period State
    var triggerType by remember(profile.id) { mutableStateOf(profile.triggerType) }
    var timePeriodStartTime by remember(profile.id) { mutableStateOf(profile.timePeriodStartTime) }
    var timePeriodEndTime by remember(profile.id) { mutableStateOf(profile.timePeriodEndTime) }
    
    // Disguise State
    var disguiseApps by remember(profile.id) { mutableStateOf(profile.disguiseApps) }
    var randomizeDisguise by remember(profile.id) { mutableStateOf(profile.randomizeDisguise) }
    
    // Ringtone picker launcher
    val ringtonePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val uri = result.data?.getParcelableExtra<android.net.Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (uri != null) {
                if (randomizeSound) {
                    val currentList = ArrayList(selectedSoundUris)
                    currentList.add(uri.toString())
                    selectedSoundUris = currentList
                } else {
                    val currentList = ArrayList<String>()
                    currentList.add(uri.toString())
                    selectedSoundUris = currentList
                }
            }
        }
    }

    // Quote add/edit dialog states
    var showQuoteDialog by remember { mutableStateOf(false) }
    var dialogQuoteText by remember { mutableStateOf("") }
    var editingQuoteIndex by remember { mutableStateOf<Int?>(null) }

    // Bulk quotes dialog states
    var showBulkQuotesDialog by remember { mutableStateOf(false) }
    var bulkQuotesText by remember { mutableStateOf("") }

    // Multi-Selection State for Quotes
    val selectedQuoteIndices by viewModel.selectedQuoteIndices.collectAsState()
    val isQuoteSelectionMode by viewModel.isQuoteSelectionMode.collectAsState()

    // Sync input states inside ViewModel changes
    LaunchedEffect(
        profileName, initialDelay, rangeMin, rangeMax, cooldownMin, isCooldownMode,
        soundUri, selectedSoundUris, randomizeSound, randomizeVibration, vibrationType,
        triggerType, timePeriodStartTime, timePeriodEndTime, disguiseApps, randomizeDisguise
    ) {
        viewModel.updateActiveProfileDetails(
            name = profileName,
            initialDelay = initialDelay.toIntOrNull() ?: 1,
            rangeStart = rangeMin.toIntOrNull() ?: 1,
            rangeEnd = rangeMax.toIntOrNull() ?: 3,
            cooldown = cooldownMin.toIntOrNull() ?: 2,
            isCooldownMode = isCooldownMode,
            soundUri = soundUri,
            selectedSoundUris = selectedSoundUris,
            randomizeSound = randomizeSound,
            randomizeVibration = randomizeVibration,
            vibrationType = vibrationType,
            triggerType = triggerType,
            timePeriodStartTime = timePeriodStartTime,
            timePeriodEndTime = timePeriodEndTime,
            disguiseApps = disguiseApps,
            randomizeDisguise = randomizeDisguise
        )
    }

    Scaffold(
        topBar = {
            if (isQuoteSelectionMode) {
                // Symmetrical Contextual Action Bar (CAB) matching theme colors
                TopAppBar(
                    title = {
                        Text(
                            text = "${selectedQuoteIndices.size} Selected",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.clearQuoteSelection() }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear Selection", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = { viewModel.selectAllQuotes() },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Select All", fontWeight = FontWeight.Bold)
                        }
                        IconButton(
                            onClick = { viewModel.bulkCopyQuotes(context) },
                            modifier = Modifier.testTag("bulk_copy_quotes_button")
                        ) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Copy Selected", tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                        IconButton(
                            onClick = { viewModel.bulkDeleteQuotes() },
                            modifier = Modifier.testTag("bulk_delete_quotes_button")
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete Selected", tint = MaterialTheme.colorScheme.error)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                )
            } else {
                TopAppBar(
                    title = {
                        Text(
                            text = if (profile.profileName.isEmpty()) "Edit Rules" else profileName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Go Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Profile info inputs
            item {
                OutlinedTextField(
                    value = profileName,
                    onValueChange = { profileName = it },
                    label = { Text("Profile Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("profile_detail_name_field")
                )
            }
            
            // Trigger Type Selector
            item {
                Column {
                    Text(
                        "Trigger Mode",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            com.example.model.TriggerType.APP_USAGE to "App Usage",
                            com.example.model.TriggerType.TIME_PERIOD to "Time Period"
                        ).forEach { (type, label) ->
                            val isSelected = triggerType == type
                            Card(
                                onClick = { triggerType = type },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .width(120.dp)
                                    .height(48.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = label,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
            
            if (triggerType == com.example.model.TriggerType.TIME_PERIOD) {
                // Time Period Config
                item {
                    Column {
                        Text(
                            text = "Time Period Configuration",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Start Time
                            SystemTimePickerCard("START TIME", timePeriodStartTime, { timePeriodStartTime = it }, modifier = Modifier.weight(1f))
                            // End Time
                            SystemTimePickerCard("END TIME", timePeriodEndTime, { timePeriodEndTime = it }, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            if (triggerType == com.example.model.TriggerType.APP_USAGE) {
                // Symmetrical Timing Configuration Card Grid (Geometric Balance Style)
                item {
                    Column {
                    Text(
                        text = "Timing Configuration",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Card 1: Grace Period
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "GRACE PERIOD",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedTextField(
                                        value = initialDelay,
                                        onValueChange = { initialDelay = it },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent,
                                            errorBorderColor = Color.Transparent,
                                            focusedContainerColor = Color.Transparent,
                                            unfocusedContainerColor = Color.Transparent,
                                            disabledContainerColor = Color.Transparent
                                        ),
                                        textStyle = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .testTag("initial_delay_field")
                                    )
                                    Text(
                                        "min",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(start = 2.dp, bottom = 4.dp)
                                    )
                                }
                            }
                        }

                        // Card 2: Cooldown (conditional / semi-transparent if disabled)
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCooldownMode) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(
                                1.dp,
                                if (isCooldownMode) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "COOLDOWN",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCooldownMode) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedTextField(
                                        value = cooldownMin,
                                        onValueChange = { cooldownMin = it },
                                        enabled = isCooldownMode,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent,
                                            disabledBorderColor = Color.Transparent,
                                            focusedContainerColor = Color.Transparent,
                                            unfocusedContainerColor = Color.Transparent,
                                            disabledContainerColor = Color.Transparent
                                        ),
                                        textStyle = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCooldownMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .testTag("cooldown_field")
                                    )
                                    Text(
                                        "min",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isCooldownMode) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                        modifier = Modifier.padding(start = 2.dp, bottom = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Card 3: Min Random Delay
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "MIN RANDOM INTERV",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedTextField(
                                        value = rangeMin,
                                        onValueChange = { rangeMin = it },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent,
                                            errorBorderColor = Color.Transparent,
                                            focusedContainerColor = Color.Transparent,
                                            unfocusedContainerColor = Color.Transparent,
                                            disabledContainerColor = Color.Transparent
                                        ),
                                        textStyle = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .testTag("range_min_field")
                                    )
                                    Text(
                                        "min",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(start = 2.dp, bottom = 4.dp)
                                    )
                                }
                            }
                        }

                        // Card 4: Max Random Delay
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "MAX RANDOM INTERV",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    OutlinedTextField(
                                        value = rangeMax,
                                        onValueChange = { rangeMax = it },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent,
                                            errorBorderColor = Color.Transparent,
                                            focusedContainerColor = Color.Transparent,
                                            unfocusedContainerColor = Color.Transparent,
                                            disabledContainerColor = Color.Transparent
                                        ),
                                        textStyle = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(52.dp)
                                            .testTag("range_max_field")
                                    )
                                    Text(
                                        "min",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(start = 2.dp, bottom = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Nag Mode Selectors
            item {
                Column {
                    Text(
                        "Trigger Frequency Mode",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(false, true).forEach { modeCooldown ->
                            val isSelected = isCooldownMode == modeCooldown
                            Card(
                                onClick = { isCooldownMode = modeCooldown },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = if (modeCooldown) "Cooldown Period" else "Constant Nagging",
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            } // Close first APP_USAGE trigger block

            // Notification Customization
            item {
                Column {
                    Text(
                        "Notification Customization",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            // Sound Controls
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Randomize Sound", fontWeight = FontWeight.Bold)
                                    Text("Pick a random system notification sound per quote from your selected list", style = MaterialTheme.typography.bodySmall)
                                }
                                Switch(
                                    checked = randomizeSound,
                                    onCheckedChange = { randomizeSound = it }
                                )
                            }
                            
                            if (randomizeSound) {
                                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Sounds Pool", fontWeight = FontWeight.SemiBold)
                                        OutlinedButton(onClick = {
                                            val intent = android.content.Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER)
                                            intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_NOTIFICATION)
                                            intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                            intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                            ringtonePickerLauncher.launch(intent)
                                        }) {
                                            Text("Add Sound")
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (selectedSoundUris.isEmpty()) {
                                        Text("No sounds selected. System default will be used.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            selectedSoundUris.forEachIndexed { index, uriStr ->
                                                var name by remember(uriStr) { mutableStateOf("Loading...") }
                                                LaunchedEffect(uriStr) {
                                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                                        try {
                                                            val rm = android.media.RingtoneManager.getRingtone(context, android.net.Uri.parse(uriStr))
                                                            name = rm?.getTitle(context) ?: "Unknown Sound"
                                                        } catch (e: Exception) {
                                                            name = "Unknown Sound"
                                                        }
                                                    }
                                                }
                                                Row(
                                                    modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(name, style = MaterialTheme.typography.bodySmall, maxLines = 1, modifier = Modifier.weight(1f))
                                                    IconButton(onClick = {
                                                        val currentList = ArrayList(selectedSoundUris)
                                                        currentList.removeAt(index)
                                                        selectedSoundUris = currentList
                                                    }, modifier = Modifier.size(24.dp)) {
                                                        Icon(Icons.Filled.Close, contentDescription = "Remove Sound", modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    var name by remember(selectedSoundUris) { mutableStateOf("Loading...") }
                                    LaunchedEffect(selectedSoundUris) {
                                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                            try {
                                                val rm = if (selectedSoundUris.isNotEmpty()) android.media.RingtoneManager.getRingtone(context, android.net.Uri.parse(selectedSoundUris[0])) else null
                                                name = rm?.getTitle(context) ?: "Default System Sound"
                                            } catch (e: Exception) {
                                                name = "Default System Sound"
                                            }
                                        }
                                    }
                                    Text(name, modifier = Modifier.weight(1f))
                                    OutlinedButton(onClick = {
                                        val intent = android.content.Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER)
                                        intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_NOTIFICATION)
                                        intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                        intent.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                        ringtonePickerLauncher.launch(intent)
                                    }) {
                                        Text("Select")
                                    }
                                }
                            }
                            
                            androidx.compose.material3.Divider(modifier = Modifier.padding(vertical = 4.dp))
                            
                            // Vibration Controls
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Randomize Vibration", fontWeight = FontWeight.Bold)
                                    Text("Pick a random vibration type per quote", style = MaterialTheme.typography.bodySmall)
                                }
                                Switch(
                                    checked = randomizeVibration,
                                    onCheckedChange = { randomizeVibration = it }
                                )
                            }
                            
                            if (!randomizeVibration) {
                                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                                    Text("Vibration Pattern", fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(0 to "Single", 1 to "Double", 2 to "Heavy", 3 to "None").forEach { (type, label) ->
                                            val isSelected = vibrationType == type
                                            Card(
                                                onClick = { vibrationType = type },
                                                colors = CardDefaults.cardColors(
                                                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                                                ),
                                                border = BorderStroke(
                                                    1.dp,
                                                    if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(36.dp)
                                            ) {
                                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = label,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Notification Disguise
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Notification Disguise",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = {
                                viewModel.saveActiveProfile(context)
                                onNavigateToAddDisguiseApp()
                            }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Add, contentDescription = "Add")
                                Spacer(Modifier.width(4.dp))
                                Text("Add App")
                            }
                        }
                    }

                    if (disguiseApps.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 4.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Randomize Disguise", fontWeight = FontWeight.Bold)
                                Text("Pick a random app to disguise as", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(
                                checked = randomizeDisguise,
                                onCheckedChange = { randomizeDisguise = it }
                            )
                        }

                        disguiseApps.forEach { pkg ->
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = CardDefaults.outlinedCardBorder()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AppIconImage(packageName = pkg, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(pkg, modifier = Modifier.weight(1f))
                                    IconButton(
                                        onClick = { viewModel.removeDisguiseAppFromActiveProfile(pkg) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    } else {
                        Text("No disguise apps selected. Notification will show as Nudge.", style = MaterialTheme.typography.bodySmall, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    }
                }
            }

            if (triggerType == com.example.model.TriggerType.APP_USAGE) {
            // Monitored Apps section
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Regulated Apps",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(
                            onClick = {
                                viewModel.saveActiveProfile(context) // cache what we have
                                onNavigateToAddApp()
                            },
                            modifier = Modifier.testTag("add_regulated_app_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Apps")
                            }
                        }
                    }

                    if (profile.monitoredApps.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No apps in list. Click 'Add Apps' to start monitoring.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        // Show current monitored app packages
                        FlowRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            profile.monitoredApps.forEach { p ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier.testTag("app_chip_$p")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        AppIconImage(packageName = p, modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = p.split(".").lastOrNull() ?: p,
                                            style = MaterialTheme.typography.labelLarge,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = { viewModel.removeAppFromActiveProfile(p) },
                                            modifier = Modifier.size(24.dp).testTag("delete_app_$p")
                                        ) {
                                            Icon(
                                                Icons.Filled.Close,
                                                contentDescription = "Remove App",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            } // Close second APP_USAGE trigger block

            // Custom Quotes section CAB Contextual Header Card
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Disruptive Quotes",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(
                            onClick = {
                                bulkQuotesText = profile.quotes.joinToString(separator = "\n\n\n\n")
                                showBulkQuotesDialog = true
                            },
                            modifier = Modifier.testTag("bulk_edit_quotes_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Bulk Edit")
                            }
                        }
                        TextButton(
                            onClick = {
                                editingQuoteIndex = null
                                dialogQuoteText = ""
                                showQuoteDialog = true
                            },
                            modifier = Modifier.testTag("add_quote_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.AddComment, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Quote")
                            }
                        }
                    }
                }
            }

            // Quote selection bulk tools bar if selection mode is active
            if (isQuoteSelectionMode) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quote_selection_cab_bar")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { viewModel.clearQuoteSelection() }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear Selection")
                                }
                                Text(
                                    text = "${selectedQuoteIndices.size} Selected",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            Row {
                                TextButton(onClick = { viewModel.selectAllQuotes() }) {
                                    Text("Select All")
                                }

                                IconButton(
                                    onClick = { viewModel.bulkCopyQuotes(context) },
                                    modifier = Modifier.testTag("bulk_copy_quotes_button")
                                ) {
                                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy Selected")
                                }

                                IconButton(
                                    onClick = { viewModel.bulkDeleteQuotes() },
                                    modifier = Modifier.testTag("bulk_delete_quotes_button")
                                ) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete Selected", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }

            // Bullet quotes list inside main list container
            if (profile.quotes.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No disruptive quotes added. Add a quote to break scrolls.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                itemsIndexed(profile.quotes) { index, quote ->
                    val isSelected = selectedQuoteIndices.contains(index)
                    QuoteRowItem(
                        quote = quote,
                        isSelected = isSelected,
                        isInSelectionMode = isQuoteSelectionMode,
                        onClick = {
                            if (isQuoteSelectionMode) {
                                viewModel.toggleQuoteSelection(index)
                            } else {
                                // Normal tap: Edit single quote
                                editingQuoteIndex = index
                                dialogQuoteText = quote
                                showQuoteDialog = true
                            }
                        },
                        onLongClick = {
                            viewModel.toggleQuoteSelection(index)
                        },
                        testTagSuffix = index.toString()
                    )
                }
            }

            // Top footer / persistent action elements
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (profileName.isNotBlank()) {
                            viewModel.saveActiveProfile(context)
                            onNavigateBack()
                        } else {
                            Toast.makeText(context, "Please enter a valid profile name", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_profile_button")
                ) {
                    Text("Save Regulation Profile", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        viewModel.deleteActiveProfile(context)
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("delete_profile_button")
                ) {
                    Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Wipe Regulation Profile")
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Add or Edit single quote dialog
    if (showQuoteDialog) {
        AlertDialog(
            onDismissRequest = {
                showQuoteDialog = false
                dialogQuoteText = ""
                editingQuoteIndex = null
            },
            title = { Text(if (editingQuoteIndex == null) "Add Disorienting Quote" else "Modify Quote") },
            text = {
                Column {
                    Text("Enter custom text to flash over addictive apps:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = dialogQuoteText,
                        onValueChange = { dialogQuoteText = it },
                        placeholder = { Text("e.g., Scrolling won't fulfill you.") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth().testTag("quote_input_field")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (dialogQuoteText.isNotBlank()) {
                            val trimmed = dialogQuoteText.trim()
                            val idx = editingQuoteIndex
                            if (idx == null) {
                                viewModel.addQuoteToActiveProfile(trimmed)
                            } else {
                                viewModel.editQuoteInActiveProfile(idx, trimmed)
                            }
                            showQuoteDialog = false
                            dialogQuoteText = ""
                            editingQuoteIndex = null
                        }
                    },
                    modifier = Modifier.testTag("submit_quote_button")
                ) {
                    Text("Apply")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showQuoteDialog = false
                    dialogQuoteText = ""
                    editingQuoteIndex = null
                }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showBulkQuotesDialog) {
        AlertDialog(
            onDismissRequest = {
                showBulkQuotesDialog = false
                bulkQuotesText = ""
            },
            title = { Text("Bulk Edit Quotes") },
            text = {
                Column {
                    Text(
                        text = "Paste or edit multiple quotes below. Separate each individual quote with exactly three empty lines.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = bulkQuotesText,
                        onValueChange = { bulkQuotesText = it },
                        placeholder = { Text("Quote A\n\n\n\nQuote B\n\n\n\nQuote C") },
                        minLines = 8,
                        maxLines = 12,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bulk_quotes_input_field")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val text = bulkQuotesText
                        val list = text.split(Regex("\\r?\\n(\\s*\\r?\\n){3}"))
                            .map { it.trim() }
                            .filter { it.isNotEmpty() }
                        
                        viewModel.replaceQuotesInActiveProfile(list)
                        showBulkQuotesDialog = false
                        bulkQuotesText = ""
                    },
                    modifier = Modifier.testTag("save_bulk_quotes_button")
                ) {
                    Text("Save All")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showBulkQuotesDialog = false
                    bulkQuotesText = ""
                }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SystemTimePickerCard(
    label: String,
    minutesFromMidnight: Int,
    onTimeSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    val hour = minutesFromMidnight / 60
    val minute = minutesFromMidnight % 60
    
    val isPM = hour >= 12
    val displayHour = if (hour % 12 == 0) 12 else hour % 12
    val amPmStr = if (isPM) "PM" else "AM"
    val timeStr = java.lang.String.format("%02d:%02d %s", displayHour, minute, amPmStr)
    
    Card(
        onClick = {
            val picker = android.app.TimePickerDialog(
                context,
                { _, selectedHour, selectedMinute ->
                    onTimeSelected(selectedHour * 60 + selectedMinute)
                },
                hour,
                minute,
                false
            )
            picker.show()
        },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(
                    text = timeStr,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun QuoteRowItem(
    quote: String,
    isSelected: Boolean,
    isInSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    testTagSuffix: String
) {
    val containerBg = if (isSelected) {
        Color(0x40008577) // semi-transparent teal as specified (#40008577)
    } else {
        MaterialTheme.colorScheme.surface
    }

    val borderStroke = if (isSelected) {
        BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
    } else {
        BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = containerBg),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("quote_row_$testTagSuffix"),
        shape = RoundedCornerShape(12.dp),
        border = borderStroke
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isInSelectionMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onClick() },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF008577)),
                    modifier = Modifier.padding(end = 6.dp)
                )
            } else {
                Icon(
                    Icons.Filled.FormatQuote,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    modifier = Modifier.size(24.dp).padding(end = 4.dp)
                )
            }

            Text(
                text = quote,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )

            if (!isInSelectionMode) {
                Icon(
                    Icons.Filled.Edit,
                    contentDescription = "Edit Quote",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAppScreen(
    viewModel: ProfileViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val installedApps by viewModel.installedApps.collectAsState()
    val isLoading by viewModel.isLoadingApps.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) {
            installedApps
        } else {
            installedApps.filter {
                it.label.contains(searchQuery, ignoreCase = true) ||
                        it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.loadInstalledApps(context)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Select Apps to Monitor") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Go Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search apps by name...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("app_search_field")
            )

            if (isLoading) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (filteredApps.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No applications matches your hunt.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredApps) { app ->
                        Card(
                            onClick = {
                                viewModel.addAppToActiveProfile(app.packageName)
                                onNavigateBack()
                            },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_app_row_${app.packageName}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIconImage(packageName = app.packageName, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = app.label,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDisguiseAppScreen(
    viewModel: ProfileViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val installedApps by viewModel.installedApps.collectAsState()
    val isLoading by viewModel.isLoadingApps.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) {
            installedApps
        } else {
            installedApps.filter {
                it.label.contains(searchQuery, ignoreCase = true) ||
                        it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.loadInstalledApps(context)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Select App to Disguise As") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Go Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search apps by name...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .testTag("disguise_app_search_field")
            )

            if (isLoading) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (filteredApps.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No applications matches your hunt.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredApps) { app ->
                        Card(
                            onClick = {
                                viewModel.addDisguiseAppToActiveProfile(app.packageName)
                                onNavigateBack()
                            },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = CardDefaults.outlinedCardBorder(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("select_disguise_app_row_${app.packageName}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AppIconImage(packageName = app.packageName, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = app.label,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = app.packageName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
