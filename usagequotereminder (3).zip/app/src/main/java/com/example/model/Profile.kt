package com.example.model

import java.io.Serializable
import java.util.UUID

enum class NagMode {
    CONSTANT,
    COOLDOWN
}

enum class TriggerType {
    APP_USAGE,
    TIME_PERIOD
}

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    var profileName: String = "",
    var monitoredApps: ArrayList<String> = ArrayList(),
    var quotes: ArrayList<String> = ArrayList(),
    var initialDelayMinutes: Int = 1, // Defaulting to 1 for easier testing/use
    var rangeStartMinutes: Int = 1,
    var rangeEndMinutes: Int = 3,
    var cooldownMinutes: Int = 2,
    var nagMode: NagMode = NagMode.CONSTANT,
    var triggerType: TriggerType = TriggerType.APP_USAGE,
    var timePeriodStartTime: Int = 15 * 60, // 3:00 PM
    var timePeriodEndTime: Int = 16 * 60, // 4:00 PM
    var isEnabled: Boolean = true,
    var soundUri: String? = null,
    var selectedSoundUris: ArrayList<String> = ArrayList(),
    var randomizeSound: Boolean = false,
    var randomizeVibration: Boolean = false,
    var vibrationType: Int = 0 // 0 = Single, 1 = Double, 2 = Heavy
) : Serializable
