import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """@Composable
fun SettingsSection(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .androidx.compose.foundation.border(
                width = 1.dp,
                color = androidx.compose.ui.graphics.Color.Gray.copy(alpha = 0.5f),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
            )
            .padding(8.dp)
    ) {
        androidx.compose.material3.Text(
            text = title,
            color = androidx.compose.ui.graphics.Color.Cyan,
            style = androidx.compose.material3.MaterialTheme.typography.titleSmall,
            modifier = androidx.compose.ui.Modifier.padding(bottom = 8.dp)
        )
        content()
    }
}"""

replacement = """@Composable
fun SettingsSection(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    androidx.compose.foundation.layout.Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .androidx.compose.foundation.border(
                width = 1.dp,
                color = Color.Gray.copy(alpha = 0.5f),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
            )
            .padding(8.dp)
    ) {
        androidx.compose.material3.Text(
            text = title,
            color = Color.Cyan,
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        content()
    }
}"""
content = content.replace(target, replacement)

content = content.replace(".androidx.compose.foundation.border", ".border")

if "import androidx.compose.foundation.border" not in content:
    content = content.replace("import androidx.compose.foundation.background", "import androidx.compose.foundation.background\nimport androidx.compose.foundation.border\nimport androidx.compose.foundation.shape.RoundedCornerShape")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

