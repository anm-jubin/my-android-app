package com.example

import android.content.Context
import android.webkit.WebView
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class Test2 {
    fun test(context: Context, webView: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            val profileStore = ProfileStore.getInstance()
            val profile = profileStore.getOrCreateProfile("incognito")
            val cm = profile.cookieManager
        }
    }
}
