package com.example

import android.content.Context
import android.webkit.WebView
import androidx.webkit.WebViewCompat

class Test3 {
    fun test(context: Context, webView: WebView) {
        val p = WebViewCompat.getProfile(webView)
    }
}
