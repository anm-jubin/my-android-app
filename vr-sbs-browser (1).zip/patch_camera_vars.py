import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add states
target_states = """    var contentOpacity by remember { mutableFloatStateOf(prefs.getFloat("contentOpacity", 1f)) }"""

replacement_states = """    var contentOpacity by remember { mutableFloatStateOf(prefs.getFloat("contentOpacity", 1f)) }
    var cameraIpd by remember { mutableFloatStateOf(prefs.getFloat("cameraIpd", 0f)) }
    var cameraScale by remember { mutableFloatStateOf(prefs.getFloat("cameraScale", 1f)) }
    var cameraVerticalShift by remember { mutableFloatStateOf(prefs.getFloat("cameraVerticalShift", 0f)) }"""
content = content.replace(target_states, replacement_states)

# Add save effects
target_save_effects = """    LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity) {
        prefs.edit()
            .putBoolean("isDesktopMode", isDesktopMode)
            .putBoolean("isRightHandMode", isRightHandMode)
            .putFloat("scale", scale)
            .putFloat("ipd", ipd)
            .putFloat("verticalShift", verticalShift)
            .putFloat("fabOffsetX", fabOffsetX)
            .putFloat("fabOffsetY", fabOffsetY)
            .putString("tabs", Json.encodeToString(tabs))
            .putLong("activeTabId", activeTabId)
            .putBoolean("lensWrapping", lensWrapping)
            .putFloat("lensDistortion", lensDistortion)
            .putString("bookmarks", Json.encodeToString(bookmarks))
            .putString("searchEngine", searchEngine)
            .putBoolean("gyroEnabled", gyroEnabled)
            .putFloat("gyroSensitivity", gyroSensitivity)
            .putBoolean("historyEnabled", historyEnabled)
            .putString("historyList", Json.encodeToString(historyList))
            .putBoolean("cameraPassthroughEnabled", cameraPassthroughEnabled)
            .putFloat("contentOpacity", contentOpacity)
            .apply()
    }"""

replacement_save_effects = """    LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity, cameraIpd, cameraScale, cameraVerticalShift) {
        prefs.edit()
            .putBoolean("isDesktopMode", isDesktopMode)
            .putBoolean("isRightHandMode", isRightHandMode)
            .putFloat("scale", scale)
            .putFloat("ipd", ipd)
            .putFloat("verticalShift", verticalShift)
            .putFloat("fabOffsetX", fabOffsetX)
            .putFloat("fabOffsetY", fabOffsetY)
            .putString("tabs", Json.encodeToString(tabs))
            .putLong("activeTabId", activeTabId)
            .putBoolean("lensWrapping", lensWrapping)
            .putFloat("lensDistortion", lensDistortion)
            .putString("bookmarks", Json.encodeToString(bookmarks))
            .putString("searchEngine", searchEngine)
            .putBoolean("gyroEnabled", gyroEnabled)
            .putFloat("gyroSensitivity", gyroSensitivity)
            .putBoolean("historyEnabled", historyEnabled)
            .putString("historyList", Json.encodeToString(historyList))
            .putBoolean("cameraPassthroughEnabled", cameraPassthroughEnabled)
            .putFloat("contentOpacity", contentOpacity)
            .putFloat("cameraIpd", cameraIpd)
            .putFloat("cameraScale", cameraScale)
            .putFloat("cameraVerticalShift", cameraVerticalShift)
            .apply()
    }"""
content = content.replace(target_save_effects, replacement_save_effects)

# Add settings UI
target_settings_ui = """                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("Opacity", modifier = Modifier.weight(1f), color = Color.White)
                                    Slider(
                                        value = contentOpacity,
                                        onValueChange = { contentOpacity = it },
                                        valueRange = 0f..1f,
                                        modifier = Modifier.weight(2f)
                                    )
                                }
                            }"""

replacement_settings_ui = """                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("Opacity", modifier = Modifier.weight(1f), color = Color.White)
                                    Slider(
                                        value = contentOpacity,
                                        onValueChange = { contentOpacity = it },
                                        valueRange = 0f..1f,
                                        modifier = Modifier.weight(2f)
                                    )
                                }
                            }
                            item { Divider(color = Color.DarkGray, modifier = Modifier.padding(vertical = 8.dp)) }
                            item {
                                Text("Camera Display", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("Camera IPD", modifier = Modifier.weight(1f), color = Color.White)
                                    Slider(
                                        value = cameraIpd,
                                        onValueChange = { cameraIpd = it },
                                        valueRange = -200f..200f,
                                        modifier = Modifier.weight(2f)
                                    )
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("Camera Scale", modifier = Modifier.weight(1f), color = Color.White)
                                    Slider(
                                        value = cameraScale,
                                        onValueChange = { cameraScale = it },
                                        valueRange = 0.5f..2.5f,
                                        modifier = Modifier.weight(2f)
                                    )
                                }
                            }
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text("Camera Vertical", modifier = Modifier.weight(1f), color = Color.White)
                                    Slider(
                                        value = cameraVerticalShift,
                                        onValueChange = { cameraVerticalShift = it },
                                        valueRange = -300f..300f,
                                        modifier = Modifier.weight(2f)
                                    )
                                }
                            }"""
content = content.replace(target_settings_ui, replacement_settings_ui)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

