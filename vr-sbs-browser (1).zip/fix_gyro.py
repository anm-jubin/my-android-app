import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    var baseOrientation by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }
    var currentOrientation by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }"""

print("Target found:", target in content)
