import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix gyro offsets
target_wrapper_usage = """        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = cameraIpd,
                gyroYawOffset = gyroYawOffset,
                gyroPitchOffset = gyroPitchOffset,
                verticalShift = cameraVerticalShift,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {"""
            
replacement_wrapper_usage = """        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = cameraIpd,
                gyroYawOffset = 0f,
                gyroPitchOffset = 0f,
                verticalShift = cameraVerticalShift,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {"""
content = content.replace(target_wrapper_usage, replacement_wrapper_usage)

# Fix settings UI
target_settings = """                            if (cameraPassthroughEnabled) {
                                Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = contentOpacity,
                                    onValueChange = { contentOpacity = it },
                                    valueRange = 0.1f..1.0f
                                )
                            }"""
                            
replacement_settings = """                            if (cameraPassthroughEnabled) {
                                Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = contentOpacity,
                                    onValueChange = { contentOpacity = it },
                                    valueRange = 0.1f..1.0f
                                )
                                Text("Camera IPD", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cameraIpd,
                                    onValueChange = { cameraIpd = it },
                                    valueRange = -200f..200f
                                )
                                Text("Camera Scale", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cameraScale,
                                    onValueChange = { cameraScale = it },
                                    valueRange = 0.5f..2.5f
                                )
                                Text("Camera Vertical", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cameraVerticalShift,
                                    onValueChange = { cameraVerticalShift = it },
                                    valueRange = -300f..300f
                                )
                            }"""
content = content.replace(target_settings, replacement_settings)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
