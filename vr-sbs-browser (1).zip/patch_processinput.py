import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                }

                fun processInput(input: String): String {
                    val trimmed = input.trim()
                    if (trimmed.isEmpty()) return "https://www.google.com"
                    val isUrl = !trimmed.contains(" ") && (trimmed.contains(".") || trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("localhost"))
                    if (isUrl) {
                        return if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) "https://$trimmed" else trimmed
                    } else {
                        val encoded = java.net.URLEncoder.encode(trimmed, "UTF-8")
                        return when (searchEngine) {
                            "Bing" -> "https://www.bing.com/search?q=$encoded"
                            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
                            else -> "https://www.google.com/search?q=$encoded"
                        }
                    }
                }

                // Address Bar"""

replace = """                }

                // Address Bar"""

content = content.replace(target, replace)

target_insert = """    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }"""

replace_insert = """    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }
    
    fun processInput(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return "https://www.google.com"
        val isUrl = !trimmed.contains(" ") && (trimmed.contains(".") || trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("localhost"))
        if (isUrl) {
            return if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) "https://$trimmed" else trimmed
        } else {
            val encoded = java.net.URLEncoder.encode(trimmed, "UTF-8")
            return when (searchEngine) {
                "Bing" -> "https://www.bing.com/search?q=$encoded"
                "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
                else -> "https://www.google.com/search?q=$encoded"
            }
        }
    }"""

content = content.replace(target_insert, replace_insert)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
