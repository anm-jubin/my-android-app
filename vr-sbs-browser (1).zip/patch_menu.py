import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                            DropdownMenuItem(
                                text = { Text("Bookmarks") },
                                onClick = { 
                                    menuExpanded = false
                                    showBookmarksList = !showBookmarksList
                                    if (showBookmarksList) showControls = false
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) }
                            )"""

replace = """                            DropdownMenuItem(
                                text = { Text("Bookmarks") },
                                onClick = { 
                                    menuExpanded = false
                                    showBookmarksList = !showBookmarksList
                                    if (showBookmarksList) { showControls = false; showHistoryList = false }
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("History") },
                                onClick = { 
                                    menuExpanded = false
                                    showHistoryList = !showHistoryList
                                    if (showHistoryList) { showControls = false; showBookmarksList = false }
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) } // Use List icon or something else
                            )"""

content = content.replace(target, replace)

target_settings = """                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = { 
                                    menuExpanded = false
                                    showControls = !showControls
                                    if (showControls) showBookmarksList = false
                                },"""

replace_settings = """                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = { 
                                    menuExpanded = false
                                    showControls = !showControls
                                    if (showControls) { showBookmarksList = false; showHistoryList = false }
                                },"""
content = content.replace(target_settings, replace_settings)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
