import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

state_target = """    var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isDesktopMode", true)) }"""
state_replace = """    var keepScreenOn by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("keepScreenOn", false)) }
    var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isDesktopMode", true)) }"""

effect_target = """    val browserManager = androidx.compose.runtime.remember {"""
effect_replace = """    val activity = context as? android.app.Activity
    androidx.compose.runtime.LaunchedEffect(keepScreenOn) {
        if (keepScreenOn) {
            activity?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    val browserManager = androidx.compose.runtime.remember {"""

save_target = """        prefs.edit().putBoolean("isDesktopMode", isDesktopMode).apply()"""
save_replace = """        prefs.edit().putBoolean("keepScreenOn", keepScreenOn).apply()
        prefs.edit().putBoolean("isDesktopMode", isDesktopMode).apply()"""

ui_target = """                            SettingsSection("Browser & System") {
                                Row(verticalAlignment = Alignment.CenterVertically) {"""
ui_replace = """                            SettingsSection("Browser & System") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Keep Screen On", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = keepScreenOn, onCheckedChange = { keepScreenOn = it })
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {"""

content = content.replace(state_target, state_replace)
content = content.replace(effect_target, effect_replace)
content = content.replace(save_target, save_replace)
content = content.replace(ui_target, ui_replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
