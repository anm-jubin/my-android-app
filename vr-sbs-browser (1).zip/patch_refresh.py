import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace('Icon(Icons.Default.Add, contentDescription = "Recenter", tint = Color.Black)', 
                          'Icon(androidx.compose.material.icons.Icons.Default.Refresh, contentDescription = "Recenter", tint = Color.Black)')

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
