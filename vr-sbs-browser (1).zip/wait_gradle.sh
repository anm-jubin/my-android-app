while ps aux | grep -v grep | grep gradle > /dev/null; do sleep 1; done
