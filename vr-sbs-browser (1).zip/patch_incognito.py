import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target1 = """    fun updateIncognitoMode(incognito: Boolean) {
        isIncognito = incognito
        if (incognito) {
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            android.webkit.CookieManager.getInstance().flush()
            android.webkit.WebStorage.getInstance().deleteAllData()
        }
        webViews.values.forEach { view ->
            if (incognito) {
                view.clearCache(true)
                view.clearHistory()
            }
            view.settings.domStorageEnabled = !incognito
            view.settings.databaseEnabled = !incognito
            android.webkit.CookieManager.getInstance().setAcceptCookie(!incognito)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(view, !incognito)
        }
    }"""

replacement1 = """    fun updateIncognitoMode(incognito: Boolean) {
        if (isIncognito != incognito) {
            // Nuke all cookies and data when switching between modes to prevent session leakage
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            android.webkit.CookieManager.getInstance().flush()
            android.webkit.WebStorage.getInstance().deleteAllData()
            webViews.values.forEach { view ->
                view.clearCache(true)
                view.clearHistory()
            }
        }
        isIncognito = incognito
        
        webViews.values.forEach { view ->
            view.settings.domStorageEnabled = !incognito
            view.settings.databaseEnabled = !incognito
            // Cookies must always be accepted so websites function, 
            // but we rely on clearing them when toggling the mode.
            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        }
    }"""

target2 = """            android.webkit.CookieManager.getInstance().setAcceptCookie(!this@BrowserManager.isIncognito)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, !this@BrowserManager.isIncognito)"""

replacement2 = """            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)"""

if target1 in content:
    content = content.replace(target1, replacement1)
    print("Replaced updateIncognitoMode")
else:
    print("Could not find target1")

if target2 in content:
    content = content.replace(target2, replacement2)
    print("Replaced addTab cookie settings")
else:
    print("Could not find target2")
    
with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

