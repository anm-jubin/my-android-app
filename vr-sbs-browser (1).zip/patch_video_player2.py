import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target1 = """                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { (if (isRightHandMode) ipd else -ipd).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { verticalShift.toDp() }
                    )"""

replace1 = """                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { (verticalShift + gyroPitchOffset).toDp() }
                    )"""

content = content.replace(target1, replace1)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
