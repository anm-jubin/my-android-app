import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Decorate address bar
target_textfield = """                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions("""

replace_textfield = """                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Search or type URL", color = Color.Gray) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.DarkGray,
                                unfocusedContainerColor = Color.DarkGray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            keyboardOptions = KeyboardOptions("""
content = content.replace(target_textfield, replace_textfield)

# Add keepScreenOn to LaunchedEffect
target_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity, cameraIpd, cameraScale, cameraVerticalShift) {"""
replace_effect = """    androidx.compose.runtime.LaunchedEffect(keepScreenOn, isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity, cameraIpd, cameraScale, cameraVerticalShift) {"""
content = content.replace(target_effect, replace_effect)

target_prefs = """        prefs.edit()
            .putBoolean("isDesktopMode", isDesktopMode)"""
replace_prefs = """        prefs.edit()
            .putBoolean("keepScreenOn", keepScreenOn)
            .putBoolean("isDesktopMode", isDesktopMode)"""
content = content.replace(target_prefs, replace_prefs)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
