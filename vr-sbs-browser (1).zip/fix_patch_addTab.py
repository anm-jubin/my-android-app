import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {"""

replace = """    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            if (this@BrowserManager.isPassthroughEnabled) {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            } else {
                setBackgroundColor(android.graphics.Color.WHITE)
            }
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
