import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                            .offset(
                                x = with(density) { (if (isRightHandMode) ipd else -ipd).toDp() },
                                y = with(density) { verticalShift.toDp() }
                            )
                    )
                }
            }"""

replace = """            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode,
                    gyroYawOffset = gyroYawOffset,
                    gyroPitchOffset = gyroPitchOffset
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                            .offset(
                                x = with(density) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                                y = with(density) { (verticalShift + gyroPitchOffset).toDp() }
                            )
                    )
                }
            }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
