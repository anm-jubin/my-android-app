import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    BoxWithConstraints(modifier = modifier.fillMaxSize().background(if (cameraPassthroughEnabled) Color.Transparent else Color.Black)) {
        if (cameraPassthroughEnabled) {
            CameraPassthroughLayer()
        }
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        // Wrapper for the lens distortion, so it only distorts the content, not the UI!
        Box(modifier = Modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f).alpha(contentOpacity)) {
        // The single WebView container, drawn twice using Compose rendering!
        // Using graphicsLayer maps the affine transform (scale/translate) natively to the View layer,
        // which perfectly fixes the touch mapping offsets when scaling or shifting the IPD.
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye (shifted to the opposite lens)
                    drawContext.canvas.save()
                    val distance = if (isRightHandMode) {
                        -size.width - 2 * ipd
                    } else {
                        size.width + 2 * ipd
                    }
                    drawContext.canvas.translate(distance, 0f)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode,
                    gyroYawOffset = gyroYawOffset,
                    gyroPitchOffset = gyroPitchOffset
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .offset(
                                x = with(density) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                                y = with(density) { (verticalShift + gyroPitchOffset).toDp() }
                            )
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                }
            }
        }
        } // Close distortion wrapper"""

replacement = """    BoxWithConstraints(modifier = modifier.fillMaxSize().background(if (cameraPassthroughEnabled) Color.Transparent else Color.Black)) {
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = ipd,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {
                CameraPassthroughLayer()
            }
        }

        // Wrapper for the lens distortion, so it only distorts the content, not the UI!
        VrSplitScreenWrapper(
            isRightHandMode = isRightHandMode,
            ipd = ipd,
            lensWrapping = lensWrapping,
            lensDistortion = lensDistortion,
            eyeWidth = eyeWidth,
            modifier = Modifier.alpha(contentOpacity)
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode,
                    gyroYawOffset = gyroYawOffset,
                    gyroPitchOffset = gyroPitchOffset
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .offset(
                                x = with(density) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                                y = with(density) { (verticalShift + gyroPitchOffset).toDp() }
                            )
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                }
            }
        } // Close distortion wrapper"""

if target in content:
    print("Match found, patching...")
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content.replace(target, replacement))
else:
    print("Match NOT found!")

