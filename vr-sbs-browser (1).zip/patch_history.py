import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add states for history
target_states = """    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }"""

replace_states = """    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }
    var historyEnabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("historyEnabled", true)) }
    var historyList by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf<List<Pair<String, String>>>((prefs.getString("historyList", "") ?: "").split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size >= 2) Pair(parts[0], parts[1]) else null
        }) 
    }
    var showHistoryList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }"""

content = content.replace(target_states, replace_states)

# Add saving prefs
target_prefs = """            .putString("searchEngine", searchEngine)"""
replace_prefs = """            .putString("searchEngine", searchEngine)
            .putBoolean("historyEnabled", historyEnabled)
            .putString("historyList", historyList.joinToString(",") { "${it.first}|${it.second}" })"""
content = content.replace(target_prefs, replace_prefs)

# Update effect dependencies
target_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity) {"""
replace_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList) {"""
content = content.replace(target_effect, replace_effect)

# In onUrlChanged, add to history if enabled
target_onurlchanged = """    androidx.compose.runtime.LaunchedEffect(Unit) {
        browserManager.onUrlChanged = { newUrl ->
            urlInput = newUrl
            currentUrl = newUrl
            tabs = tabs.map { if (it.id == activeTabId) it.copy(url = newUrl) else it }
        }"""
replace_onurlchanged = """    androidx.compose.runtime.LaunchedEffect(Unit) {
        browserManager.onUrlChanged = { newUrl ->
            urlInput = newUrl
            currentUrl = newUrl
            tabs = tabs.map { if (it.id == activeTabId) it.copy(url = newUrl) else it }
            if (historyEnabled) {
                val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(newUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                // prevent consecutive duplicates
                if (historyList.isEmpty() || historyList.first().second != newUrl) {
                    historyList = listOf(Pair(title, newUrl)) + historyList
                    if (historyList.size > 100) {
                        historyList = historyList.take(100)
                    }
                }
            }
        }"""
content = content.replace(target_onurlchanged, replace_onurlchanged)


with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
