import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace('"Default"', 'androidx.webkit.Profile.DEFAULT_PROFILE_NAME')

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
