import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }"""

replace = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Incognito Mode", color = if (isIncognito) Color.Cyan else Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(
                                    checked = isIncognito, 
                                    onCheckedChange = { 
                                        isIncognito = it 
                                        browserManager.setIncognito(it)
                                    }
                                )
                            }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
