import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    val browserManager = androidx.compose.runtime.remember { 
        BrowserManager(context).apply {
            tabs.forEach { addTab(it.id, it.url, isDesktopMode) }
            this.activeTabId = activeTabId
        }
    }"""

replace = """    val browserManager = androidx.compose.runtime.remember { 
        BrowserManager(context).apply {
            this.setIncognito(isIncognito)
            tabs.forEach { addTab(it.id, it.url, isDesktopMode) }
            this.activeTabId = activeTabId
        }
    }"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
