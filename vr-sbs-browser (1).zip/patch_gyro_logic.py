import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    var localVideoUri by remember { mutableStateOf<Uri?>(null) }"""
replace = """
    // Gyroscope Setup
    val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
    androidx.compose.runtime.DisposableEffect(gyroEnabled, shouldRecenter) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
        val rotationSensor = sensorManager.getDefaultSensor(android.hardware.Sensor.TYPE_GAME_ROTATION_VECTOR)
        
        val listener = object : android.hardware.SensorEventListener {
            override fun onSensorChanged(event: android.hardware.SensorEvent) {
                if (event.sensor.type == android.hardware.Sensor.TYPE_GAME_ROTATION_VECTOR) {
                    val rotationMatrix = FloatArray(9)
                    android.hardware.SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    
                    val remappedMatrix = FloatArray(9)
                    when (windowManager.defaultDisplay.rotation) {
                        android.view.Surface.ROTATION_90 -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_Y, android.hardware.SensorManager.AXIS_MINUS_X, remappedMatrix)
                        android.view.Surface.ROTATION_270 -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_MINUS_Y, android.hardware.SensorManager.AXIS_X, remappedMatrix)
                        android.view.Surface.ROTATION_180 -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_MINUS_X, android.hardware.SensorManager.AXIS_MINUS_Y, remappedMatrix)
                        else -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_X, android.hardware.SensorManager.AXIS_Y, remappedMatrix)
                    }
                    
                    val orientation = FloatArray(3)
                    android.hardware.SensorManager.getOrientation(remappedMatrix, orientation)
                    
                    if (shouldRecenter) {
                        baseOrientation = orientation.clone()
                        shouldRecenter = false
                    }
                    currentOrientation = orientation.clone()
                }
            }
            override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
        }
        
        if (gyroEnabled && rotationSensor != null) {
            sensorManager.registerListener(listener, rotationSensor, android.hardware.SensorManager.SENSOR_DELAY_GAME)
        }
        
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }
    
    fun getAngleDiff(angle1: Float, angle2: Float): Float {
        var diff = angle1 - angle2
        while (diff < -Math.PI.toFloat()) diff += (2 * Math.PI).toFloat()
        while (diff > Math.PI.toFloat()) diff -= (2 * Math.PI).toFloat()
        return diff
    }
    
    val gyroYawOffset = if (gyroEnabled) getAngleDiff(currentOrientation[0], baseOrientation[0]) * -gyroSensitivity else 0f
    val gyroPitchOffset = if (gyroEnabled) getAngleDiff(currentOrientation[1], baseOrientation[1]) * gyroSensitivity else 0f

    var localVideoUri by remember { mutableStateOf<Uri?>(null) }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
