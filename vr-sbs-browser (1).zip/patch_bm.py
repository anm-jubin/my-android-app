import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add isIncognito to BrowserManager
target_bm = """class BrowserManager(val context: Context) {
    val container = android.widget.FrameLayout(context).apply {"""

replace_bm = """class BrowserManager(val context: Context) {
    var isIncognito: Boolean = false

    fun setIncognito(incognito: Boolean) {
        isIncognito = incognito
        if (incognito) {
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            android.webkit.CookieManager.getInstance().flush()
            android.webkit.WebStorage.getInstance().deleteAllData()
        }
        webViews.values.forEach { view ->
            if (incognito) {
                view.clearCache(true)
                view.clearHistory()
            }
            view.settings.domStorageEnabled = !incognito
            view.settings.databaseEnabled = !incognito
            android.webkit.CookieManager.getInstance().setAcceptCookie(!incognito)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(view, !incognito)
        }
    }

    val container = android.widget.FrameLayout(context).apply {"""
content = content.replace(target_bm, replace_bm)

# Use isIncognito in addTab
target_addTab = """                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true"""

replace_addTab = """                javaScriptEnabled = true
                domStorageEnabled = !this@BrowserManager.isIncognito
                databaseEnabled = !this@BrowserManager.isIncognito"""
content = content.replace(target_addTab, replace_addTab)

target_addTab_cookies = """            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)"""

replace_addTab_cookies = """            android.webkit.CookieManager.getInstance().setAcceptCookie(!this@BrowserManager.isIncognito)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, !this@BrowserManager.isIncognito)"""
content = content.replace(target_addTab_cookies, replace_addTab_cookies)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
