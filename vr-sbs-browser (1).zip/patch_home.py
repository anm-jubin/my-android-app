import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Change initial URL to about:blank
target_initial_url = """val freshTab = WebTab(newId, "https://m.youtube.com")"""
replace_initial_url = """val freshTab = WebTab(newId, "about:blank")"""
content = content.replace(target_initial_url, replace_initial_url)

target_initial_filter = """val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" }.take(2)"""
replace_initial_filter = """val filteredLoaded = loadedTabs.filter { it.url != "about:blank" }.take(2)"""
content = content.replace(target_initial_filter, replace_initial_filter)

target_initial_urlinput = """var urlInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.firstOrNull { it.id == activeTabId }?.url ?: "https://m.youtube.com") }"""
replace_initial_urlinput = """var urlInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.firstOrNull { it.id == activeTabId }?.url ?: "about:blank") }"""
content = content.replace(target_initial_urlinput, replace_initial_urlinput)

target_addtab = """val newTab = WebTab(newId, "https://m.youtube.com")
                                                tabs = listOf(newTab)
                                                browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)"""
replace_addtab = """val newTab = WebTab(newId, "about:blank")
                                                tabs = listOf(newTab)
                                                browserManager.addTab(newId, "about:blank", isDesktopMode)"""
content = content.replace(target_addtab, replace_addtab)

target_addtab2 = """val newTab = WebTab(newId, "https://m.youtube.com")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)"""
replace_addtab2 = """val newTab = WebTab(newId, "about:blank")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "about:blank", isDesktopMode)"""
content = content.replace(target_addtab2, replace_addtab2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
