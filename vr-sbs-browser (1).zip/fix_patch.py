import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

bad_snippet = """                                        if (this@BrowserManager.isPassthroughEnabled) {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            } else {
                setBackgroundColor(android.graphics.Color.WHITE)
            }
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {"""
good_snippet = """                                        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {"""

content = content.replace(bad_snippet, good_snippet)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
