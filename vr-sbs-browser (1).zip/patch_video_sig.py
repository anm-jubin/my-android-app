import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    modifier: Modifier = Modifier
) {"""

replace = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    gyroYawOffset: Float = 0f,
    gyroPitchOffset: Float = 0f,
    modifier: Modifier = Modifier
) {"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
