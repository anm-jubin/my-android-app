import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

target = "  implementation(libs.androidx.camera.view)"
replace = "  implementation(libs.androidx.camera.view)\n  implementation(\"androidx.webkit:webkit:1.11.0\")"
content = content.replace(target, replace)

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
