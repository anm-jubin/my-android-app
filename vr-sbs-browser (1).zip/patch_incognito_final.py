import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target1 = """    fun updateIncognitoMode(incognito: Boolean) {
        if (isIncognito != incognito) {
            // Nuke all cookies and data when switching between modes to prevent session leakage
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            android.webkit.CookieManager.getInstance().flush()
            android.webkit.WebStorage.getInstance().deleteAllData()
            webViews.values.forEach { view ->
                view.clearCache(true)
                view.clearHistory()
            }
        }
        isIncognito = incognito
        
        webViews.values.forEach { view ->
            view.settings.domStorageEnabled = !incognito
            view.settings.databaseEnabled = !incognito
            // Cookies must always be accepted so websites function, 
            // but we rely on clearing them when toggling the mode.
            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        }
    }"""

replacement1 = """    fun updateIncognitoMode(incognito: Boolean) {
        val didChange = isIncognito != incognito
        isIncognito = incognito
        
        if (didChange) {
            // Re-create all tabs to apply the new profile!
            val oldTabs = webViews.keys.toList()
            oldTabs.forEach { tabId ->
                val webView = webViews[tabId]
                val currentUrl = webView?.url ?: webView?.originalUrl ?: "about:blank"
                container.removeView(webView)
                webViews.remove(tabId)
                webView?.destroy()
                
                // Re-add tab which will now check the new isIncognito state and set Profile
                addTab(tabId, currentUrl, true) // Wait, isDesktopMode is hard to fetch here... we'll assume true or we can just let it reload the page.
            }
            // activeTabId setter will update visibility
            val oldActive = activeTabId
            activeTabId = oldActive
        }
    }"""

content = content.replace(target1, replacement1)

target_addTab = """    @SuppressLint("SetJavaScriptEnabled")
    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {"""
replace_addTab = """    @SuppressLint("SetJavaScriptEnabled")
    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val profileStore = androidx.webkit.ProfileStore.getInstance()
                if (this@BrowserManager.isIncognito) {
                    val profile = profileStore.getOrCreateProfile("incognito")
                    androidx.webkit.WebViewCompat.setProfile(this, profile.name)
                } else {
                    val profile = profileStore.getOrCreateProfile("Default") // or ProfileStore.getInstance().getProfile("Default")
                    androidx.webkit.WebViewCompat.setProfile(this, "Default")
                }
            }
"""
content = content.replace(target_addTab, replace_addTab)

target_cookies = """            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)"""
replace_cookies = """            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val cookieManager = androidx.webkit.WebViewCompat.getProfile(this).cookieManager
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(this, true)
            } else {
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            }"""
content = content.replace(target_cookies, replace_cookies)

target_clear = """                                        android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                        android.webkit.CookieManager.getInstance().flush()"""
replace_clear = """                                        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                                            val profileName = if (isIncognito) "incognito" else "Default"
                                            val cookieManager = androidx.webkit.ProfileStore.getInstance().getProfile(profileName)?.cookieManager
                                            cookieManager?.removeAllCookies(null)
                                            cookieManager?.flush()
                                        } else {
                                            android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                            android.webkit.CookieManager.getInstance().flush()
                                        }"""
content = content.replace(target_clear, replace_clear)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
