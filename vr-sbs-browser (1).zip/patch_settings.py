import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                        Column(modifier = Modifier.padding(8.dp).verticalScroll(rememberScrollState())) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Right-Hand Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isRightHandMode, onCheckedChange = { isRightHandMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Incognito Mode", color = if (isIncognito) Color.Cyan else Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(
                                    checked = isIncognito, 
                                    onCheckedChange = { 
                                        isIncognito = it 
                                        browserManager.updateIncognitoMode(it)
                                    }
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text("Search Engine", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                var engineExpanded by remember { mutableStateOf(false) }
                                Box {
                                    androidx.compose.material3.TextButton(onClick = { engineExpanded = true }) {
                                        Text(searchEngine, color = Color.Cyan)
                                    }
                                    DropdownMenu(
                                        expanded = engineExpanded,
                                        onDismissRequest = { engineExpanded = false }
                                    ) {
                                        DropdownMenuItem(text = { Text("Google") }, onClick = { searchEngine = "Google"; engineExpanded = false })
                                        DropdownMenuItem(text = { Text("Bing") }, onClick = { searchEngine = "Bing"; engineExpanded = false })
                                        DropdownMenuItem(text = { Text("DuckDuckGo") }, onClick = { searchEngine = "DuckDuckGo"; engineExpanded = false })
                                    }
                                }
                            }
                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = scale,
                                onValueChange = { scale = it },
                                valueRange = 0.1f..3.0f
                            )
                            if (android.os.Build.VERSION.SDK_INT >= 33) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                                }
                                if (lensWrapping) {
                                    Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = lensDistortion,
                                        onValueChange = { lensDistortion = it },
                                        valueRange = 0.0f..1.5f
                                    )
                                }
                            } else {
                                Text("Lens Wrapping requires Android 13+", color = Color.Red.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 4.dp))
                            }
                            Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = ipd,
                                onValueChange = { ipd = it },
                                valueRange = -500f..500f
                            )
                            Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = verticalShift,
                                onValueChange = { verticalShift = it },
                                valueRange = -1000f..1000f
                            )
                            
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Camera Passthrough", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = cameraPassthroughEnabled, onCheckedChange = { cameraPassthroughEnabled = it })
                            }
                            if (cameraPassthroughEnabled) {
                                Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = contentOpacity,
                                    onValueChange = { contentOpacity = it },
                                    valueRange = 0.1f..1.0f
                                )
                                Text("Camera IPD", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cameraIpd,
                                    onValueChange = { cameraIpd = it },
                                    valueRange = -200f..200f
                                )
                                Text("Camera Scale", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cameraScale,
                                    onValueChange = { cameraScale = it },
                                    valueRange = 0.5f..2.5f
                                )
                                Text("Camera Vertical", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = cameraVerticalShift,
                                    onValueChange = { cameraVerticalShift = it },
                                    valueRange = -300f..300f
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Gyroscope Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = gyroEnabled, onCheckedChange = { 
                                    gyroEnabled = it 
                                    if (it) shouldRecenter = true
                                })
                            }
                            if (gyroEnabled) {
                                Text("Gyro Sensitivity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = gyroSensitivity,
                                    onValueChange = { gyroSensitivity = it },
                                    valueRange = 500f..3000f
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    scale = 1f
                                    ipd = 0f
                                    verticalShift = 0f
                                    isRightHandMode = true
                                    isDesktopMode = true
                                    lensWrapping = true
                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                    gyroEnabled = false
                                    gyroSensitivity = 1500f
                                    shouldRecenter = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                            ) {
                                Text("Reset View Settings", color = Color.White)
                            }"""

replacement = """                        Column(modifier = Modifier.padding(8.dp).verticalScroll(rememberScrollState())) {
                            SettingsSection("Browser & System") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Right-Hand Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = isRightHandMode, onCheckedChange = { isRightHandMode = it })
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Incognito Mode", color = if (isIncognito) Color.Cyan else Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(
                                        checked = isIncognito, 
                                        onCheckedChange = { 
                                            isIncognito = it 
                                            browserManager.updateIncognitoMode(it)
                                        }
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Text("Search Engine", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    var engineExpanded by remember { mutableStateOf(false) }
                                    Box {
                                        androidx.compose.material3.TextButton(onClick = { engineExpanded = true }) {
                                            Text(searchEngine, color = Color.Cyan)
                                        }
                                        DropdownMenu(
                                            expanded = engineExpanded,
                                            onDismissRequest = { engineExpanded = false }
                                        ) {
                                            DropdownMenuItem(text = { Text("Google") }, onClick = { searchEngine = "Google"; engineExpanded = false })
                                            DropdownMenuItem(text = { Text("Bing") }, onClick = { searchEngine = "Bing"; engineExpanded = false })
                                            DropdownMenuItem(text = { Text("DuckDuckGo") }, onClick = { searchEngine = "DuckDuckGo"; engineExpanded = false })
                                        }
                                    }
                                }
                            }
                            
                            SettingsSection("Virtual Screen") {
                                Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = scale,
                                    onValueChange = { scale = it },
                                    valueRange = 0.1f..3.0f
                                )
                                Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = ipd,
                                    onValueChange = { ipd = it },
                                    valueRange = -500f..500f
                                )
                                Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = verticalShift,
                                    onValueChange = { verticalShift = it },
                                    valueRange = -1000f..1000f
                                )
                                if (android.os.Build.VERSION.SDK_INT >= 33) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                        Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                                    }
                                    if (lensWrapping) {
                                        Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                        Slider(
                                            value = lensDistortion,
                                            onValueChange = { lensDistortion = it },
                                            valueRange = 0.0f..1.5f
                                        )
                                    }
                                } else {
                                    Text("Lens Wrapping requires Android 13+", color = Color.Red.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 4.dp))
                                }
                            }
                            
                            SettingsSection("Camera Passthrough") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Enable Passthrough", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = cameraPassthroughEnabled, onCheckedChange = { cameraPassthroughEnabled = it })
                                }
                                if (cameraPassthroughEnabled) {
                                    Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = contentOpacity,
                                        onValueChange = { contentOpacity = it },
                                        valueRange = 0.1f..1.0f
                                    )
                                    Text("Camera IPD", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = cameraIpd,
                                        onValueChange = { cameraIpd = it },
                                        valueRange = -200f..200f
                                    )
                                    Text("Camera Scale", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = cameraScale,
                                        onValueChange = { cameraScale = it },
                                        valueRange = 0.5f..2.5f
                                    )
                                    Text("Camera Vertical", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = cameraVerticalShift,
                                        onValueChange = { cameraVerticalShift = it },
                                        valueRange = -300f..300f
                                    )
                                }
                            }
                            
                            SettingsSection("Gyroscope") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Enable Head Tracking", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = gyroEnabled, onCheckedChange = { 
                                        gyroEnabled = it 
                                        if (it) shouldRecenter = true
                                    })
                                }
                                if (gyroEnabled) {
                                    Text("Gyro Sensitivity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = gyroSensitivity,
                                        onValueChange = { gyroSensitivity = it },
                                        valueRange = 500f..3000f
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    scale = 1f
                                    ipd = 0f
                                    verticalShift = 0f
                                    isRightHandMode = true
                                    isDesktopMode = true
                                    lensWrapping = true
                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                    gyroEnabled = false
                                    gyroSensitivity = 1500f
                                    shouldRecenter = true
                                    
                                    cameraIpd = 0f
                                    cameraScale = 1f
                                    cameraVerticalShift = 0f
                                    contentOpacity = 1f
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                            ) {
                                Text("Reset View Settings", color = Color.White)
                            }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced settings UI")
else:
    print("Could not find target settings string")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

