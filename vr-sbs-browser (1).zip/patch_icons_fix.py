import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Revert my bad patch
content = content.replace("androidx.compose.material.icons.filled.Search", "Icons.Default.Search")
content = content.replace("androidx.compose.material.icons.filled.Menu", "Icons.Default.Menu")
content = content.replace("androidx.compose.material.icons.filled.Info", "Icons.Default.Info")
content = content.replace("androidx.compose.material.icons.filled.PlayArrow", "Icons.Default.PlayArrow")

# Add the imports at the top
imports = """import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import android.os.Bundle"""
content = content.replace("import android.os.Bundle", imports)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
