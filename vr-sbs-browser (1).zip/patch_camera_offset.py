import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = ipd,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {
                CameraPassthroughLayer()
            }
        }"""

replacement = """        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = ipd,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {
                CameraPassthroughLayer(
                    modifier = Modifier.offset(x = with(density) { (if (isRightHandMode) ipd else -ipd).toDp() })
                )
            }
        }"""

if target in content:
    print("Match found, patching...")
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content.replace(target, replacement))
else:
    print("Match NOT found!")

