import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("fun setIncognito(incognito: Boolean)", "fun updateIncognitoMode(incognito: Boolean)")
content = content.replace("browserManager.setIncognito(it)", "browserManager.updateIncognitoMode(it)")
content = content.replace("this.setIncognito(isIncognito)", "this.updateIncognitoMode(isIncognito)")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
