import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    val activeEyeIpdOffset = if (isRightHandMode) ipd else -ipd
                    drawContext.canvas.translate(activeEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye
                    drawContext.canvas.save()
                    val mirrorEyeIpdOffset = if (isRightHandMode) -ipd else ipd
                    val baseDistance = if (isRightHandMode) -size.width else size.width
                    drawContext.canvas.translate(baseDistance + mirrorEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()"""

replacement = """                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    val activeEyeIpdOffset = if (isRightHandMode) ipd else -ipd
                    drawContext.canvas.translate(activeEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    val mirrorEyeIpdOffset = if (isRightHandMode) -ipd else ipd
                    val baseDistance = if (isRightHandMode) -size.width else size.width
                    drawContext.canvas.translate(baseDistance + mirrorEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContent()
                    drawContext.canvas.restore()"""

content = content.replace(target, replacement)
with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
