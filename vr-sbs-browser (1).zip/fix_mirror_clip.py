import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                    // 2. Draw Mirror Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    val mirrorEyeIpdOffset = if (isRightHandMode) -ipd else ipd
                    val baseDistance = if (isRightHandMode) -size.width else size.width
                    drawContext.canvas.translate(baseDistance + mirrorEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContent()
                    drawContext.canvas.restore()"""

replacement = """                    // 2. Draw Mirror Eye
                    drawContext.canvas.save()
                    val baseDistance = if (isRightHandMode) -size.width else size.width
                    drawContext.canvas.translate(baseDistance, 0f) // Shift canvas to the physical location of the other eye
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height) // Clip it to that physical location
                    val mirrorEyeIpdOffset = if (isRightHandMode) -ipd else ipd
                    drawContext.canvas.translate(mirrorEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset) // Shift the content inside the clip
                    drawContent()
                    drawContext.canvas.restore()"""

if target in content:
    content = content.replace(target, replacement)
    print("Fixed mirror clip")
else:
    print("Not found mirror clip")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
