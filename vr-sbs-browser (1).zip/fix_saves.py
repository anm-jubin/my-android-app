import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """            .putFloat("contentOpacity", contentOpacity)"""
replacement = """            .putFloat("contentOpacity", contentOpacity)
            .putFloat("cameraIpd", cameraIpd)
            .putFloat("cameraScale", cameraScale)
            .putFloat("cameraVerticalShift", cameraVerticalShift)"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

