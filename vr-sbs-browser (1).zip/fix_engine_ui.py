import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)"""

replace = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                Text("Search Engine", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                var engineExpanded by remember { mutableStateOf(false) }
                                Box {
                                    androidx.compose.material3.TextButton(onClick = { engineExpanded = true }) {
                                        Text(searchEngine, color = Color.Cyan)
                                    }
                                    DropdownMenu(
                                        expanded = engineExpanded,
                                        onDismissRequest = { engineExpanded = false }
                                    ) {
                                        DropdownMenuItem(text = { Text("Google") }, onClick = { searchEngine = "Google"; engineExpanded = false })
                                        DropdownMenuItem(text = { Text("Bing") }, onClick = { searchEngine = "Bing"; engineExpanded = false })
                                        DropdownMenuItem(text = { Text("DuckDuckGo") }, onClick = { searchEngine = "DuckDuckGo"; engineExpanded = false })
                                    }
                                }
                            }
                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
