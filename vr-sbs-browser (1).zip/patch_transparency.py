import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

bm_start = "class BrowserManager(val context: Context) {"
bm_replace = """class BrowserManager(val context: Context) {
    var isPassthroughEnabled: Boolean = false
    fun updatePassthrough(enabled: Boolean) {
        isPassthroughEnabled = enabled
        webViews.values.forEach { view ->
            if (enabled) {
                view.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
            } else {
                view.setBackgroundColor(android.graphics.Color.WHITE)
                view.evaluateJavascript("document.body.style.backgroundColor = ''; document.documentElement.style.backgroundColor = '';", null)
            }
        }
    }"""
content = content.replace(bm_start, bm_replace)

tab_create = """            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {"""
tab_create_replace = """            if (this@BrowserManager.isPassthroughEnabled) {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            } else {
                setBackgroundColor(android.graphics.Color.WHITE)
            }
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {"""
content = content.replace(tab_create, tab_create_replace)

page_finished = """                override fun onPageFinished(view: WebView, url: String) {
                    if (id == activeTabId) {"""
page_finished_replace = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    if (id == activeTabId) {"""
content = content.replace(page_finished, page_finished_replace)

effect_target = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode) {
        browserManager.updateDesktopMode(isDesktopMode)
    }"""
effect_replace = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode) {
        browserManager.updateDesktopMode(isDesktopMode)
    }
    androidx.compose.runtime.LaunchedEffect(cameraPassthroughEnabled) {
        browserManager.updatePassthrough(cameraPassthroughEnabled)
    }"""
content = content.replace(effect_target, effect_replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
