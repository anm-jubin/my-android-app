import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add states
target_states = """    var gyroSensitivity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("gyroSensitivity", 1500f)) }"""
replace_states = """    var gyroSensitivity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("gyroSensitivity", 1500f)) }
    
    var cameraPassthroughEnabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("cameraPassthroughEnabled", false)) }
    var contentOpacity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("contentOpacity", 1.0f)) }"""
content = content.replace(target_states, replace_states)

# Add LaunchedEffect args
target_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito) {"""
replace_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity) {"""
content = content.replace(target_effect, replace_effect)

# Add save prefs
target_prefs = """            .putBoolean("isIncognito", isIncognito)"""
replace_prefs = """            .putBoolean("isIncognito", isIncognito)
            .putBoolean("cameraPassthroughEnabled", cameraPassthroughEnabled)
            .putFloat("contentOpacity", contentOpacity)"""
content = content.replace(target_prefs, replace_prefs)

# Add UI controls
target_ui = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Gyroscope Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)"""
replace_ui = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Camera Passthrough", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = cameraPassthroughEnabled, onCheckedChange = { cameraPassthroughEnabled = it })
                            }
                            if (cameraPassthroughEnabled) {
                                Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = contentOpacity,
                                    onValueChange = { contentOpacity = it },
                                    valueRange = 0.1f..1.0f
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Gyroscope Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)"""
content = content.replace(target_ui, replace_ui)

# Box modifier and alpha
target_box = """    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        // Wrapper for the lens distortion, so it only distorts the content, not the UI!
        Box(modifier = Modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {"""
replace_box = """    BoxWithConstraints(modifier = modifier.fillMaxSize().background(if (cameraPassthroughEnabled) Color.Transparent else Color.Black)) {
        if (cameraPassthroughEnabled) {
            CameraPassthroughLayer()
        }
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        // Wrapper for the lens distortion, so it only distorts the content, not the UI!
        Box(modifier = Modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f).alpha(contentOpacity)) {"""
content = content.replace(target_box, replace_box)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
