import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                                if (bookmarks.isEmpty()) {
                                    item {
                                        Text("No bookmarks yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }"""

replace = """                                if (bookmarks.isEmpty()) {
                                    item {
                                        Text("No bookmarks yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                if (showHistoryList) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("History", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Record", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Switch(checked = historyEnabled, onCheckedChange = { historyEnabled = it })
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (historyList.isNotEmpty()) {
                                        androidx.compose.material3.TextButton(onClick = { historyList = emptyList() }) {
                                            Text("Clear All", color = Color.Red.copy(alpha = 0.8f))
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(historyList) { historyItem ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                                            urlInput = historyItem.second
                                            currentUrl = historyItem.second
                                            browserManager.loadUrlInActiveTab(historyItem.second)
                                            localVideoUri = null
                                            isUiVisible = false
                                        },
                                        color = Color.White.copy(alpha = 0.1f),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(historyItem.first, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                                Text(historyItem.second, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                            }
                                            IconButton(onClick = { historyList = historyList.filter { it != historyItem } }) {
                                                Icon(Icons.Default.Clear, "Remove", tint = Color.White)
                                            }
                                        }
                                    }
                                }
                                if (historyList.isEmpty()) {
                                    item {
                                        Text(if (historyEnabled) "No history yet." else "History is disabled.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
