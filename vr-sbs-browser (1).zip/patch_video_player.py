import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target1 = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    modifier: Modifier = Modifier
) {"""
replace1 = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    gyroYawOffset: Float = 0f,
    gyroPitchOffset: Float = 0f,
    modifier: Modifier = Modifier
) {"""
content = content.replace(target1, replace1)

# Find offset in TextureVideoPlayer
target2 = """            AndroidView(
                factory = { ctx ->
                    TextureView(ctx).apply {
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                                val s = Surface(surface)
                                val mp = MediaPlayer().apply {
                                    setDataSource(context, uri)
                                    setSurface(s)
                                    prepareAsync()
                                    setOnPreparedListener { 
                                        it.start()
                                        duration = it.duration
                                    }
                                }
                                mediaPlayer = mp
                            }
                            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                                mediaPlayer?.release()
                                mediaPlayer = null
                                return true
                            }
                            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .offset(
                        x = with(LocalDensity.current) { (if (isRightHandMode) ipd else -ipd).toDp() },
                        y = with(LocalDensity.current) { verticalShift.toDp() }
                    )
            )"""

replace2 = """            AndroidView(
                factory = { ctx ->
                    TextureView(ctx).apply {
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                                val s = Surface(surface)
                                val mp = MediaPlayer().apply {
                                    setDataSource(context, uri)
                                    setSurface(s)
                                    prepareAsync()
                                    setOnPreparedListener { 
                                        it.start()
                                        duration = it.duration
                                    }
                                }
                                mediaPlayer = mp
                            }
                            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                                mediaPlayer?.release()
                                mediaPlayer = null
                                return true
                            }
                            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .offset(
                        x = with(LocalDensity.current) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                        y = with(LocalDensity.current) { (verticalShift + gyroPitchOffset).toDp() }
                    )
            )"""

if target2 in content:
    content = content.replace(target2, replace2)
else:
    print("TextureVideoPlayer offset not found")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
