import re

with open("app/build.gradle.kts", "r") as f:
    content = f.read()

content = content.replace('implementation("androidx.webkit:webkit:1.11.0")', 'implementation("androidx.webkit:webkit:1.17.0")')

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
