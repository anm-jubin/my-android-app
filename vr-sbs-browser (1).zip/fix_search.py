import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add search engine state
state_target = """    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }"""
state_replace = """    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }"""
content = content.replace(state_target, state_replace)

# Add save searchEngine
save_target = """            .putFloat("lensDistortion", lensDistortion)"""
save_replace = """            .putFloat("lensDistortion", lensDistortion)
            .putString("searchEngine", searchEngine)"""
content = content.replace(save_target, save_replace)

# Add to LaunchedEffect dependencies
effect_target = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks) {"""
effect_replace = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine) {"""
content = content.replace(effect_target, effect_replace)

# Helper function before address bar
helper_target = """                // Address Bar"""
helper_replace = """                fun processInput(input: String): String {
                    val trimmed = input.trim()
                    if (trimmed.isEmpty()) return "https://www.google.com"
                    val isUrl = !trimmed.contains(" ") && (trimmed.contains(".") || trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("localhost"))
                    if (isUrl) {
                        return if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) "https://$trimmed" else trimmed
                    } else {
                        val encoded = java.net.URLEncoder.encode(trimmed, "UTF-8")
                        return when (searchEngine) {
                            "Bing" -> "https://www.bing.com/search?q=$encoded"
                            "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
                            else -> "https://www.google.com/search?q=$encoded"
                        }
                    }
                }

                // Address Bar"""
content = content.replace(helper_target, helper_replace)

# Update onGo logic
ongo_target = """                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )"""
ongo_replace = """                            keyboardActions = KeyboardActions(
                                onGo = {
                                    val finalUrl = processInput(urlInput)
                                    currentUrl = finalUrl
                                    urlInput = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )"""
content = content.replace(ongo_target, ongo_replace)

# Update Go button logic
btn_target = """                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            browserManager.loadUrlInActiveTab(finalUrl)
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }"""
btn_replace = """                        IconButton(onClick = { 
                            val finalUrl = processInput(urlInput)
                            currentUrl = finalUrl
                            urlInput = finalUrl
                            browserManager.loadUrlInActiveTab(finalUrl)
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }"""
content = content.replace(btn_target, btn_replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
