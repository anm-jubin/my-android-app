import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add states
target_states = """    var lensDistortion by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("lensDistortion", 0.1f)) }"""
replace_states = """    var lensDistortion by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("lensDistortion", 0.1f)) }
    
    var gyroEnabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("gyroEnabled", false)) }
    var shouldRecenter by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var baseOrientation by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }
    var currentOrientation by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }
    var gyroSensitivity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("gyroSensitivity", 1500f)) }"""
content = content.replace(target_states, replace_states)

# Add save prefs
target_prefs = """            .putFloat("lensDistortion", lensDistortion)
            .putString("searchEngine", searchEngine)"""
replace_prefs = """            .putFloat("lensDistortion", lensDistortion)
            .putString("searchEngine", searchEngine)
            .putBoolean("gyroEnabled", gyroEnabled)
            .putFloat("gyroSensitivity", gyroSensitivity)"""
content = content.replace(target_prefs, replace_prefs)

target_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine) {"""
replace_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity) {"""
content = content.replace(target_effect, replace_effect)


with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
