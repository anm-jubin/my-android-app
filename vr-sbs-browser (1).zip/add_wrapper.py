with open("app/src/main/java/com/example/MainActivity.kt", "a") as f:
    f.write("""

@Composable
fun VrSplitScreenWrapper(
    isRightHandMode: Boolean,
    ipd: Float,
    lensWrapping: Boolean,
    lensDistortion: Float,
    eyeWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    drawContext.canvas.save()
                    val distance = if (isRightHandMode) {
                        -size.width - 2 * ipd
                    } else {
                        size.width + 2 * ipd
                    }
                    drawContext.canvas.translate(distance, 0f)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            content()
        }
    }
}
""")
