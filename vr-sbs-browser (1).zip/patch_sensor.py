import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_states = """    var baseOrientation by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }
    var currentOrientation by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }"""

replace_states = """    var baseRotationMatrix by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(9) { if (it % 4 == 0) 1f else 0f }) }
    var currentAngleChange by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }"""

content = content.replace(target_states, replace_states)

target_listener = """                    val orientation = FloatArray(3)
                    android.hardware.SensorManager.getOrientation(remappedMatrix, orientation)
                    
                    if (shouldRecenter) {
                        baseOrientation = orientation.clone()
                        shouldRecenter = false
                    }
                    currentOrientation = orientation.clone()"""

replace_listener = """                    if (shouldRecenter) {
                        baseRotationMatrix = remappedMatrix.clone()
                        shouldRecenter = false
                    }
                    
                    val angleChange = FloatArray(3)
                    android.hardware.SensorManager.getAngleChange(angleChange, remappedMatrix, baseRotationMatrix)
                    currentAngleChange = angleChange.clone()"""

content = content.replace(target_listener, replace_listener)


target_offsets = """    fun getAngleDiff(angle1: Float, angle2: Float): Float {
        var diff = angle1 - angle2
        while (diff < -Math.PI.toFloat()) diff += (2 * Math.PI).toFloat()
        while (diff > Math.PI.toFloat()) diff -= (2 * Math.PI).toFloat()
        return diff
    }
    
    val gyroYawOffset = if (gyroEnabled) getAngleDiff(currentOrientation[0], baseOrientation[0]) * (gyroSensitivity * 1.5f) else 0f
    val gyroPitchOffset = if (gyroEnabled) getAngleDiff(currentOrientation[1], baseOrientation[1]) * -gyroSensitivity else 0f"""

replace_offsets = """    // getAngleChange indices: 0 = Z (Roll), 1 = X (Pitch), 2 = Y (Yaw)
    // We invert Yaw because turning head right (positive Y rotation) should move the screen left (negative offset)
    val gyroYawOffset = if (gyroEnabled) currentAngleChange[2] * -(gyroSensitivity * 1.5f) else 0f
    val gyroPitchOffset = if (gyroEnabled) currentAngleChange[1] * -gyroSensitivity else 0f"""

content = content.replace(target_offsets, replace_offsets)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
