import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Insert the New Tab Page overlay
target_androidview = """                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                }"""

replace_androidview = """                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                    if (currentUrl == "about:blank" || currentUrl.isEmpty()) {
                        NewTabPage(
                            isPassthroughEnabled = cameraPassthroughEnabled,
                            onSearch = { query ->
                                val finalUrl = processInput(query)
                                currentUrl = finalUrl
                                urlInput = finalUrl
                                browserManager.loadUrlInActiveTab(finalUrl)
                                localVideoUri = null
                                isUiVisible = false
                            }
                        )
                    }
                }"""
content = content.replace(target_androidview, replace_androidview)

# Append NewTabPage composables at the end of the file
newtab_composable = """
@Composable
fun NewTabPage(
    isPassthroughEnabled: Boolean,
    onSearch: (String) -> Unit
) {
    var searchInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isPassthroughEnabled) Color.Transparent else Color.Black),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.layout.Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp).widthIn(max = 600.dp)
        ) {
            Text(
                "VR Browser", 
                color = Color.White, 
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(bottom = 32.dp)
            )
            
            // Search Box
            TextField(
                value = searchInput,
                onValueChange = { searchInput = it },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                placeholder = { Text("Search or type URL", color = Color.Gray) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { onSearch(searchInput) })
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Shortcuts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ShortcutIcon("YouTube", Icons.Default.PlayArrow, Color.Red) { onSearch("https://m.youtube.com") }
                ShortcutIcon("Google", Icons.Default.Search, Color.Blue) { onSearch("https://www.google.com") }
                ShortcutIcon("Reddit", Icons.Default.Menu, Color(0xFFFF4500)) { onSearch("https://www.reddit.com") }
                ShortcutIcon("Wikipedia", Icons.Default.Info, Color.Gray) { onSearch("https://www.wikipedia.org") }
            }
        }
    }
}

@Composable
fun ShortcutIcon(name: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.FloatingActionButton(
            onClick = onClick,
            containerColor = Color.White,
            contentColor = color,
            modifier = Modifier.size(64.dp)
        ) {
            Icon(icon, contentDescription = name, modifier = Modifier.size(32.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(name, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}
"""
content = content + newtab_composable

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
