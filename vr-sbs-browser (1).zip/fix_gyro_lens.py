import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix gyro inversion and sensitivity
target_gyro = """    val gyroYawOffset = if (gyroEnabled) getAngleDiff(currentOrientation[0], baseOrientation[0]) * -gyroSensitivity else 0f
    val gyroPitchOffset = if (gyroEnabled) getAngleDiff(currentOrientation[1], baseOrientation[1]) * gyroSensitivity else 0f"""

replace_gyro = """    val gyroYawOffset = if (gyroEnabled) getAngleDiff(currentOrientation[0], baseOrientation[0]) * (gyroSensitivity * 1.5f) else 0f
    val gyroPitchOffset = if (gyroEnabled) getAngleDiff(currentOrientation[1], baseOrientation[1]) * -gyroSensitivity else 0f"""
content = content.replace(target_gyro, replace_gyro)

# Fix screen size slider and lens UI
target_ui = """                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = scale,
                                onValueChange = { scale = it },
                                valueRange = 0.5f..1.5f
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                            }
                            if (lensWrapping) {
                                Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = lensDistortion,
                                    onValueChange = { lensDistortion = it },
                                    valueRange = 0.0f..1.5f
                                )
                            }"""

replace_ui = """                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = scale,
                                onValueChange = { scale = it },
                                valueRange = 0.1f..3.0f
                            )
                            if (android.os.Build.VERSION.SDK_INT >= 33) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                                }
                                if (lensWrapping) {
                                    Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = lensDistortion,
                                        onValueChange = { lensDistortion = it },
                                        valueRange = 0.0f..1.5f
                                    )
                                }
                            } else {
                                Text("Lens Wrapping requires Android 13+", color = Color.Red.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 4.dp))
                            }"""
content = content.replace(target_ui, replace_ui)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
