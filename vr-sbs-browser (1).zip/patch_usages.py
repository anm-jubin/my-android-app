import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Usage 1: Camera
target_camera = """        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = ipd,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {
                CameraPassthroughLayer(
                    modifier = Modifier.offset(x = with(density) { (if (isRightHandMode) ipd else -ipd).toDp() })
                )
            }
        }"""
        
replacement_camera = """        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = cameraIpd,
                gyroYawOffset = gyroYawOffset,
                gyroPitchOffset = gyroPitchOffset,
                verticalShift = cameraVerticalShift,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {
                CameraPassthroughLayer(
                    modifier = Modifier.graphicsLayer { scaleX = cameraScale; scaleY = cameraScale }
                )
            }
        }"""
content = content.replace(target_camera, replacement_camera)

# Usage 2: Browser
target_browser = """        VrSplitScreenWrapper(
            isRightHandMode = isRightHandMode,
            ipd = ipd,
            lensWrapping = lensWrapping,
            lensDistortion = lensDistortion,
            eyeWidth = eyeWidth,
            modifier = Modifier.alpha(contentOpacity)
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode,
                    gyroYawOffset = gyroYawOffset,
                    gyroPitchOffset = gyroPitchOffset
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .offset(
                                x = with(density) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                                y = with(density) { (verticalShift + gyroPitchOffset).toDp() }
                            )
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                }
            }
        } // Close distortion wrapper"""
        
replacement_browser = """        VrSplitScreenWrapper(
            isRightHandMode = isRightHandMode,
            ipd = ipd,
            gyroYawOffset = gyroYawOffset,
            gyroPitchOffset = gyroPitchOffset,
            verticalShift = verticalShift,
            lensWrapping = lensWrapping,
            lensDistortion = lensDistortion,
            eyeWidth = eyeWidth,
            modifier = Modifier.alpha(contentOpacity)
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                }
            }
        } // Close distortion wrapper"""
content = content.replace(target_browser, replacement_browser)

# Update TextureVideoPlayer signature to remove ipd/gyro/verticalShift
target_videoplayer_sig = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    gyroYawOffset: Float = 0f,
    gyroPitchOffset: Float = 0f,
    modifier: Modifier = Modifier
) {"""

replacement_videoplayer_sig = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    modifier: Modifier = Modifier
) {"""
content = content.replace(target_videoplayer_sig, replacement_videoplayer_sig)

# Update TextureVideoPlayer internals (remove offset)
target_videoplayer_internal = """                modifier = Modifier
                    .fillMaxSize()
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { (verticalShift + gyroPitchOffset).toDp() }
                    )
                    .graphicsLayer { scaleX = scale; scaleY = scale }"""

replacement_videoplayer_internal = """                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }"""
content = content.replace(target_videoplayer_internal, replacement_videoplayer_internal)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

