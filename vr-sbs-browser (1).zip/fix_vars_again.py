import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_states = """    var contentOpacity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("contentOpacity", 1.0f)) }"""

replacement_states = """    var contentOpacity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("contentOpacity", 1.0f)) }
    var cameraIpd by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("cameraIpd", 0f)) }
    var cameraScale by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("cameraScale", 1f)) }
    var cameraVerticalShift by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("cameraVerticalShift", 0f)) }"""

if target_states in content:
    content = content.replace(target_states, replacement_states)
    print("Patched states")

target_save = """            .putFloat("contentOpacity", contentOpacity)
            .apply()"""

replacement_save = """            .putFloat("contentOpacity", contentOpacity)
            .putFloat("cameraIpd", cameraIpd)
            .putFloat("cameraScale", cameraScale)
            .putFloat("cameraVerticalShift", cameraVerticalShift)
            .apply()"""

if target_save in content:
    content = content.replace(target_save, replacement_save)
    print("Patched saves")
    
target_launch = """LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity) {"""

replacement_launch = """LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity, cameraIpd, cameraScale, cameraVerticalShift) {"""

if target_launch in content:
    content = content.replace(target_launch, replacement_launch)
    print("Patched launch")
    
with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

