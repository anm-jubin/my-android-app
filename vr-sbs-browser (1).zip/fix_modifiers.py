import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix AndroidView for Browser
target_browser = """                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                            .offset(
                                x = with(density) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                                y = with(density) { (verticalShift + gyroPitchOffset).toDp() }
                            )"""
                            
replace_browser = """                            .fillMaxSize()
                            .offset(
                                x = with(density) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                                y = with(density) { (verticalShift + gyroPitchOffset).toDp() }
                            )
                            .graphicsLayer { scaleX = scale; scaleY = scale }"""
content = content.replace(target_browser, replace_browser)

# Fix AndroidView for VideoPlayer
target_video = """                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { (verticalShift + gyroPitchOffset).toDp() }
                    )"""

replace_video = """                    .fillMaxSize()
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { ((if (isRightHandMode) ipd else -ipd) + gyroYawOffset).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { (verticalShift + gyroPitchOffset).toDp() }
                    )
                    .graphicsLayer { scaleX = scale; scaleY = scale }"""
content = content.replace(target_video, replace_video)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
