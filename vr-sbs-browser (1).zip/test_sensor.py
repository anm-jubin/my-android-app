import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

print("File loaded")
