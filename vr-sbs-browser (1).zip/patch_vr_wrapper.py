import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_wrapper = """@Composable
fun VrSplitScreenWrapper(
    isRightHandMode: Boolean,
    ipd: Float,
    lensWrapping: Boolean,
    lensDistortion: Float,
    eyeWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    drawContext.canvas.save()
                    val distance = if (isRightHandMode) {
                        -size.width - 2 * ipd
                    } else {
                        size.width + 2 * ipd
                    }
                    drawContext.canvas.translate(distance, 0f)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            content()
        }
    }
}"""

replacement_wrapper = """@Composable
fun VrSplitScreenWrapper(
    isRightHandMode: Boolean,
    ipd: Float,
    gyroYawOffset: Float,
    gyroPitchOffset: Float,
    verticalShift: Float,
    lensWrapping: Boolean,
    lensDistortion: Float,
    eyeWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    val activeEyeIpdOffset = if (isRightHandMode) ipd else -ipd
                    drawContext.canvas.translate(activeEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye
                    drawContext.canvas.save()
                    val mirrorEyeIpdOffset = if (isRightHandMode) -ipd else ipd
                    val baseDistance = if (isRightHandMode) -size.width else size.width
                    drawContext.canvas.translate(baseDistance + mirrorEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            content()
        }
    }
}"""

if target_wrapper in content:
    content = content.replace(target_wrapper, replacement_wrapper)
    print("Patched VrSplitScreenWrapper")
else:
    print("Could not find VrSplitScreenWrapper")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

