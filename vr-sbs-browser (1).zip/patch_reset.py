import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                },
                                modifier = Modifier.fillMaxWidth(),"""

replace = """                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                    gyroEnabled = false
                                    gyroSensitivity = 1500f
                                    shouldRecenter = true
                                },
                                modifier = Modifier.fillMaxWidth(),"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
