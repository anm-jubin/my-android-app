import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("Icons.Default.Search", "androidx.compose.material.icons.filled.Search")
content = content.replace("Icons.Default.Menu", "androidx.compose.material.icons.filled.Menu")
content = content.replace("Icons.Default.Info", "androidx.compose.material.icons.filled.Info")
content = content.replace("Icons.Default.PlayArrow", "androidx.compose.material.icons.filled.PlayArrow")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
