import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """        // Left Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        // Right Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset((fabOffsetX + eyeWidthPx).roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }"""

replace = """        // Left Eye Floating Action Button
        Column(
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
        ) {
            SmallFloatingActionButton(
                onClick = { isUiVisible = !isUiVisible },
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            fabOffsetX += dragAmount.x
                            fabOffsetY += dragAmount.y
                        }
                    },
                containerColor = Color.White.copy(alpha = 0.5f)
            ) {
                Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
            }
            if (gyroEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                SmallFloatingActionButton(
                    onClick = { shouldRecenter = true },
                    modifier = Modifier
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                fabOffsetX += dragAmount.x
                                fabOffsetY += dragAmount.y
                            }
                        },
                    containerColor = Color.Cyan.copy(alpha = 0.5f)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Recenter", tint = Color.Black)
                }
            }
        }

        // Right Eye Floating Action Button
        Column(
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset((fabOffsetX + eyeWidthPx).roundToInt(), fabOffsetY.roundToInt()) }
        ) {
            SmallFloatingActionButton(
                onClick = { isUiVisible = !isUiVisible },
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            fabOffsetX += dragAmount.x
                            fabOffsetY += dragAmount.y
                        }
                    },
                containerColor = Color.White.copy(alpha = 0.5f)
            ) {
                Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
            }
            if (gyroEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                SmallFloatingActionButton(
                    onClick = { shouldRecenter = true },
                    modifier = Modifier
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                fabOffsetX += dragAmount.x
                                fabOffsetY += dragAmount.y
                            }
                        },
                    containerColor = Color.Cyan.copy(alpha = 0.5f)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Recenter", tint = Color.Black)
                }
            }
        }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
