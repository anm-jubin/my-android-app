import re
with open("app/build.gradle.kts", "r") as f:
    content = f.read()

content = content.replace("// implementation(libs.accompanist.permissions)", "implementation(libs.accompanist.permissions)")
content = content.replace("// implementation(libs.androidx.camera.camera2)", "implementation(libs.androidx.camera.camera2)")
content = content.replace("// implementation(libs.androidx.camera.core)", "implementation(libs.androidx.camera.core)")
content = content.replace("// implementation(libs.androidx.camera.lifecycle)", "implementation(libs.androidx.camera.lifecycle)")
content = content.replace("// implementation(libs.androidx.camera.view)", "implementation(libs.androidx.camera.view)")

with open("app/build.gradle.kts", "w") as f:
    f.write(content)
