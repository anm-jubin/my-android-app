import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("import androidx.compose.ui.Modifier", "import androidx.compose.ui.Modifier\\nimport androidx.compose.ui.draw.alpha")

target_launcher = """    val permissionLauncher = rememberLauncherForActivityResult(
        androidx.activity.compose.LocalActivityResultRegistryOwner.current?.activityResultRegistry ?: return,
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasPermission = isGranted
    }
    // Alternatively just use the standard rememberLauncherForActivityResult
    
    val standardLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) {
            standardLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }"""
    
replace_launcher = """    val standardLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) {
            standardLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }"""
content = content.replace(target_launcher, replace_launcher)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
