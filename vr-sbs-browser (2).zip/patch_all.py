import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Remove old CSS hack for Insta
target1 = """                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        view.evaluateJavascript(
                            "var style = document.createElement('style'); " +
                            "style.innerHTML = 'body, #react-root, main { max-width: 500px !important; margin: 0 auto !important; overflow-x: hidden !important; } video { object-fit: contain !important; }'; " +
                            "if (!document.getElementById('vr-custom-style')) { style.id = 'vr-custom-style'; document.head.appendChild(style); }", null
                        )
                    }"""
content = content.replace(target1, "")

# 2. Add adjustWebViewLayout inside BrowserManager
target2 = "    fun getActiveWebView(): WebView? = activeTabId?.let { webViews[it] }"
replace2 = """    fun getActiveWebView(): WebView? = activeTabId?.let { webViews[it] }
    
    private fun adjustWebViewLayout(webView: WebView, url: String?) {
        val lp = webView.layoutParams as? android.widget.FrameLayout.LayoutParams ?: return
        val currentUrl = url ?: ""
        if (currentUrl.contains("instagram.com") || currentUrl.contains("tiktok.com")) {
            if (!this.isDesktopMode) {
                lp.width = (450 * context.resources.displayMetrics.density).toInt()
            } else {
                lp.width = (1100 * context.resources.displayMetrics.density).toInt()
            }
            lp.gravity = android.view.Gravity.CENTER_HORIZONTAL
        } else {
            lp.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT
            lp.gravity = android.view.Gravity.NO_GRAVITY
        }
        webView.layoutParams = lp
    }"""
content = content.replace(target2, replace2)

# 3. Add adjustWebViewLayout calls
target3_dm = """            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (isDesktopMode != isCurrentlyDesktop) {
                if (isDesktopMode) {"""
replace3_dm = """            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            adjustWebViewLayout(view, view.url ?: view.originalUrl)
            if (isDesktopMode != isCurrentlyDesktop) {
                if (isDesktopMode) {"""
content = content.replace(target3_dm, replace3_dm)

target3_url = """                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {"""
replace3_url = """                    adjustWebViewLayout(view, url)
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {"""
content = content.replace(target3_url, replace3_url)

target3_start = """                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)

                }"""
replace3_start = """                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    adjustWebViewLayout(view, url)
                }"""
content = content.replace(target3_start, replace3_start)

# 4. Turn multiple windows back on and handle onCreateWindow
target4_settings = """                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false
                userAgentString ="""
replace4_settings = """                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(true)
                javaScriptCanOpenWindowsAutomatically = true
                
                var ua = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)
                if (!isDesktopMode) {
                    ua = ua.replace("; wv", "").replace("Version/4.0 ", "")
                }
                userAgentString = ua"""
content = content.replace(target4_settings, replace4_settings)
content = content.replace("userAgentString = if (isDesktopMode) \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36\" else WebSettings.getDefaultUserAgent(context)", "")
content = content.replace("it.settings.userAgentString = if (this@BrowserManager.isDesktopMode) \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36\" else WebSettings.getDefaultUserAgent(it.context)", """
                            var newUa = if (this@BrowserManager.isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            if (!this@BrowserManager.isDesktopMode) {
                                newUa = newUa.replace("; wv", "").replace("Version/4.0 ", "")
                            }
                            it.settings.userAgentString = newUa
""")

target4_webchrome = """                override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                    request.grant(request.resources)
                }
            }"""
replace4_webchrome = """                override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                    request.grant(request.resources)
                }
                
                override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                    val popupWebView = WebView(view!!.context).apply {
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            userAgentString = view.settings.userAgentString
                        }
                        layoutParams = android.widget.FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                    popupWebView.webChromeClient = object : WebChromeClient() {
                        override fun onCloseWindow(window: WebView?) {
                            container.removeView(popupWebView)
                            popupWebView.destroy()
                        }
                    }
                    popupWebView.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                            val reqUrl = request?.url?.toString() ?: return false
                            if (reqUrl.startsWith("intent://") || reqUrl.startsWith("android-app://")) {
                                try {
                                    val intent = android.content.Intent.parseUri(reqUrl, android.content.Intent.URI_INTENT_SCHEME)
                                    if (intent != null) {
                                        v!!.context.startActivity(intent)
                                        return true
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                                return true
                            }
                            return false
                        }
                    }
                    
                    container.addView(popupWebView)
                    val transport = resultMsg?.obj as WebView.WebViewTransport
                    transport.webView = popupWebView
                    resultMsg?.sendToTarget()
                    return true
                }
            }"""
content = content.replace(target4_webchrome, replace4_webchrome)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
