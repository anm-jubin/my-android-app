#!/bin/bash
sed -i '48,110c\
@Composable\
fun AppIconImage(packageName: String, modifier: Modifier = Modifier) {\
    val context = LocalContext.current\
    val iconBitmap by androidx.compose.runtime.produceState<androidx.compose.ui.graphics.ImageBitmap?>(\
        initialValue = iconCache.get(packageName),\
        key1 = packageName\
    ) {\
        if (value == null) {\
            value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {\
                try {\
                    val cached = iconCache.get(packageName)\
                    if (cached != null) return@withContext cached\
                    val drawable = context.packageManager.getApplicationIcon(packageName)\
                    if (!kotlinx.coroutines.isActive) return@withContext null\
                    val rawWidth = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 144\
                    val rawHeight = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 144\
                    val width = minOf(rawWidth, 144)\
                    val height = minOf(rawHeight, 144)\
                    val bmp = drawable.toBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)\
                    if (!kotlinx.coroutines.isActive) return@withContext null\
                    val newBitmap = bmp.asImageBitmap()\
                    iconCache.put(packageName, newBitmap)\
                    newBitmap\
                } catch (e: Exception) {\
                    null\
                }\
            }\
        }\
    }\
    if (iconBitmap != null) {\
        androidx.compose.foundation.Image(\
            bitmap = iconBitmap!!,\
            contentDescription = null,\
            modifier = modifier\
        )\
    } else {\
        Box(\
            modifier = modifier\
                .background(MaterialTheme.colorScheme.primaryContainer, shape = CircleShape),\
            contentAlignment = Alignment.Center\
        ) {\
            Text(\
                text = packageName.take(2).uppercase(),\
                style = MaterialTheme.typography.bodySmall,\
                color = MaterialTheme.colorScheme.onPrimaryContainer\
            )\
        }\
    }\
}' app/src/main/java/com/example/ui/screens/AppScreens.kt
