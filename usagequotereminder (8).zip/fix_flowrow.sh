#!/bin/bash
sed -i 's/profile.monitoredApps.forEach { p ->/val displayApps = profile.monitoredApps.take(15)\n                            displayApps.forEach { p ->/1' app/src/main/java/com/example/ui/screens/AppScreens.kt
sed -i '1466a\
                            if (profile.monitoredApps.size > 15) {\
                                SuggestionChip(\
                                    onClick = {},\
                                    label = { Text("+${profile.monitoredApps.size - 15} more") }\
                                )\
                            }' app/src/main/java/com/example/ui/screens/AppScreens.kt
