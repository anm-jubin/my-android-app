#!/bin/bash
# Remove lines 1467 to 1472
sed -i '1467,1472d' app/src/main/java/com/example/ui/screens/AppScreens.kt
# Add the chip after the forEach brace
sed -i '1467a\
                            if (profile.monitoredApps.size > 15) {\
                                SuggestionChip(\
                                    onClick = {},\
                                    label = { Text("+${profile.monitoredApps.size - 15} more") }\
                                )\
                            }' app/src/main/java/com/example/ui/screens/AppScreens.kt
