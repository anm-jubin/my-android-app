package com.example.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import com.example.R

object NotificationIconHelper {

    fun createDisguiseAvatar(context: Context, appIcon: Drawable): Bitmap {
        val avatarSize = 144 // 48dp * 3 roughly
        val badgeSize = 54   // ~18dp * 3 roughly
        
        val bitmap = Bitmap.createBitmap(avatarSize, avatarSize, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        
        // Draw the default avatar (man shape)
        val defaultAvatar = ContextCompat.getDrawable(context, R.drawable.ic_default_avatar)
        if (defaultAvatar != null) {
            defaultAvatar.setBounds(0, 0, avatarSize, avatarSize)
            defaultAvatar.draw(canvas)
        }
        
        // Draw a circular cutout for the badge
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        val badgeCenterX = avatarSize - badgeSize / 2f
        val badgeCenterY = avatarSize - badgeSize / 2f
        val cutoutRadius = badgeSize / 2f + 4f // add a small margin
        canvas.drawCircle(badgeCenterX, badgeCenterY, cutoutRadius, paint)
        
        // Draw the app icon (badge)
        appIcon.setBounds(
            avatarSize - badgeSize,
            avatarSize - badgeSize,
            avatarSize,
            avatarSize
        )
        appIcon.draw(canvas)
        
        return bitmap
    }
}
