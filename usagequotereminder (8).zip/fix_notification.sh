#!/bin/bash
sed -i 's/val person = androidx.core.app.Person.Builder().setName(disguiseAppName ?: "Message").apply { if (disguiseBitmap != null) setIcon(androidx.core.graphics.drawable.IconCompat.createWithBitmap(disguiseBitmap)) }.build()//1' app/src/main/java/com/example/service/QuoteMonitorService.kt
sed -i 's/builder.setStyle(androidx.core.app.NotificationCompat.MessagingStyle(person).addMessage(randomQuote, System.currentTimeMillis(), person))/builder.setStyle(NotificationCompat.BigTextStyle().bigText(randomQuote))/1' app/src/main/java/com/example/service/QuoteMonitorService.kt

sed -i 's/val person = androidx.core.app.Person.Builder().setName(disguiseAppName ?: "Message").apply { if (disguiseBitmap != null) setIcon(androidx.core.graphics.drawable.IconCompat.createWithBitmap(disguiseBitmap)) }.build()//1' app/src/main/java/com/example/service/QuoteMonitorService.kt
sed -i 's/builder.setStyle(androidx.core.app.NotificationCompat.MessagingStyle(person).addMessage(randomQuote, System.currentTimeMillis(), person))/builder.setStyle(NotificationCompat.BigTextStyle().bigText(randomQuote))/1' app/src/main/java/com/example/service/QuoteMonitorService.kt
