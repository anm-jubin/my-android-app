package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class MappingSettings(
    val applyToTouch: Boolean = false,
    val swapAxes: Boolean = false,
    val invertX: Boolean = false,
    val invertY: Boolean = false,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f
)

data class DrawnStroke(
    val points: List<Offset>,
    val color: Color = Color(0xFF6750A4),
    val strokeWidth: Float = 5f
)

class TabletViewModel : ViewModel() {
    private val _settings = MutableStateFlow(MappingSettings())
    val settings: StateFlow<MappingSettings> = _settings.asStateFlow()

    private val _strokes = MutableStateFlow<List<DrawnStroke>>(emptyList())
    val strokes: StateFlow<List<DrawnStroke>> = _strokes.asStateFlow()

    private val _currentStroke = MutableStateFlow<DrawnStroke?>(null)
    val currentStroke: StateFlow<DrawnStroke?> = _currentStroke.asStateFlow()

    fun updateSettings(newSettings: MappingSettings) {
        _settings.value = newSettings
    }

    fun startStroke(position: Offset) {
        _currentStroke.value = DrawnStroke(points = listOf(position))
    }

    fun moveStroke(position: Offset) {
        _currentStroke.update { stroke ->
            stroke?.copy(points = stroke.points + position)
        }
    }

    fun endStroke() {
        _currentStroke.value?.let { stroke ->
            _strokes.update { it + stroke }
        }
        _currentStroke.value = null
    }

    fun clearCanvas() {
        _strokes.value = emptyList()
        _currentStroke.value = null
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                TabletMapperApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TabletMapperApp(viewModel: TabletViewModel = viewModel()) {
    val settings by viewModel.settings.collectAsState()
    val strokes by viewModel.strokes.collectAsState()
    val currentStroke by viewModel.currentStroke.collectAsState()

    var showSettingsDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 24.dp, vertical = 16.dp)
                    .padding(top = 24.dp), // Accommodate status bar roughly
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "INPUT CONTROLLER",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = "PenMapper Pro",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.clearCanvas() },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Clear Canvas",
                            tint = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier
                            .size(40.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape)
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp) // Edge spacing
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(24.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
                    .clip(RoundedCornerShape(24.dp))
            ) {
                DrawingCanvas(
                    strokes = strokes,
                    currentStroke = currentStroke,
                    settings = settings,
                    onStrokeStart = { viewModel.startStroke(it) },
                    onStrokeMove = { viewModel.moveStroke(it) },
                    onStrokeEnd = { viewModel.endStroke() },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        if (showSettingsDialog) {
            SettingsDialog(
                settings = settings,
                onDismiss = { showSettingsDialog = false },
                onSettingsChanged = { viewModel.updateSettings(it) }
            )
        }
    }
}

@Composable
fun DrawingCanvas(
    strokes: List<DrawnStroke>,
    currentStroke: DrawnStroke?,
    settings: MappingSettings,
    onStrokeStart: (Offset) -> Unit,
    onStrokeMove: (Offset) -> Unit,
    onStrokeEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .pointerInput(settings) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    
                    // Decide whether to apply mapping
                    val shouldMap = down.type != PointerType.Touch || settings.applyToTouch
                    
                    var mappedPos = if (shouldMap) mapPosition(down.position, Size(size.width.toFloat(), size.height.toFloat()), settings) else down.position
                    onStrokeStart(mappedPos)

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull()
                        if (change != null) {
                            if (change.pressed) {
                                mappedPos = if (shouldMap) mapPosition(change.position, Size(size.width.toFloat(), size.height.toFloat()), settings) else change.position
                                onStrokeMove(mappedPos)
                            }
                            change.consume()
                        }
                    } while (event.changes.any { it.pressed })
                    
                    onStrokeEnd()
                }
            }
    ) {
        val drawStroke = { stroke: DrawnStroke ->
            if (stroke.points.size == 1) {
                drawCircle(
                    color = stroke.color,
                    radius = stroke.strokeWidth / 2f,
                    center = stroke.points.first()
                )
            } else if (stroke.points.size > 1) {
                val path = Path().apply {
                    moveTo(stroke.points.first().x, stroke.points.first().y)
                    for (i in 1 until stroke.points.size) {
                        lineTo(stroke.points[i].x, stroke.points[i].y)
                    }
                }
                drawPath(
                    path = path,
                    color = stroke.color,
                    style = Stroke(
                        width = stroke.strokeWidth,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }

        strokes.forEach { drawStroke(it) }
        currentStroke?.let { drawStroke(it) }
    }
}

fun mapPosition(pos: Offset, canvasSize: Size, settings: MappingSettings): Offset {
    var x = pos.x
    var y = pos.y

    if (settings.swapAxes) {
        val temp = x
        x = y
        y = temp
    }

    if (settings.invertX) {
        x = canvasSize.width - x
    }

    if (settings.invertY) {
        y = canvasSize.height - y
    }

    x *= settings.scaleX
    y *= settings.scaleY

    x += settings.offsetX
    y += settings.offsetY

    return Offset(x, y)
}

@Composable
fun SettingsDialog(
    settings: MappingSettings,
    onDismiss: () -> Unit,
    onSettingsChanged: (MappingSettings) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "Orientation Mapping",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = settings.applyToTouch,
                        onCheckedChange = { onSettingsChanged(settings.copy(applyToTouch = it)) },
                        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                    )
                    Text("Apply to Touch (Test mode)", color = MaterialTheme.colorScheme.onSurface)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = settings.swapAxes,
                        onCheckedChange = { onSettingsChanged(settings.copy(swapAxes = it)) },
                        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                    )
                    Text("Swap X and Y Axes", color = MaterialTheme.colorScheme.onSurface)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = settings.invertX,
                        onCheckedChange = { onSettingsChanged(settings.copy(invertX = it)) },
                        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                    )
                    Text("Invert X Axis", color = MaterialTheme.colorScheme.onSurface)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = settings.invertY,
                        onCheckedChange = { onSettingsChanged(settings.copy(invertY = it)) },
                        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                    )
                    Text("Invert Y Axis", color = MaterialTheme.colorScheme.onSurface)
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Scale X: ${String.format("%.2f", settings.scaleX)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = settings.scaleX,
                        onValueChange = { onSettingsChanged(settings.copy(scaleX = it)) },
                        valueRange = 0.1f..5f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Scale Y: ${String.format("%.2f", settings.scaleY)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = settings.scaleY,
                        onValueChange = { onSettingsChanged(settings.copy(scaleY = it)) },
                        valueRange = 0.1f..5f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Offset X: ${settings.offsetX.toInt()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = settings.offsetX,
                        onValueChange = { onSettingsChanged(settings.copy(offsetX = it)) },
                        valueRange = -2000f..2000f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Offset Y: ${settings.offsetY.toInt()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = settings.offsetY,
                        onValueChange = { onSettingsChanged(settings.copy(offsetY = it)) },
                        valueRange = -2000f..2000f,
                        colors = SliderDefaults.colors(
                            thumbColor = MaterialTheme.colorScheme.primary,
                            activeTrackColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Save Configuration", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
