package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SleekPrimary = Color(0xFF6750A4)
val SleekOnPrimary = Color(0xFFFFFFFF)
val SleekPrimaryContainer = Color(0xFFEADDFF)
val SleekOnPrimaryContainer = Color(0xFF21005D)
val SleekBackground = Color(0xFFFDF8F6)
val SleekSurface = Color(0xFFFFFFFF)
val SleekSurfaceVariant = Color(0xFFF3EDF7)
val SleekOutline = Color(0xFFE7E0EC)
val SleekOutlineVariant = Color(0xFF79747E)
val SleekTextPrimary = Color(0xFF1D1B20)
val SleekTextSecondary = Color(0xFF49454F)
