package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.alarm.AlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.data.local.AppDatabase
import com.example.data.local.DeliveredNotificationEntity
import com.example.data.preferences.ReminderPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NotificationAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_FIRE_QUOTE = "com.example.action.FIRE_QUOTE"
        private const val TAG = "NotificationReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        Log.d(TAG, "NotificationAlarmReceiver received alarm trigger! Action=${intent?.action}")

        val pendingResult = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        scope.launch {
            try {
                val db = AppDatabase.getInstance(context)
                val quoteDao = db.quoteDao()
                val prefs = ReminderPreferences(context)

                // Pick a random quote from the active profile's collection (or any if empty)
                val activeProfileId = prefs.activeProfileId
                val profile = quoteDao.getProfileById(activeProfileId)
                val profileName = profile?.name ?: "Personal"

                val quote = quoteDao.getRandomQuoteForProfile(activeProfileId)
                    ?: quoteDao.getRandomQuoteAny()

                val text = quote?.text ?: "The secret of getting ahead is getting started."

                // Show the clean notification
                NotificationHelper.showQuoteNotification(context, text)

                // Schedule tomorrow's random notification so the randomness refreshes every day
                // using the profile's or global active time window
                AlarmScheduler.scheduleNextAlarm(context, forceNewRandom = true)
                Log.d(TAG, "Delivered quote and scheduled next alarm.")
            } catch (e: Exception) {
                Log.e(TAG, "Error handling quote notification alarm", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
