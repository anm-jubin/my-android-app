package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.alarm.AlarmScheduler
import com.example.data.preferences.ReminderPreferences

class BootCompletedReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootCompletedReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        Log.d(TAG, "BootCompletedReceiver triggered with action: $action")

        val prefs = ReminderPreferences(context)
        if (prefs.isEnabled) {
            // Restore or recalculate the next alarm without requiring any background service
            AlarmScheduler.scheduleNextAlarm(context, forceNewRandom = false)
        }
    }
}
