package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.preferences.ReminderPreferences
import com.example.receiver.NotificationAlarmReceiver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.TimeZone
import kotlin.random.Random

object AlarmScheduler {

    private const val TAG = "AlarmScheduler"
    const val REQUEST_CODE = 1001

    suspend fun scheduleNextAlarmForActiveProfile(context: Context, forceNewRandom: Boolean = false): Long {
        return withContext(Dispatchers.IO) {
            val prefs = ReminderPreferences(context)
            if (!prefs.isEnabled) {
                cancelAlarm(context)
                prefs.nextScheduledTimeMillis = 0L
                return@withContext 0L
            }

            val db = AppDatabase.getInstance(context)
            val profile = db.quoteDao().getProfileById(prefs.activeProfileId)

            val startH = profile?.startHour ?: prefs.startHour
            val startM = profile?.startMinute ?: prefs.startMinute
            val endH = profile?.endHour ?: prefs.endHour
            val endM = profile?.endMinute ?: prefs.endMinute

            scheduleAlarmInternal(
                context = context,
                startHour = startH,
                startMinute = startM,
                endHour = endH,
                endMinute = endM,
                forceNewRandom = forceNewRandom
            )
        }
    }

    fun scheduleNextAlarm(context: Context, forceNewRandom: Boolean = false): Long {
        val prefs = ReminderPreferences(context)
        if (!prefs.isEnabled) {
            cancelAlarm(context)
            prefs.nextScheduledTimeMillis = 0L
            return 0L
        }

        return scheduleAlarmInternal(
            context = context,
            startHour = prefs.startHour,
            startMinute = prefs.startMinute,
            endHour = prefs.endHour,
            endMinute = prefs.endMinute,
            forceNewRandom = forceNewRandom
        )
    }

    private fun scheduleAlarmInternal(
        context: Context,
        startHour: Int,
        startMinute: Int,
        endHour: Int,
        endMinute: Int,
        forceNewRandom: Boolean
    ): Long {
        val prefs = ReminderPreferences(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            ?: return 0L

        val existingScheduled = prefs.nextScheduledTimeMillis
        val now = System.currentTimeMillis()

        // If there is already a future scheduled time and we are not forcing a reshuffle, keep it
        if (!forceNewRandom && existingScheduled > now + 1000) {
            setSystemAlarm(context, alarmManager, existingScheduled)
            return existingScheduled
        }

        val timeZone = TimeZone.getDefault()

        val nextTimeMillis = calculateNextRandomTime(
            startHour = startHour,
            startMinute = startMinute,
            endHour = endHour,
            endMinute = endMinute,
            timeZone = timeZone
        )

        prefs.nextScheduledTimeMillis = nextTimeMillis
        setSystemAlarm(context, alarmManager, nextTimeMillis)

        Log.d(TAG, "Scheduled next random alarm at $nextTimeMillis (in ${(nextTimeMillis - now) / 1000 / 60} minutes)")
        return nextTimeMillis
    }

    private fun setSystemAlarm(context: Context, alarmManager: AlarmManager, triggerAtMillis: Long) {
        val intent = Intent(context, NotificationAlarmReceiver::class.java).apply {
            action = NotificationAlarmReceiver.ACTION_FIRE_QUOTE
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "SecurityException while scheduling exact alarm, falling back to inexact", e)
            try {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } catch (fallbackEx: Exception) {
                Log.e(TAG, "Failed to schedule alarm", fallbackEx)
            }
        }
    }

    fun cancelAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, NotificationAlarmReceiver::class.java).apply {
            action = NotificationAlarmReceiver.ACTION_FIRE_QUOTE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
        val prefs = ReminderPreferences(context)
        prefs.nextScheduledTimeMillis = 0L
    }

    /**
     * Calculates a uniformly random instant between [startHour:startMinute] and [endHour:endMinute]
     * in the specified [timeZone]. If the window for today has already passed, computes for tomorrow.
     */
    fun calculateNextRandomTime(
        startHour: Int,
        startMinute: Int,
        endHour: Int,
        endMinute: Int,
        timeZone: TimeZone
    ): Long {
        val now = Calendar.getInstance(timeZone)
        val candidate = Calendar.getInstance(timeZone).apply {
            set(Calendar.HOUR_OF_DAY, startHour)
            set(Calendar.MINUTE, startMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val windowEnd = Calendar.getInstance(timeZone).apply {
            set(Calendar.HOUR_OF_DAY, endHour)
            set(Calendar.MINUTE, endMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If end time is before or equal to start time, the range wraps past midnight to next day
        if (windowEnd.timeInMillis <= candidate.timeInMillis) {
            windowEnd.add(Calendar.DAY_OF_YEAR, 1)
        }

        val windowDurationMillis = windowEnd.timeInMillis - candidate.timeInMillis

        // If today's entire window has already ended, advance to tomorrow's window
        if (now.timeInMillis >= windowEnd.timeInMillis) {
            candidate.add(Calendar.DAY_OF_YEAR, 1)
        }

        // If we are currently inside the window today, pick a random time between (now + 1 min) and windowEnd
        val startBoundMillis = if (candidate.timeInMillis <= now.timeInMillis && now.timeInMillis < windowEnd.timeInMillis) {
            now.timeInMillis + 60_000L // at least 1 minute in the future
        } else {
            candidate.timeInMillis
        }

        val targetWindowEnd = candidate.timeInMillis + windowDurationMillis

        return if (targetWindowEnd > startBoundMillis) {
            val randomOffset = Random.nextLong(0, targetWindowEnd - startBoundMillis)
            startBoundMillis + randomOffset
        } else {
            // Window for today is too narrow, push to tomorrow cleanly
            candidate.add(Calendar.DAY_OF_YEAR, 1)
            val randomOffset = if (windowDurationMillis > 0) Random.nextLong(0, windowDurationMillis) else 0L
            candidate.timeInMillis + randomOffset
        }
    }
}
