package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SlatePrimaryDark,
    onPrimary = Color(0xFF003355),
    primaryContainer = Color(0xFF1B4365),
    onPrimaryContainer = Color(0xFFD0E4FF),
    secondary = SlateSecondaryDark,
    onSecondary = Color(0xFF1B3447),
    secondaryContainer = Color(0xFF334B5E),
    onSecondaryContainer = Color(0xFFD2E5F7),
    tertiary = NeutralTertiaryDark,
    background = MinimalBackgroundDark,
    onBackground = Color(0xFFE2E4E8),
    surface = MinimalSurfaceDark,
    onSurface = Color(0xFFE2E4E8),
    surfaceVariant = MinimalSurfaceVariantDark,
    onSurfaceVariant = Color(0xFFC3C7CE)
)

private val LightColorScheme = lightColorScheme(
    primary = SlatePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4F0),
    onPrimaryContainer = Color(0xFF0D253A),
    secondary = SlateSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE2ECF3),
    onSecondaryContainer = Color(0xFF132838),
    tertiary = NeutralTertiary,
    background = MinimalBackgroundLight,
    onBackground = Color(0xFF1E2329),
    surface = MinimalSurfaceLight,
    onSurface = Color(0xFF1E2329),
    surfaceVariant = MinimalSurfaceVariantLight,
    onSurfaceVariant = Color(0xFF5A636E)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true, // Supports dynamic color or our clean slate theme
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
