package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Minimalist Modern Neutral & Indigo / Slate Palette
// Replaced red/terracotta with balanced calm slate/indigo accents and clean neutrals
val SlatePrimary = Color(0xFF2B5B84) // Calm slate blue
val SlatePrimaryDark = Color(0xFF9CC8F5)

val SlateSecondary = Color(0xFF4A6B82)
val SlateSecondaryDark = Color(0xFFB0C9DE)

val NeutralTertiary = Color(0xFF5D6B78)
val NeutralTertiaryDark = Color(0xFFC0CCD8)

// Minimalist Light canvas (clean, light, high legibility, gentle cool gray-white)
val MinimalBackgroundLight = Color(0xFFF8F9FA)
val MinimalSurfaceLight = Color(0xFFFFFFFF)
val MinimalSurfaceVariantLight = Color(0xFFF1F3F5)

// Minimalist Dark canvas
val MinimalBackgroundDark = Color(0xFF121417)
val MinimalSurfaceDark = Color(0xFF1A1D21)
val MinimalSurfaceVariantDark = Color(0xFF25292E)

val SuccessGreen = Color(0xFF2E7D32)
val MutedText = Color(0xFF6C757D)
