package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.alarm.NotificationHelper
import com.example.data.local.ProfileEntity
import com.example.data.local.QuoteEntity
import com.example.ui.components.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuoteReminderScreen(
    viewModel: QuoteReminderViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Screen navigation state: null = Profile List (default page), ProfileEntity = inside profile settings
    var viewingProfile by remember { mutableStateOf<ProfileEntity?>(null) }
    var isCreatingProfile by remember { mutableStateOf(false) }

    // Draft state for new profile creation (does not persist unless saved)
    var draftName by remember { mutableStateOf("") }
    var draftDescription by remember { mutableStateOf("") }
    var draftStartHour by remember { mutableIntStateOf(9) }
    var draftStartMinute by remember { mutableIntStateOf(0) }
    var draftEndHour by remember { mutableIntStateOf(18) }
    var draftEndMinute by remember { mutableIntStateOf(0) }
    var draftQuotes by remember { mutableStateOf(listOf<String>()) }
    var editingDraftQuoteIndex by remember { mutableStateOf<Int?>(null) }
    var editingDraftQuoteText by remember { mutableStateOf<String?>(null) }

    // Dialog states
    var showTimeRangeDialog by remember { mutableStateOf(false) }
    var showBulkEditDialog by remember { mutableStateOf(false) }
    var showSingleQuoteDialog by remember { mutableStateOf(false) }
    var editingQuote by remember { mutableStateOf<QuoteEntity?>(null) }
    var showOptionsMenu by remember { mutableStateOf(false) }

    // Handle system back button when inside a profile or creating a profile
    BackHandler(enabled = isCreatingProfile || viewingProfile != null) {
        if (isCreatingProfile) {
            isCreatingProfile = false // Discard without saving!
        } else {
            viewingProfile = null
        }
    }

    // Keep viewingProfile reference up-to-date with uiState updates
    LaunchedEffect(uiState.profiles, viewingProfile) {
        viewingProfile?.let { current ->
            val updated = uiState.profiles.find { it.id == current.id }
            if (updated != null) {
                viewingProfile = updated
            } else {
                viewingProfile = null
            }
        }
    }

    // Notification permission check for Android 13+
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    LaunchedEffect(uiState.statusMessage) {
        uiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissStatusMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when {
                            isCreatingProfile -> "New Profile Settings"
                            viewingProfile != null -> viewingProfile?.name ?: "Profile Settings"
                            else -> "Profiles"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    if (isCreatingProfile) {
                        IconButton(
                            onClick = { isCreatingProfile = false },
                            modifier = Modifier.testTag("cancel_new_profile_button")
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Discard and return")
                        }
                    } else if (viewingProfile != null) {
                        IconButton(
                            onClick = { viewingProfile = null },
                            modifier = Modifier.testTag("back_to_profiles_button")
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back to Profiles")
                        }
                    }
                },
                actions = {
                    if (isCreatingProfile) {
                        Button(
                            onClick = {
                                if (draftName.isNotBlank()) {
                                    viewModel.createProfileWithQuotes(
                                        name = draftName.trim(),
                                        description = draftDescription.trim(),
                                        startH = draftStartHour,
                                        startM = draftStartMinute,
                                        endH = draftEndHour,
                                        endM = draftEndMinute,
                                        quotes = draftQuotes
                                    )
                                    isCreatingProfile = false
                                }
                            },
                            enabled = draftName.isNotBlank(),
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("save_profile_button"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    } else if (viewingProfile != null) {
                        Box {
                            IconButton(
                                onClick = { showOptionsMenu = true },
                                modifier = Modifier.testTag("more_options_button")
                            ) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More Options")
                            }

                            DropdownMenu(
                                expanded = showOptionsMenu,
                                onDismissRequest = { showOptionsMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Restore Starter Quotes") },
                                    onClick = {
                                        showOptionsMenu = false
                                        viewModel.restoreDefaultQuotesForActiveProfile()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.Restore, contentDescription = null)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Clear All Quotes") },
                                    onClick = {
                                        showOptionsMenu = false
                                        viewModel.clearAllQuotesForActiveProfile()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            if (isCreatingProfile) {
                FloatingActionButton(
                    onClick = {
                        editingDraftQuoteIndex = null
                        editingDraftQuoteText = null
                        showSingleQuoteDialog = true
                    },
                    modifier = Modifier.testTag("add_quote_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Quote")
                }
            } else if (viewingProfile == null) {
                FloatingActionButton(
                    onClick = {
                        // Open full settings instead of preview dialog
                        draftName = ""
                        draftDescription = ""
                        draftStartHour = 9
                        draftStartMinute = 0
                        draftEndHour = 18
                        draftEndMinute = 0
                        draftQuotes = emptyList()
                        editingDraftQuoteIndex = null
                        editingDraftQuoteText = null
                        isCreatingProfile = true
                    },
                    modifier = Modifier.testTag("add_profile_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Profile")
                }
            } else {
                FloatingActionButton(
                    onClick = {
                        editingQuote = null
                        showSingleQuoteDialog = true
                    },
                    modifier = Modifier.testTag("add_quote_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Quote")
                }
            }
        }
    ) { innerPadding ->
        when {
            isCreatingProfile -> {
                NewProfileSettingsContent(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    draftName = draftName,
                    onDraftNameChange = { draftName = it },
                    draftDescription = draftDescription,
                    onDraftDescriptionChange = { draftDescription = it },
                    startHour = draftStartHour,
                    startMinute = draftStartMinute,
                    endHour = draftEndHour,
                    endMinute = draftEndMinute,
                    onChangeTimeRange = { showTimeRangeDialog = true },
                    draftQuotes = draftQuotes,
                    onAddQuote = {
                        editingDraftQuoteIndex = null
                        editingDraftQuoteText = null
                        showSingleQuoteDialog = true
                    },
                    onEditQuote = { index, text ->
                        editingDraftQuoteIndex = index
                        editingDraftQuoteText = text
                        showSingleQuoteDialog = true
                    },
                    onDeleteQuote = { index ->
                        draftQuotes = draftQuotes.filterIndexed { i, _ -> i != index }
                    },
                    onBulkEdit = { showBulkEditDialog = true },
                    onRestoreStarterQuotes = {
                        draftQuotes = listOf(
                            "The only way to do great work is to love what you do.",
                            "Do what you can, with what you have, where you are.",
                            "Act as if what you do makes a difference. It does."
                        )
                    },
                    onSendTestNotification = {
                        val text = if (draftQuotes.isNotEmpty()) draftQuotes.random() else "This is a test notification for your new profile!"
                        NotificationHelper.showQuoteNotification(context, text)
                    },
                    onSave = {
                        if (draftName.isNotBlank()) {
                            viewModel.createProfileWithQuotes(
                                name = draftName.trim(),
                                description = draftDescription.trim(),
                                startH = draftStartHour,
                                startM = draftStartMinute,
                                endH = draftEndHour,
                                endM = draftEndMinute,
                                quotes = draftQuotes
                            )
                            isCreatingProfile = false
                        }
                    },
                    onCancel = { isCreatingProfile = false }
                )
            }
            viewingProfile == null -> {
                // DEFAULT PAGE: Profile List with on/off switch per profile & tap to open settings
                ProfilesListContent(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    profiles = uiState.profiles,
                    activeProfileId = uiState.activeProfileId,
                    isGloballyEnabled = uiState.isEnabled,
                    hasNotificationPermission = hasNotificationPermission,
                    onEnablePermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onToggleProfile = { profile, turnOn ->
                        if (turnOn) {
                            if (uiState.activeProfileId != profile.id) {
                                viewModel.selectProfile(profile.id)
                            }
                            if (!uiState.isEnabled) {
                                viewModel.toggleEnabled(true)
                            }
                        } else {
                            // Turning off
                            if (uiState.activeProfileId == profile.id) {
                                viewModel.toggleEnabled(false)
                            }
                        }
                    },
                    onOpenProfile = { profile ->
                        if (uiState.activeProfileId != profile.id) {
                            viewModel.selectProfile(profile.id)
                        }
                        viewingProfile = profile
                    },
                    onDeleteProfile = { profileId ->
                        viewModel.deleteProfile(profileId)
                    }
                )
            }
            else -> {
                // INSIDE PROFILE: Main Settings & Quotes management
                val profile = viewingProfile!!
                ProfileSettingsContent(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    profile = profile,
                    uiState = uiState,
                    onToggleEnabled = { viewModel.toggleEnabled(it) },
                    onChangeTimeRange = { showTimeRangeDialog = true },
                    onSendTestNotification = { viewModel.sendTestNotification() },
                    onBulkEdit = { showBulkEditDialog = true },
                    onSearchChange = { viewModel.setSearchQuery(it) },
                    onAddQuote = {
                        editingQuote = null
                        showSingleQuoteDialog = true
                    },
                    onEditQuote = { quote ->
                        editingQuote = quote
                        showSingleQuoteDialog = true
                    },
                    onDeleteQuote = { viewModel.deleteQuote(it.id) },
                    onRestoreDefaults = { viewModel.restoreDefaultQuotesForActiveProfile() }
                )
            }
        }
    }

    // Dialogs
    if (showTimeRangeDialog) {
        val initStartH = if (isCreatingProfile) draftStartHour else (viewingProfile?.startHour ?: 9)
        val initStartM = if (isCreatingProfile) draftStartMinute else (viewingProfile?.startMinute ?: 0)
        val initEndH = if (isCreatingProfile) draftEndHour else (viewingProfile?.endHour ?: 18)
        val initEndM = if (isCreatingProfile) draftEndMinute else (viewingProfile?.endMinute ?: 0)

        TimeRangePickerDialog(
            initialStartHour = initStartH,
            initialStartMinute = initStartM,
            initialEndHour = initEndH,
            initialEndMinute = initEndM,
            onDismiss = { showTimeRangeDialog = false },
            onConfirm = { sH, sM, eH, eM ->
                if (isCreatingProfile) {
                    draftStartHour = sH
                    draftStartMinute = sM
                    draftEndHour = eH
                    draftEndMinute = eM
                } else {
                    viewModel.updateTimeRange(sH, sM, eH, eM)
                }
                showTimeRangeDialog = false
            }
        )
    }

    if (showBulkEditDialog) {
        val quotesForDialog = if (isCreatingProfile) {
            draftQuotes.map { QuoteEntity(text = it) }
        } else {
            uiState.quotes
        }
        BulkQuotesDialog(
            existingQuotes = quotesForDialog,
            onDismiss = { showBulkEditDialog = false },
            onSave = { rawText, replaceExisting ->
                if (isCreatingProfile) {
                    val parsed = rawText.split(Regex("\\r?\\n\\s*\\r?\\n"))
                        .map { it.trim().removeSurrounding("\"") }
                        .filter { it.isNotBlank() }
                    draftQuotes = if (replaceExisting) {
                        parsed
                    } else {
                        draftQuotes + parsed
                    }
                } else {
                    viewModel.saveBulkQuotes(rawText, replaceExisting)
                }
                showBulkEditDialog = false
            }
        )
    }

    if (showSingleQuoteDialog) {
        val initialQuote = if (isCreatingProfile) {
            if (editingDraftQuoteText != null) QuoteEntity(text = editingDraftQuoteText!!) else null
        } else {
            editingQuote
        }
        SingleQuoteDialog(
            initialQuote = initialQuote,
            onDismiss = {
                showSingleQuoteDialog = false
                editingQuote = null
                editingDraftQuoteIndex = null
                editingDraftQuoteText = null
            },
            onConfirm = { text ->
                if (isCreatingProfile) {
                    val idx = editingDraftQuoteIndex
                    if (idx != null && idx in draftQuotes.indices) {
                        draftQuotes = draftQuotes.toMutableList().apply { set(idx, text) }
                    } else {
                        draftQuotes = draftQuotes + text
                    }
                } else {
                    if (editingQuote != null) {
                        viewModel.updateQuote(editingQuote!!.copy(text = text))
                    } else {
                        viewModel.addQuote(text)
                    }
                }
                showSingleQuoteDialog = false
                editingQuote = null
                editingDraftQuoteIndex = null
                editingDraftQuoteText = null
            }
        )
    }
}

@Composable
fun ProfilesListContent(
    modifier: Modifier = Modifier,
    profiles: List<ProfileEntity>,
    activeProfileId: Int,
    isGloballyEnabled: Boolean,
    hasNotificationPermission: Boolean,
    onEnablePermission: () -> Unit,
    onToggleProfile: (ProfileEntity, Boolean) -> Unit,
    onOpenProfile: (ProfileEntity) -> Unit,
    onDeleteProfile: (Int) -> Unit
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("permission_warning_card")
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.NotificationsOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "Notifications disabled",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onEnablePermission) {
                            Text("Enable")
                        }
                    }
                }
            }
        }

        items(profiles, key = { it.id }) { profile ->
            val isActive = profile.id == activeProfileId && isGloballyEnabled

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = if (isActive) 2.dp else 0.5.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenProfile(profile) }
                    .testTag("profile_card_${profile.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Text(
                            text = profile.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (profile.description.isNotBlank()) {
                            Text(
                                text = profile.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "${formatHourMinute(profile.startHour, profile.startMinute)} – ${formatHourMinute(profile.endHour, profile.endMinute)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Switch(
                            checked = isActive,
                            onCheckedChange = { isChecked ->
                                onToggleProfile(profile, isChecked)
                            },
                            modifier = Modifier.testTag("toggle_profile_${profile.id}")
                        )

                        if (profiles.size > 1) {
                            IconButton(
                                onClick = { onDeleteProfile(profile.id) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("delete_profile_${profile.id}")
                            ) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "Delete Profile",
                                    modifier = Modifier.size(18.dp),
                                    tint = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
fun ProfileSettingsContent(
    modifier: Modifier = Modifier,
    profile: ProfileEntity,
    uiState: ReminderUiState,
    onToggleEnabled: (Boolean) -> Unit,
    onChangeTimeRange: () -> Unit,
    onSendTestNotification: () -> Unit,
    onBulkEdit: () -> Unit,
    onSearchChange: (String) -> Unit,
    onAddQuote: () -> Unit,
    onEditQuote: (QuoteEntity) -> Unit,
    onDeleteQuote: (QuoteEntity) -> Unit,
    onRestoreDefaults: () -> Unit
) {
    val startFormatted = formatHourMinute(profile.startHour, profile.startMinute)
    val endFormatted = formatHourMinute(profile.endHour, profile.endMinute)

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Main Settings Card for this Profile
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_settings_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Switch row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (uiState.isEnabled) "Reminders Active" else "Reminders Off",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )

                        Switch(
                            checked = uiState.isEnabled,
                            onCheckedChange = onToggleEnabled,
                            modifier = Modifier.testTag("profile_toggle_switch")
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

                    // Time Window row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Daily Window: $startFormatted – $endFormatted",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        TextButton(
                            onClick = onChangeTimeRange,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("change_time_range_button")
                        ) {
                            Text("Change Window", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    // Dedicated Test Notification Button
                    OutlinedButton(
                        onClick = onSendTestNotification,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_test_notification_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            Icons.Default.NotificationsActive,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Test Notification", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Quotes Section Header
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Quotes (${uiState.quotes.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    TextButton(
                        onClick = onBulkEdit,
                        modifier = Modifier.testTag("bulk_edit_quotes_button"),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bulk Edit", style = MaterialTheme.typography.labelMedium)
                    }
                }

                // Search input
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = onSearchChange,
                    placeholder = { Text("Search quotes...", style = MaterialTheme.typography.bodySmall) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("search_quotes_input")
                )
            }
        }

        // Quotes list
        if (uiState.filteredQuotes.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (uiState.searchQuery.isNotEmpty()) "No matching quotes" else "No quotes in this profile",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (uiState.searchQuery.isNotEmpty()) "Try a different search term." else "Add quotes individually or bulk paste them.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (uiState.searchQuery.isEmpty()) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Button(onClick = onBulkEdit, shape = RoundedCornerShape(8.dp)) {
                                    Text("Bulk Add", style = MaterialTheme.typography.labelMedium)
                                }
                                OutlinedButton(onClick = onRestoreDefaults, shape = RoundedCornerShape(8.dp)) {
                                    Text("Starter Quotes", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            items(
                items = uiState.filteredQuotes,
                key = { it.id }
            ) { quote ->
                QuoteItemCard(
                    quote = quote,
                    onEdit = onEditQuote,
                    onDelete = { onDeleteQuote(quote) },
                    onCopied = {}
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
fun NewProfileSettingsContent(
    modifier: Modifier = Modifier,
    draftName: String,
    onDraftNameChange: (String) -> Unit,
    draftDescription: String,
    onDraftDescriptionChange: (String) -> Unit,
    startHour: Int,
    startMinute: Int,
    endHour: Int,
    endMinute: Int,
    onChangeTimeRange: () -> Unit,
    draftQuotes: List<String>,
    onAddQuote: () -> Unit,
    onEditQuote: (Int, String) -> Unit,
    onDeleteQuote: (Int) -> Unit,
    onBulkEdit: () -> Unit,
    onRestoreStarterQuotes: () -> Unit,
    onSendTestNotification: () -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit
) {
    val startFormatted = formatHourMinute(startHour, startMinute)
    val endFormatted = formatHourMinute(endHour, endMinute)

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Notice banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Configure settings and quotes for this new profile. Tap 'Save' to create it, or Discard to cancel without saving.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Profile Details Card
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("new_profile_details_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Profile Information",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )

                    OutlinedTextField(
                        value = draftName,
                        onValueChange = onDraftNameChange,
                        label = { Text("Profile Name *") },
                        placeholder = { Text("e.g. Work, Zen, Philosophy") },
                        singleLine = true,
                        isError = draftName.isBlank(),
                        supportingText = {
                            if (draftName.isBlank()) {
                                Text("Profile name is required to save")
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_profile_name_input")
                    )

                    OutlinedTextField(
                        value = draftDescription,
                        onValueChange = onDraftDescriptionChange,
                        label = { Text("Description (Optional)") },
                        placeholder = { Text("e.g. Daily inspiration for work hours") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Surprise Window Card
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("new_profile_window_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Daily Window: $startFormatted – $endFormatted",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Quotes will be sent at a random time in this window",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        TextButton(
                            onClick = onChangeTimeRange,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.testTag("change_time_range_button")
                        ) {
                            Text("Change Window", style = MaterialTheme.typography.labelMedium)
                        }
                    }

                    // Test Notification Button
                    OutlinedButton(
                        onClick = onSendTestNotification,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("send_test_notification_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            Icons.Default.NotificationsActive,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Test Notification", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Quotes Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quotes (${draftQuotes.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = onBulkEdit,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("bulk_edit_quotes_button")
                    ) {
                        Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bulk Add", style = MaterialTheme.typography.labelMedium)
                    }
                    TextButton(
                        onClick = onAddQuote,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("add_quote_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // Quotes list or empty state
        if (draftQuotes.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "No quotes in this profile yet",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Add quotes individually, bulk paste, or start with sample quotes.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Button(onClick = onRestoreStarterQuotes, shape = RoundedCornerShape(8.dp)) {
                                Text("Starter Quotes", style = MaterialTheme.typography.labelMedium)
                            }
                            OutlinedButton(onClick = onBulkEdit, shape = RoundedCornerShape(8.dp)) {
                                Text("Bulk Add", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        } else {
            items(
                count = draftQuotes.size,
                key = { index -> index }
            ) { index ->
                val quoteText = draftQuotes[index]
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = quoteText,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                        Row {
                            IconButton(
                                onClick = { onEditQuote(index, quoteText) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = "Edit quote",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = { onDeleteQuote(index) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "Delete quote",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Buttons (Save / Discard)
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("cancel_new_profile_button")
                ) {
                    Text("Discard", style = MaterialTheme.typography.labelLarge)
                }

                Button(
                    onClick = onSave,
                    enabled = draftName.isNotBlank(),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_new_profile_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Profile", style = MaterialTheme.typography.labelLarge)
                }
            }
            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}
