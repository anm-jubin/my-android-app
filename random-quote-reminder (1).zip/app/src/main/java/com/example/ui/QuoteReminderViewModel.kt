package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.data.local.AppDatabase
import com.example.data.local.DeliveredNotificationEntity
import com.example.data.local.ProfileEntity
import com.example.data.local.QuoteEntity
import com.example.data.preferences.ReminderPreferences
import com.example.data.repository.QuoteRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class ReminderUiState(
    val isEnabled: Boolean = true,
    val startHour: Int = 9,
    val startMinute: Int = 0,
    val endHour: Int = 18,
    val endMinute: Int = 0,
    val nextScheduledTimeMillis: Long = 0L,
    val profiles: List<ProfileEntity> = emptyList(),
    val activeProfile: ProfileEntity? = null,
    val activeProfileId: Int = 1,
    val quotes: List<QuoteEntity> = emptyList(),
    val filteredQuotes: List<QuoteEntity> = emptyList(),
    val searchQuery: String = "",
    val statusMessage: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class QuoteReminderViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: QuoteRepository
    private val prefs: ReminderPreferences = ReminderPreferences(application)

    private val _activeProfileId = MutableStateFlow(prefs.activeProfileId)
    private val _searchQuery = MutableStateFlow("")
    private val _statusMessage = MutableStateFlow<String?>(null)

    private val _scheduleState = MutableStateFlow(
        Pair(prefs.isEnabled, prefs.nextScheduledTimeMillis)
    )

    val uiState: StateFlow<ReminderUiState>

    init {
        val database = AppDatabase.getInstance(application)
        repository = QuoteRepository(database.quoteDao())

        // Quotes flow reacting to the currently selected profile
        val quotesFlow = _activeProfileId.flatMapLatest { profileId ->
            repository.getQuotesForProfile(profileId)
        }

        uiState = combine(
            repository.allProfiles,
            _activeProfileId,
            quotesFlow,
            _searchQuery,
            _statusMessage,
            _scheduleState
        ) { args: Array<Any?> ->
            @Suppress("UNCHECKED_CAST")
            val profiles = args[0] as List<ProfileEntity>
            val activeId = args[1] as Int
            @Suppress("UNCHECKED_CAST")
            val quotes = args[2] as List<QuoteEntity>
            val query = args[3] as String
            val msg = args[4] as String?
            @Suppress("UNCHECKED_CAST")
            val schedule = args[5] as Pair<Boolean, Long>

            val currentProfile = profiles.find { it.id == activeId } ?: profiles.firstOrNull()
            val effectiveProfileId = currentProfile?.id ?: activeId

            val startH = currentProfile?.startHour ?: prefs.startHour
            val startM = currentProfile?.startMinute ?: prefs.startMinute
            val endH = currentProfile?.endHour ?: prefs.endHour
            val endM = currentProfile?.endMinute ?: prefs.endMinute

            val filtered = if (query.isBlank()) {
                quotes
            } else {
                quotes.filter {
                    it.text.contains(query, ignoreCase = true)
                }
            }

            ReminderUiState(
                isEnabled = schedule.first,
                startHour = startH,
                startMinute = startM,
                endHour = endH,
                endMinute = endM,
                nextScheduledTimeMillis = schedule.second,
                profiles = profiles,
                activeProfile = currentProfile,
                activeProfileId = effectiveProfileId,
                quotes = quotes,
                filteredQuotes = filtered,
                searchQuery = query,
                statusMessage = msg
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ReminderUiState(
                isEnabled = prefs.isEnabled,
                nextScheduledTimeMillis = prefs.nextScheduledTimeMillis,
                activeProfileId = prefs.activeProfileId
            )
        )

        // Pre-populate default profiles and sample quotes on first launch
        viewModelScope.launch {
            repository.initializeDefaultProfilesAndQuotesIfEmpty()
            refreshScheduledAlarm(forceReshuffle = false)
        }
    }

    fun selectProfile(profileId: Int) {
        prefs.activeProfileId = profileId
        _activeProfileId.value = profileId

        // Update schedule for this profile
        viewModelScope.launch {
            val profile = repository.getProfileById(profileId)
            if (profile != null) {
                prefs.startHour = profile.startHour
                prefs.startMinute = profile.startMinute
                prefs.endHour = profile.endHour
                prefs.endMinute = profile.endMinute
            }
            if (prefs.isEnabled) {
                val context = getApplication<Application>()
                val nextMillis = AlarmScheduler.scheduleNextAlarmForActiveProfile(context, forceNewRandom = true)
                _scheduleState.value = Pair(true, nextMillis)
                _statusMessage.value = "Active: ${profile?.name ?: "profile"}"
            } else {
                _statusMessage.value = "Selected: ${profile?.name ?: "profile"}"
            }
        }
    }

    fun addProfile(name: String, description: String, startH: Int, endH: Int) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val newId = repository.insertProfile(name, description, startH, endH).toInt()
            selectProfile(newId)
            _statusMessage.value = "Created profile '$name'"
        }
    }

    fun createProfileWithQuotes(
        name: String,
        description: String,
        startH: Int,
        startM: Int,
        endH: Int,
        endM: Int,
        quotes: List<String>
    ) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val newId = repository.insertProfile(name, description, startH, startM, endH, endM).toInt()
            if (quotes.isNotEmpty()) {
                val quotePairs = quotes.filter { it.isNotBlank() }.map { Pair(it, "") }
                repository.insertBulkQuotes(newId, quotePairs)
            }
            selectProfile(newId)
            _statusMessage.value = "Profile '$name' created and saved"
        }
    }

    fun updateProfile(profile: ProfileEntity) {
        viewModelScope.launch {
            repository.updateProfile(profile)
            if (profile.id == _activeProfileId.value) {
                prefs.startHour = profile.startHour
                prefs.startMinute = profile.startMinute
                prefs.endHour = profile.endHour
                prefs.endMinute = profile.endMinute
                if (prefs.isEnabled) {
                    val context = getApplication<Application>()
                    val nextMillis = AlarmScheduler.scheduleNextAlarmForActiveProfile(context, forceNewRandom = true)
                    _scheduleState.value = Pair(true, nextMillis)
                }
            }
            _statusMessage.value = "Profile '${profile.name}' updated"
        }
    }

    fun deleteProfile(profileId: Int) {
        viewModelScope.launch {
            val profiles = repository.allProfiles.first()
            if (profiles.size <= 1) {
                _statusMessage.value = "Cannot delete the only profile"
                return@launch
            }
            repository.deleteProfile(profileId)
            val remaining = profiles.filter { it.id != profileId }
            val nextProfile = remaining.first()
            selectProfile(nextProfile.id)
            _statusMessage.value = "Profile deleted"
        }
    }

    fun toggleEnabled(enabled: Boolean) {
        prefs.isEnabled = enabled
        val context = getApplication<Application>()
        if (enabled) {
            viewModelScope.launch {
                val nextMillis = AlarmScheduler.scheduleNextAlarmForActiveProfile(context, forceNewRandom = true)
                _scheduleState.value = Pair(true, nextMillis)
                _statusMessage.value = "Daily reminders enabled"
            }
        } else {
            AlarmScheduler.cancelAlarm(context)
            _scheduleState.value = Pair(false, 0L)
            _statusMessage.value = "Reminders paused"
        }
    }

    fun updateTimeRange(startH: Int, startM: Int, endH: Int, endM: Int) {
        val activeId = _activeProfileId.value
        viewModelScope.launch {
            val currentProfile = repository.getProfileById(activeId)
            if (currentProfile != null) {
                repository.updateProfile(
                    currentProfile.copy(
                        startHour = startH,
                        startMinute = startM,
                        endHour = endH,
                        endMinute = endM
                    )
                )
            }
            prefs.updateTimeRange(startH, startM, endH, endM)

            val context = getApplication<Application>()
            val nextMillis = if (prefs.isEnabled) {
                AlarmScheduler.scheduleNextAlarmForActiveProfile(context, forceNewRandom = true)
            } else 0L

            _scheduleState.value = Pair(prefs.isEnabled, nextMillis)
            _statusMessage.value = "Time window updated"
        }
    }

    fun sendTestNotification() {
        val context = getApplication<Application>()
        viewModelScope.launch {
            val quotes = repository.getQuotesForProfile(_activeProfileId.value).first()
            val quoteText = if (quotes.isNotEmpty()) {
                quotes.random().text
            } else {
                "This is a test notification for your quotes!"
            }
            NotificationHelper.showQuoteNotification(context, quoteText)
            _statusMessage.value = "Test notification sent"
        }
    }

    fun addQuote(text: String) {
        if (text.isBlank()) return
        val profileId = _activeProfileId.value
        viewModelScope.launch {
            repository.insertQuote(profileId, text, "")
            _statusMessage.value = "Quote added"
        }
    }

    fun updateQuote(quote: QuoteEntity) {
        viewModelScope.launch {
            repository.updateQuote(quote)
            _statusMessage.value = "Quote updated"
        }
    }

    fun deleteQuote(id: Int) {
        viewModelScope.launch {
            repository.deleteQuote(id)
            _statusMessage.value = "Quote deleted"
        }
    }

    fun restoreDefaultQuotesForActiveProfile() {
        val profileId = _activeProfileId.value
        viewModelScope.launch {
            val sampleQuotes = listOf(
                Pair("The only way to do great work is to love what you do.", ""),
                Pair("Do what you can, with what you have, where you are.", ""),
                Pair("Act as if what you do makes a difference. It does.", "")
            )
            repository.insertBulkQuotes(profileId, sampleQuotes)
            _statusMessage.value = "Default quotes restored"
        }
    }

    fun clearAllQuotesForActiveProfile() {
        val profileId = _activeProfileId.value
        viewModelScope.launch {
            repository.deleteAllQuotesForProfile(profileId)
            _statusMessage.value = "Quotes cleared"
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun dismissStatusMessage() {
        _statusMessage.value = null
    }

    fun saveBulkQuotes(rawText: String, replaceExisting: Boolean) {
        val profileId = _activeProfileId.value
        viewModelScope.launch {
            val quotes = rawText.split(Regex("\\r?\\n\\s*\\r?\\n"))
                .map { it.trim().removeSurrounding("\"") }
                .filter { it.isNotBlank() }
                .map { Pair(it, "") }

            if (quotes.isEmpty()) {
                _statusMessage.value = "No valid quotes found"
                return@launch
            }

            if (replaceExisting) {
                repository.deleteAllQuotesForProfile(profileId)
            }
            repository.insertBulkQuotes(profileId, quotes)
            _statusMessage.value = "Saved ${quotes.size} quotes"
        }
    }

    private fun refreshScheduledAlarm(forceReshuffle: Boolean) {
        val context = getApplication<Application>()
        if (prefs.isEnabled) {
            viewModelScope.launch {
                val nextMillis = AlarmScheduler.scheduleNextAlarmForActiveProfile(context, forceNewRandom = forceReshuffle)
                _scheduleState.value = Pair(true, nextMillis)
            }
        }
    }

    private fun formatTime(millis: Long): String {
        if (millis <= 0L) return "Not scheduled"
        val sdf = SimpleDateFormat("EEE, MMM d 'at' h:mm a", Locale.getDefault())
        return sdf.format(Date(millis))
    }
}
