package com.example.data.repository

import com.example.data.local.DeliveredNotificationEntity
import com.example.data.local.ProfileEntity
import com.example.data.local.QuoteDao
import com.example.data.local.QuoteEntity
import kotlinx.coroutines.flow.Flow

class QuoteRepository(private val quoteDao: QuoteDao) {

    val allProfiles: Flow<List<ProfileEntity>> = quoteDao.getAllProfiles()
    val deliveredHistory: Flow<List<DeliveredNotificationEntity>> = quoteDao.getDeliveredHistory()

    fun getQuotesForProfile(profileId: Int): Flow<List<QuoteEntity>> =
        quoteDao.getQuotesForProfile(profileId)

    suspend fun getQuotesListForProfile(profileId: Int): List<QuoteEntity> =
        quoteDao.getQuotesListForProfile(profileId)

    fun getQuotesCountForProfile(profileId: Int): Flow<Int> =
        quoteDao.getQuotesCountForProfile(profileId)

    suspend fun insertProfile(
        name: String,
        description: String = "",
        startHour: Int = 9,
        startMinute: Int = 0,
        endHour: Int = 18,
        endMinute: Int = 0
    ): Long {
        return quoteDao.insertProfile(
            ProfileEntity(
                name = name.trim(),
                description = description.trim(),
                startHour = startHour,
                startMinute = startMinute,
                endHour = endHour,
                endMinute = endMinute,
                isEnabled = true
            )
        )
    }

    suspend fun updateProfile(profile: ProfileEntity) {
        quoteDao.updateProfile(profile)
    }

    suspend fun deleteProfile(profileId: Int) {
        quoteDao.deleteAllQuotesForProfile(profileId)
        quoteDao.deleteProfileById(profileId)
    }

    suspend fun getProfileById(profileId: Int): ProfileEntity? {
        return quoteDao.getProfileById(profileId)
    }

    suspend fun insertQuote(profileId: Int, text: String, author: String = ""): Long {
        return quoteDao.insertQuote(
            QuoteEntity(
                profileId = profileId,
                text = text.trim(),
                author = author.trim()
            )
        )
    }

    suspend fun updateQuote(quote: QuoteEntity) {
        quoteDao.updateQuote(quote)
    }

    suspend fun deleteQuote(id: Int) {
        quoteDao.deleteQuoteById(id)
    }

    suspend fun deleteAllQuotesForProfile(profileId: Int) {
        quoteDao.deleteAllQuotesForProfile(profileId)
    }

    suspend fun insertBulkQuotes(profileId: Int, quotes: List<Pair<String, String>>) {
        val entities = quotes.map { (text, author) ->
            QuoteEntity(
                profileId = profileId,
                text = text.trim(),
                author = author.trim()
            )
        }
        quoteDao.insertQuotes(entities)
    }

    suspend fun getRandomQuoteForProfile(profileId: Int): QuoteEntity? {
        return quoteDao.getRandomQuoteForProfile(profileId) ?: quoteDao.getRandomQuoteAny()
    }

    suspend fun logDeliveredNotification(profileId: Int, profileName: String, quoteText: String, author: String) {
        quoteDao.insertDelivered(
            DeliveredNotificationEntity(
                profileId = profileId,
                profileName = profileName,
                quoteText = quoteText,
                author = author
            )
        )
    }

    suspend fun clearDeliveredHistory() {
        quoteDao.clearDeliveredHistory()
    }

    suspend fun initializeDefaultProfilesAndQuotesIfEmpty() {
        val profiles = quoteDao.getAllProfilesList()
        if (profiles.isEmpty()) {
            val defaultProfileId = quoteDao.insertProfile(
                ProfileEntity(
                    id = 1,
                    name = "Default",
                    description = "",
                    startHour = 9,
                    startMinute = 0,
                    endHour = 18,
                    endMinute = 0,
                    isEnabled = true,
                    isDefault = true
                )
            ).toInt()

            val initialQuotes = listOf(
                Pair("The only way to do great work is to love what you do.", ""),
                Pair("Do what you can, with what you have, where you are.", ""),
                Pair("Act as if what you do makes a difference. It does.", "")
            )
            insertBulkQuotes(defaultProfileId, initialQuotes)
        }
    }
}
