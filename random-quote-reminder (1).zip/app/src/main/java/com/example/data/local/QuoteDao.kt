package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface QuoteDao {

    // Profiles
    @Query("SELECT * FROM profiles ORDER BY id ASC")
    fun getAllProfiles(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profiles ORDER BY id ASC")
    suspend fun getAllProfilesList(): List<ProfileEntity>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Int): ProfileEntity?

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    fun getProfileFlowById(id: Int): Flow<ProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity): Long

    @Update
    suspend fun updateProfile(profile: ProfileEntity)

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteProfileById(id: Int)

    // Quotes by profile
    @Query("SELECT * FROM quotes WHERE profileId = :profileId ORDER BY id DESC")
    fun getQuotesForProfile(profileId: Int): Flow<List<QuoteEntity>>

    @Query("SELECT * FROM quotes WHERE profileId = :profileId")
    suspend fun getQuotesListForProfile(profileId: Int): List<QuoteEntity>

    @Query("SELECT * FROM quotes WHERE profileId = :profileId ORDER BY RANDOM() LIMIT 1")
    suspend fun getRandomQuoteForProfile(profileId: Int): QuoteEntity?

    @Query("SELECT * FROM quotes ORDER BY RANDOM() LIMIT 1")
    suspend fun getRandomQuoteAny(): QuoteEntity?

    @Query("SELECT COUNT(*) FROM quotes WHERE profileId = :profileId")
    fun getQuotesCountForProfile(profileId: Int): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuote(quote: QuoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotes(quotes: List<QuoteEntity>)

    @Update
    suspend fun updateQuote(quote: QuoteEntity)

    @Query("DELETE FROM quotes WHERE id = :id")
    suspend fun deleteQuoteById(id: Int)

    @Query("DELETE FROM quotes WHERE profileId = :profileId")
    suspend fun deleteAllQuotesForProfile(profileId: Int)

    // Delivered history
    @Query("SELECT * FROM delivered_notifications ORDER BY deliveredAt DESC LIMIT 50")
    fun getDeliveredHistory(): Flow<List<DeliveredNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDelivered(notification: DeliveredNotificationEntity): Long

    @Query("DELETE FROM delivered_notifications")
    suspend fun clearDeliveredHistory()
}
