package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val description: String = "",
    val startHour: Int = 9,
    val startMinute: Int = 0,
    val endHour: Int = 18,
    val endMinute: Int = 0,
    val isEnabled: Boolean = true,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "quotes")
data class QuoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val profileId: Int = 1,
    val text: String,
    val author: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "delivered_notifications")
data class DeliveredNotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val profileId: Int = 1,
    val profileName: String = "",
    val quoteText: String,
    val author: String = "",
    val deliveredAt: Long = System.currentTimeMillis()
)
