package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import java.util.TimeZone

class ReminderPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "random_quote_reminder_prefs"
        private const val KEY_ACTIVE_PROFILE_ID = "active_profile_id"
        private const val KEY_ENABLED = "is_enabled"
        private const val KEY_START_HOUR = "start_hour"
        private const val KEY_START_MINUTE = "start_minute"
        private const val KEY_END_HOUR = "end_hour"
        private const val KEY_END_MINUTE = "end_minute"
        private const val KEY_TIME_ZONE_ID = "time_zone_id"
        private const val KEY_NEXT_SCHEDULED_MILLIS = "next_scheduled_millis"
        private const val KEY_LAST_DELIVERED_QUOTE = "last_delivered_quote"
        private const val KEY_LAST_DELIVERED_AUTHOR = "last_delivered_author"
        private const val KEY_LAST_DELIVERED_TIME = "last_delivered_time"
    }

    var activeProfileId: Int
        get() = prefs.getInt(KEY_ACTIVE_PROFILE_ID, 1)
        set(value) = prefs.edit().putInt(KEY_ACTIVE_PROFILE_ID, value).apply()

    var isEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var startHour: Int
        get() = prefs.getInt(KEY_START_HOUR, 9) // 9:00 AM
        set(value) = prefs.edit().putInt(KEY_START_HOUR, value).apply()

    var startMinute: Int
        get() = prefs.getInt(KEY_START_MINUTE, 0)
        set(value) = prefs.edit().putInt(KEY_START_MINUTE, value).apply()

    var endHour: Int
        get() = prefs.getInt(KEY_END_HOUR, 18) // 6:00 PM
        set(value) = prefs.edit().putInt(KEY_END_HOUR, value).apply()

    var endMinute: Int
        get() = prefs.getInt(KEY_END_MINUTE, 0)
        set(value) = prefs.edit().putInt(KEY_END_MINUTE, value).apply()

    var timeZoneId: String
        get() = prefs.getString(KEY_TIME_ZONE_ID, null) ?: TimeZone.getDefault().id
        set(value) = prefs.edit().putString(KEY_TIME_ZONE_ID, value).apply()

    var nextScheduledTimeMillis: Long
        get() = prefs.getLong(KEY_NEXT_SCHEDULED_MILLIS, 0L)
        set(value) = prefs.edit().putLong(KEY_NEXT_SCHEDULED_MILLIS, value).apply()

    var lastDeliveredQuote: String
        get() = prefs.getString(KEY_LAST_DELIVERED_QUOTE, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_DELIVERED_QUOTE, value).apply()

    var lastDeliveredAuthor: String
        get() = prefs.getString(KEY_LAST_DELIVERED_AUTHOR, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_DELIVERED_AUTHOR, value).apply()

    var lastDeliveredTimeMillis: Long
        get() = prefs.getLong(KEY_LAST_DELIVERED_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_DELIVERED_TIME, value).apply()

    fun updateTimeRange(startH: Int, startM: Int, endH: Int, endM: Int) {
        prefs.edit()
            .putInt(KEY_START_HOUR, startH)
            .putInt(KEY_START_MINUTE, startM)
            .putInt(KEY_END_HOUR, endH)
            .putInt(KEY_END_MINUTE, endM)
            .apply()
    }
}
