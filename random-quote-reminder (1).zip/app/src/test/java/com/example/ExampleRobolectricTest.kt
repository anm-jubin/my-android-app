package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.alarm.AlarmScheduler
import com.example.data.preferences.ReminderPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Random Quote Reminder", appName)
  }

  @Test
  fun `test alarm calculation within time range`() {
    val tz = TimeZone.getTimeZone("UTC")
    val randomTime = AlarmScheduler.calculateNextRandomTime(
      startHour = 15,
      startMinute = 0,
      endHour = 16,
      endMinute = 0,
      timeZone = tz
    )
    assertTrue("Calculated time must be positive", randomTime > 0)
  }

  @Test
  fun `test reminder preferences defaults`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = ReminderPreferences(context)
    assertTrue("Should be enabled by default", prefs.isEnabled)
    assertEquals(9, prefs.startHour)
    assertEquals(18, prefs.endHour)
    assertEquals(1, prefs.activeProfileId)
  }
}
