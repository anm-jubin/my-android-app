package com.example

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import android.media.MediaPlayer
import android.view.TextureView
import android.view.Surface
import android.graphics.SurfaceTexture
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    VRBrowserScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    var urlInput by remember { mutableStateOf("https://m.youtube.com") }
    var currentUrl by remember { mutableStateOf("https://m.youtube.com") }
    var isUiVisible by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(true) }
    var isDesktopMode by remember { mutableStateOf(true) }
    var isRightHandMode by remember { mutableStateOf(true) }
    var scale by remember { mutableFloatStateOf(1f) }
    var ipd by remember { mutableFloatStateOf(0f) }
    var verticalShift by remember { mutableFloatStateOf(0f) }

    var fabOffsetX by remember { mutableFloatStateOf(50f) }
    var fabOffsetY by remember { mutableFloatStateOf(300f) }

    var localVideoUri by remember { mutableStateOf<Uri?>(null) }
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            localVideoUri = uri
            isUiVisible = false
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        // The single WebView container, drawn twice using Compose rendering!
        // This completely eliminates sync lag, cuts network usage in half, 
        // and guarantees exact millisecond frame rendering.
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    val halfWidth = size.width / 2f
                    val halfHeight = size.height / 2f

                    if (isRightHandMode) {
                        // 1. Draw Right Eye (Original content, right half)
                        drawContext.canvas.save()
                        drawContext.canvas.translate(ipd, verticalShift)
                        drawContext.canvas.translate(halfWidth, halfHeight)
                        drawContext.canvas.scale(scale, scale)
                        drawContext.canvas.translate(-halfWidth, -halfHeight)
                        drawContent()
                        drawContext.canvas.restore()

                        // 2. Draw Left Eye (Mirror, shifted left by 1 full eyeWidth)
                        drawContext.canvas.save()
                        drawContext.canvas.translate(-size.width - ipd, verticalShift)
                        drawContext.canvas.translate(halfWidth, halfHeight)
                        drawContext.canvas.scale(scale, scale)
                        drawContext.canvas.translate(-halfWidth, -halfHeight)
                        drawContent()
                        drawContext.canvas.restore()
                    } else {
                        // 1. Draw Left Eye (Original content, left half)
                        drawContext.canvas.save()
                        drawContext.canvas.translate(-ipd, verticalShift)
                        drawContext.canvas.translate(halfWidth, halfHeight)
                        drawContext.canvas.scale(scale, scale)
                        drawContext.canvas.translate(-halfWidth, -halfHeight)
                        drawContent()
                        drawContext.canvas.restore()

                        // 2. Draw Right Eye (Mirror, shifted right by 1 full eyeWidth)
                        drawContext.canvas.save()
                        drawContext.canvas.translate(size.width + ipd, verticalShift)
                        drawContext.canvas.translate(halfWidth, halfHeight)
                        drawContext.canvas.scale(scale, scale)
                        drawContext.canvas.translate(-halfWidth, -halfHeight)
                        drawContent()
                        drawContext.canvas.restore()
                    }
                }
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(uri = localVideoUri!!)
            } else {
                SingleBrowser(
                    url = currentUrl,
                    isDesktopMode = isDesktopMode,
                    onLoadUrl = { 
                        currentUrl = it
                        isUiVisible = false
                    }
                )
            }
        }

        // Left Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        // Right Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .offset { IntOffset((fabOffsetX + eyeWidthPx).roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        if (isUiVisible) {
            Column(
                modifier = Modifier
                    .align(if (isRightHandMode) Alignment.TopEnd else Alignment.TopStart) // Constrain UI to active Screen
                    .width(eyeWidth)
                    .padding(8.dp)
            ) {
                // Address Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            videoPickerLauncher.launch("video/*")
                        }) {
                            Icon(Icons.Default.Folder, contentDescription = "Open Local Video", tint = Color.White)
                        }
                        IconButton(onClick = { urlInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { showControls = !showControls }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }
                }
                
                if (showControls) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Controls
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Right-Hand Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isRightHandMode, onCheckedChange = { isRightHandMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = scale,
                                onValueChange = { scale = it },
                                valueRange = 0.5f..1.5f
                            )
                            Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = ipd,
                                onValueChange = { ipd = it },
                                valueRange = -150f..150f
                            )
                            Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = verticalShift,
                                onValueChange = { verticalShift = it },
                                valueRange = -300f..300f
                            )
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingleBrowser(
    url: String,
    isDesktopMode: Boolean,
    onLoadUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            val frameLayout = android.widget.FrameLayout(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }

            val webView = WebView(context).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                webChromeClient = object : WebChromeClient() {
                    private var customView: android.view.View? = null
                    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                    override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                        if (customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        this@apply.visibility = android.view.View.GONE
                        frameLayout.addView(view, android.widget.FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                    }

                    override fun onHideCustomView() {
                        if (customView == null) return
                        frameLayout.removeView(customView)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                        this@apply.visibility = android.view.View.VISIBLE
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        request?.url?.toString()?.let { newUrl ->
                            onLoadUrl(newUrl)
                        }
                        return false
                    }
                }
                loadUrl(url)
            }
            frameLayout.addView(webView)
            frameLayout
        },
        update = { frameLayout ->
            val webView = frameLayout.getChildAt(0) as WebView
            val wantsDesktop = isDesktopMode
            val isCurrentlyDesktop = webView.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    webView.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    webView.settings.userAgentString = WebSettings.getDefaultUserAgent(webView.context)
                }
                webView.reload()
            }

            if (webView.url != url && url.isNotEmpty()) {
                webView.loadUrl(url)
            }
        },
        modifier = modifier.fillMaxSize()
    )
}


@Composable
fun TextureVideoPlayer(uri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(true) }
    var currentPos by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }

    DisposableEffect(uri) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    LaunchedEffect(isPlaying, showControls) {
        if (showControls) {
            while (true) {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        currentPos = it.currentPosition
                    }
                }
                kotlinx.coroutines.delay(500)
            }
        }
    }

    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            kotlinx.coroutines.delay(3000)
            showControls = false
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                    
                    setOnClickListener {
                        showControls = !showControls
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        
        if (showControls) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))
            
            Column(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition - 10000).coerceAtLeast(0))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastRewind, "Rewind 10s", tint = Color.White)
                    }
                    
                    FloatingActionButton(
                        onClick = {
                            mediaPlayer?.let { player ->
                                if (player.isPlaying) {
                                    player.pause()
                                    isPlaying = false
                                } else {
                                    player.start()
                                    isPlaying = true
                                }
                            }
                        },
                        containerColor = Color.White.copy(alpha = 0.2f)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, 
                            "Play/Pause", 
                            tint = Color.White
                        )
                    }

                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition + 10000).coerceAtMost(duration))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastForward, "Forward 10s", tint = Color.White)
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = if (duration > 0) currentPos.toFloat() / duration.toFloat() else 0f,
                    onValueChange = { percent ->
                        val newPos = (percent * duration).toInt()
                        currentPos = newPos
                        mediaPlayer?.seekTo(newPos)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                
                fun formatTime(ms: Int): String {
                    val s = ms / 1000
                    val m = s / 60
                    val secs = s % 60
                    return String.format("%02d:%02d", m, secs)
                }
                
                Text(
                    "${formatTime(currentPos)} / ${formatTime(duration)}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}
