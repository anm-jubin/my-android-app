package com.example

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MyApplicationTheme
import com.arthenica.ffmpegkit.FFmpegKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:" + packageName)
                    startActivity(intent)
                } catch (e: Exception) {
                    val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivity(intent)
                }
            }
        } else {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 1
            )
        }

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                MainScreen()
            }
        }
    }
}

val tools = listOf(
    "1. Precision Splitter",
    "2. Smart Renamer",
    "3. Audio Compressor",
    "4. Video Compressor",
    "5. Extract Audio",
    "6. Remove Audio",
    "7. Merge Videos",
    "8. Merge Audio",
    "9. Audio Trim",
    "10. YouTube Downloader"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var selectedTool by remember { mutableStateOf(tools[0]) }
    var menuExpanded by remember { mutableStateOf(false) }
    var workingDir by remember { mutableStateOf("/storage/emulated/0/Download/Magic bullets audio") }
    var filesInDir by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedFiles by remember { mutableStateOf<Set<String>>(emptySet()) }
    val logs = remember { mutableStateListOf<String>() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(workingDir) {
        coroutineScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val dir = File(workingDir)
                    if (dir.exists() && dir.isDirectory) {
                        filesInDir = dir.listFiles()?.filter { it.isFile }?.map { it.name }?.sorted() ?: emptyList()
                        selectedFiles = emptySet()
                    } else {
                        filesInDir = emptyList()
                    }
                } catch (e: Exception) {
                    filesInDir = emptyList()
                }
            }
        }
    }

    fun runCommand(cmd: String) {
        logs.add("> ffmpeg \$cmd")
        FFmpegKit.executeAsync(cmd, { session: com.arthenica.ffmpegkit.FFmpegSession ->
            logs.add("Finished with return code \${session.getReturnCode().value}")
        }, { log: com.arthenica.ffmpegkit.Log ->
            logs.add(log.message)
        })
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable { menuExpanded = true }
                                .padding(8.dp)
                        ) {
                            Text(selectedTool, style = MaterialTheme.typography.titleMedium)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Select Tool")
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            tools.forEach { tool ->
                                DropdownMenuItem(
                                    text = { Text(tool) },
                                    onClick = {
                                        selectedTool = tool
                                        menuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        },
        bottomBar = {
            TerminalView(logs)
        }
    ) { innerPadding ->
        Column(modifier = Modifier
            .padding(innerPadding)
            .fillMaxSize()
            .padding(16.dp)) {
            OutlinedTextField(
                value = workingDir,
                onValueChange = { workingDir = it },
                label = { Text("Working Directory") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            if (filesInDir.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Select Files (\${selectedFiles.size}):", style = MaterialTheme.typography.labelMedium)
                    TextButton(onClick = {
                        selectedFiles = if (selectedFiles.size == filesInDir.size) emptySet() else filesInDir.toSet()
                    }) {
                        Text(if (selectedFiles.size == filesInDir.size) "Deselect All" else "Select All")
                    }
                }
                LazyColumn(modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .border(1.dp, Color.Gray, RoundedCornerShape(4.dp))
                    .padding(4.dp)) {
                    items(filesInDir) { fileName ->
                        val isSelected = selectedFiles.contains(fileName)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedFiles = if (isSelected) {
                                        selectedFiles - fileName
                                    } else {
                                        selectedFiles + fileName
                                    }
                                }
                                .padding(vertical = 4.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(fileName, maxLines = 1, fontSize = 12.sp)
                        }
                    }
                }
            } else {
                Text("No files found in directory.", fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
                when (selectedTool) {
                    tools[0] -> PrecisionSplitterTool(workingDir, selectedFiles, ::runCommand)
                    tools[1] -> SmartRenamerTool(workingDir, selectedFiles, ::runCommand)
                    tools[2] -> AudioCompressorTool(workingDir, selectedFiles, ::runCommand)
                    tools[3] -> VideoCompressorTool(workingDir, selectedFiles, ::runCommand)
                    tools[4] -> ExtractAudioTool(workingDir, selectedFiles, ::runCommand)
                    tools[5] -> RemoveAudioTool(workingDir, selectedFiles, ::runCommand)
                    tools[6] -> MergeVideosTool(workingDir, selectedFiles, ::runCommand)
                    tools[7] -> MergeAudioTool(workingDir, selectedFiles, ::runCommand)
                    tools[8] -> AudioTrimTool(workingDir, selectedFiles, ::runCommand)
                    tools[9] -> YouTubeDownloaderTool(workingDir, ::runCommand)
                }
            }
        }
    }
}

@Composable
fun TerminalView(logs: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(Color.Black)
            .padding(8.dp)
    ) {
        Text("Terminal / FFmpeg Logs", color = Color.Green, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(4.dp))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            reverseLayout = true
        ) {
            items(logs.reversed()) { log ->
                Text(log, color = Color.LightGray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun PrecisionSplitterTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    var cutList by remember { mutableStateOf("") }
    val inputFileName = selectedFiles.firstOrNull() ?: ""
    
    Column(modifier = Modifier.fillMaxSize()) {
        Text("Precision Splitter", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .background(Color.DarkGray, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Media Player Preview", color = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        Text("Coarse Scrub", fontSize = 12.sp)
        Slider(value = 0f, onValueChange = {})
        Text("Fine Scrub (+/- 2 seconds)", fontSize = 12.sp)
        Slider(value = 0.5f, onValueChange = {})
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Button(onClick = { cutList += "[00:01:23.000] " }) { Text("Set Start") }
            Button(onClick = { cutList += "[00:02:45.000] Segment1\n" }) { Text("Set End") }
        }
        OutlinedTextField(
            value = cutList,
            onValueChange = { cutList = it },
            label = { Text("Cut List") },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 4.dp)
        )
        Button(
            onClick = { 
                if (inputFileName.isEmpty()) {
                    onRunCmd("echo 'No file selected'")
                } else {
                    onRunCmd("-i \"\$workingDir/\$inputFileName\" -ss 00:01:23 -to 00:02:45 -c copy -map_metadata 0 \"\$workingDir/output_\$inputFileName\"") 
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Process Cuts")
        }
    }
}

@Composable
fun SmartRenamerTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    var nameList by remember { mutableStateOf("2.5.1 - Intro\\nMain Topic\\nConclusion") }
    Column {
        Text("Smart Renamer", style = MaterialTheme.typography.titleLarge)
        Text("Paste your names list here. Selected files will be renamed.", style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            value = nameList,
            onValueChange = { nameList = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 8.dp)
        )
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                onRunCmd("echo 'Simulating rename for \${selectedFiles.size} files in \$workingDir...'") 
            }
        }, Modifier.fillMaxWidth()) {
            Text("Rename Selected Files")
        }
    }
}

@Composable
fun AudioCompressorTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    var bitrate by remember { mutableStateOf("64k") }
    
    Column {
        Text("Audio Compressor", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = bitrate, onValueChange = { bitrate = it }, label = { Text("Bitrate (e.g., 64k, 128k)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.weight(1f))
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                selectedFiles.forEach { file ->
                    onRunCmd("-i \"\$workingDir/\$file\" -b:a \$bitrate -map_metadata 0 \"\$workingDir/compressed_\$file\"") 
                }
            }
        }, Modifier.fillMaxWidth()) {
            Text("Compress Audio (\${selectedFiles.size} files)")
        }
    }
}

@Composable
fun VideoCompressorTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    var crf by remember { mutableStateOf("28") }
    var scale360p by remember { mutableStateOf(false) }
    Column {
        Text("Video Compressor", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = crf, onValueChange = { crf = it }, label = { Text("CRF (Quality, lower is better)") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = scale360p, onCheckedChange = { scale360p = it })
            Text("Scale to 360p height max")
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                val vf = if (scale360p) "-vf scale=-2:360 " else ""
                selectedFiles.forEach { file ->
                    onRunCmd("-i \"\$workingDir/\$file\" -vcodec libx264 -crf \$crf \${vf}-map_metadata 0 \"\$workingDir/compressed_\$file\"") 
                }
            }
        }, Modifier.fillMaxWidth()) {
            Text("Compress Videos (\${selectedFiles.size} files)")
        }
    }
}

@Composable
fun ExtractAudioTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    Column {
        Text("Extract Audio from Videos", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Extracts audio tracks from selected videos.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.weight(1f))
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                selectedFiles.forEach { file ->
                    val outName = file.substringBeforeLast(".") + ".mp3"
                    onRunCmd("-i \"\$workingDir/\$file\" -q:a 0 -map a -map_metadata 0 \"\$workingDir/\$outName\"") 
                }
            }
        }, Modifier.fillMaxWidth()) {
            Text("Extract Audio (\${selectedFiles.size} files)")
        }
    }
}

@Composable
fun RemoveAudioTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    Column {
        Text("Remove Audio (Mute)", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Copies the video stream but removes audio track.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.weight(1f))
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                selectedFiles.forEach { file ->
                    onRunCmd("-i \"\$workingDir/\$file\" -c copy -an -map_metadata 0 \"\$workingDir/silent_\$file\"") 
                }
            }
        }, Modifier.fillMaxWidth()) {
            Text("Remove Audio (\${selectedFiles.size} files)")
        }
    }
}

@Composable
fun MergeVideosTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    Column {
        Text("Merge Videos", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Joins selected videos sequentially.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.weight(1f))
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                try {
                    val listFile = File(workingDir, "list.txt")
                    listFile.writeText(selectedFiles.joinToString("\n") { "file '\$it'" })
                    onRunCmd("-f concat -safe 0 -i \"\$workingDir/list.txt\" -c copy \"\$workingDir/merged.mp4\"") 
                } catch (e: Exception) {
                    onRunCmd("echo 'Failed to create list.txt: \${e.message}'")
                }
            }
        }, Modifier.fillMaxWidth()) {
            Text("Merge \${selectedFiles.size} Videos")
        }
    }
}

@Composable
fun MergeAudioTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    Column {
        Text("Merge Audio", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("Joins selected audio files sequentially.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.weight(1f))
        Button(onClick = { 
            if (selectedFiles.isEmpty()) {
                onRunCmd("echo 'No files selected'")
            } else {
                try {
                    val listFile = File(workingDir, "list.txt")
                    listFile.writeText(selectedFiles.joinToString("\n") { "file '\$it'" })
                    onRunCmd("-f concat -safe 0 -i \"\$workingDir/list.txt\" -c copy \"\$workingDir/merged.mp3\"") 
                } catch (e: Exception) {
                    onRunCmd("echo 'Failed to create list.txt: \${e.message}'")
                }
            }
        }, Modifier.fillMaxWidth()) {
            Text("Merge \${selectedFiles.size} Audio Files")
        }
    }
}

@Composable
fun AudioTrimTool(workingDir: String, selectedFiles: Set<String>, onRunCmd: (String) -> Unit) {
    var seconds by remember { mutableStateOf("5") }
    Column {
        Text("Audio Trim / Pad Silence", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = seconds, onValueChange = { seconds = it }, label = { Text("Seconds") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { 
                if (selectedFiles.isEmpty()) {
                    onRunCmd("echo 'No files selected'")
                } else {
                    selectedFiles.forEach { file ->
                        onRunCmd("-f lavfi -i anullsrc=r=44100:cl=stereo -t \$seconds -i \"\$workingDir/\$file\" -filter_complex '[0:a][1:a]concat=n=2:v=0:a=1' \"\$workingDir/padded_\$file\"") 
                    }
                }
            }, Modifier.weight(1f)) {
                Text("Add Start")
            }
            Button(onClick = { 
                if (selectedFiles.isEmpty()) {
                    onRunCmd("echo 'No files selected'")
                } else {
                    selectedFiles.forEach { file ->
                        onRunCmd("-i \"\$workingDir/\$file\" -ss \$seconds -c copy -map_metadata 0 \"\$workingDir/cut_\$file\"") 
                    }
                }
            }, Modifier.weight(1f)) {
                Text("Cut Start")
            }
        }
    }
}

@Composable
fun YouTubeDownloaderTool(workingDir: String, onRunCmd: (String) -> Unit) {
    var url by remember { mutableStateOf("") }
    var cookies by remember { mutableStateOf("") }
    Column {
        Text("YouTube Downloader", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Video URL") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = cookies, onValueChange = { cookies = it }, label = { Text("Cookies.txt content (Optional)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.weight(1f))
        Button(onClick = { onRunCmd("yt-dlp \$url -P \"\$workingDir\" --cookies-from-browser") }, Modifier.fillMaxWidth()) {
            Text("Download Video + Audio")
        }
    }
}
