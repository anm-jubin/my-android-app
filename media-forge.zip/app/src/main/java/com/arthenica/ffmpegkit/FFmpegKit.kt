package com.arthenica.ffmpegkit

object FFmpegKit {
    fun execute(command: String): FFmpegSession {
        android.util.Log.i("FFmpegKit", "Executing mocked command: \$command")
        return FFmpegSession(command)
    }

    fun executeAsync(command: String, callback: FFmpegSessionCompleteCallback, logCallback: LogCallback) {
        Thread {
            for (i in 1..10) {
                Thread.sleep(200)
                logCallback.apply(Log("Simulated log output line \$i for command: \$command"))
            }
            callback.apply(FFmpegSession(command))
        }.start()
    }
}

class FFmpegSession(val command: String) {
    fun getReturnCode(): ReturnCode {
        return ReturnCode(0)
    }
    fun getOutput(): String {
        return "Mock output for \$command"
    }
}

class ReturnCode(val value: Int) {
    companion object {
        fun isSuccess(returnCode: ReturnCode): Boolean {
            return returnCode.value == 0
        }
    }
}

fun interface FFmpegSessionCompleteCallback {
    fun apply(session: FFmpegSession)
}

fun interface LogCallback {
    fun apply(log: Log)
}

class Log(val message: String)
