with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """AndroidView(
            factory = { ctx ->"""

replacement = """androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = { ctx ->"""

idx = content.find(target, content.find("fun TextureVideoPlayer"))
if idx != -1:
    end_idx = content.find(")", content.find("modifier = Modifier", idx))
    content = content[:idx] + replacement + content[idx:end_idx+1] + "\n        }" + content[end_idx+1:]
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content)
    print("Wrapped TextureVideoPlayer in Box")
else:
    print("Could not find TextureVideoPlayer AndroidView")
