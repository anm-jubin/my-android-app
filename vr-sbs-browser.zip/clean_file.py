import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix the broken imports at the top
content = re.sub(r"^package com\.example.*?import android\.os\.Bundle", "package com.example\n\nimport android.os.Bundle", content, count=1, flags=re.DOTALL)

imports_to_add = """
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asComposeRenderEffect
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.annotation.SuppressLint
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
"""
content = content.replace("package com.example\n\nimport android.os.Bundle", "package com.example\n" + imports_to_add + "\nimport android.os.Bundle")

# Fix Icons.Default.Favorite to Icons.Filled.Favorite
content = content.replace("androidx.compose.material.icons.Icons.Default.FavoriteBorder", "androidx.compose.material.icons.filled.FavoriteBorder")
content = content.replace("androidx.compose.material.icons.Icons.Default.Favorite", "androidx.compose.material.icons.filled.Favorite")

# Actually, Icons.Filled.Favorite requires the Icons.Filled prefix. Let's just use Icons.Default.Favorite, but we need to import it?
# The correct path is androidx.compose.material.icons.filled.Favorite. We can just use that object directly, wait, Favorite is a property of Icons.Filled.
# Or we can just use Icons.Default.Check and Icons.Default.Add which are built-in without needing extra imports (Icons.Default is an alias for Icons.Filled, and Check/Add are in the core set).
# Let's change the icons to Icons.Default.Star... Wait, Star is NOT in the core set. Core set has:
# Add, ArrowBack, ArrowDropDown, ArrowForward, Build, Call, Check, CheckCircle, Clear, Close, Create, Delete, Done, Edit, Email, ExitToApp, Face, Favorite, FavoriteBorder, Home, Info, KeyboardArrowDown, KeyboardArrowLeft, KeyboardArrowRight, KeyboardArrowUp, List, LocationOn, Lock, MailOutline, Menu, MoreVert, Person, PlayArrow, Refresh, Search, Send, Settings, Share, ShoppingCart, Star, ThumbUp, Warning.
# Wait, Favorite IS in the core set!
content = content.replace("androidx.compose.material.icons.filled.FavoriteBorder", "androidx.compose.material.icons.Icons.Default.FavoriteBorder")
content = content.replace("androidx.compose.material.icons.filled.Favorite", "androidx.compose.material.icons.Icons.Default.Favorite")


with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
