import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Fix Sliders to show exact values
content = content.replace(
    'Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)',
    'Text("Screen Size: ${String.format("%.2f", scale)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'
)
content = content.replace(
    'Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)',
    'Text("Distortion Amount: ${String.format("%.2f", lensDistortion)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'
)

# 2. Add the custom shortcuts to Settings
target = """                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {"""

replace = """                            SettingsSection("Custom Shortcuts") {
                                var shortcutsExpanded by remember { mutableStateOf(false) }
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable { shortcutsExpanded = !shortcutsExpanded },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(if (shortcutsExpanded) "Hide Shortcuts" else "Show Shortcuts", color = Color.Cyan, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                }
                                if (shortcutsExpanded) {
                                    var newShortcutName by remember { mutableStateOf("") }
                                    var newShortcutUrl by remember { mutableStateOf("") }
                                    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                                        customShortcuts.forEach { shortcut ->
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(shortcut.first, color = Color.White, style = MaterialTheme.typography.bodySmall)
                                                    Text(shortcut.second, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                                }
                                                IconButton(onClick = { 
                                                    val newList = customShortcuts.filter { it != shortcut }
                                                    customShortcuts = newList
                                                    prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                                                }) {
                                                    Icon(Icons.Default.Clear, contentDescription = "Remove", tint = Color.Red)
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                TextField(value = newShortcutName, onValueChange = { newShortcutName = it }, placeholder = { Text("Name", style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.fillMaxWidth().height(48.dp), textStyle = MaterialTheme.typography.labelSmall)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                TextField(value = newShortcutUrl, onValueChange = { newShortcutUrl = it }, placeholder = { Text("URL", style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.fillMaxWidth().height(48.dp), textStyle = MaterialTheme.typography.labelSmall)
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            androidx.compose.material3.TextButton(onClick = {
                                                if (newShortcutName.isNotBlank() && newShortcutUrl.isNotBlank()) {
                                                    val u = if (!newShortcutUrl.startsWith("http")) "https://$newShortcutUrl" else newShortcutUrl
                                                    val newList = customShortcuts + Pair(newShortcutName, u)
                                                    customShortcuts = newList
                                                    prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                                                    newShortcutName = ""
                                                    newShortcutUrl = ""
                                                }
                                            }) {
                                                Text("Add", color = Color.Cyan)
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
