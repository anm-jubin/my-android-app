import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    fun clearIncognitoData() {
        try {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val profileStore = androidx.webkit.ProfileStore.getInstance()
                val profile = profileStore.getProfile("incognito")
                if (profile != null) {
                    profile.cookieManager.removeAllCookies(null)
                    profile.webStorage.deleteAllData()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }"""

replace = """    fun clearIncognitoData() {
        try {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val profileStore = androidx.webkit.ProfileStore.getInstance()
                val profile = profileStore.getProfile("incognito")
                if (profile != null) {
                    profile.cookieManager.removeAllCookies(null)
                    profile.webStorage.deleteAllData()
                }
            }
            android.widget.Toast.makeText(context, "Incognito data cleared!", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            android.widget.Toast.makeText(context, "Failed to clear incognito data", android.widget.Toast.LENGTH_SHORT).show()
        }
    }"""
content = content.replace(target, replace)

# Also fix the sliders
target_sliders = [
    ('Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Pupil Distance (IPD): ${String.format(\\"%.1f\\", ipd)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'),
    ('Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Vertical Shift: ${String.format(\\"%.1f\\", verticalShift)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'),
    ('Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Content Opacity: ${String.format(\\"%.2f\\", contentOpacity)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'),
    ('Text("Camera IPD", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Camera IPD: ${String.format(\\"%.1f\\", cameraIpd)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'),
    ('Text("Camera Scale", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Camera Scale: ${String.format(\\"%.2f\\", cameraScale)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'),
    ('Text("Camera Vertical", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Camera Vertical: ${String.format(\\"%.1f\\", cameraVerticalShift)}", color = Color.White, style = MaterialTheme.typography.labelSmall)'),
    ('Text("Gyro Sensitivity", color = Color.White, style = MaterialTheme.typography.labelSmall)', 'Text("Gyro Sensitivity: ${String.format(\\"%.0f\\", gyroSensitivity)}", color = Color.White, style = MaterialTheme.typography.labelSmall)')
]
for t, r in target_sliders:
    content = content.replace(t, r)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
