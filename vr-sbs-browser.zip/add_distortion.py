import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add LensWrapping state variables
state_vars = """    var lensWrapping by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("lensWrapping", true)) }
    var lensDistortion by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("lensDistortion", 0.1f)) }

    val browserManager = androidx.compose.runtime.remember {"""

content = content.replace("    val browserManager = androidx.compose.runtime.remember {", state_vars)

# Add to LaunchedEffect save
save_target = """            .putFloat("fabOffsetY", fabOffsetY)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })"""
save_replace = """            .putFloat("fabOffsetY", fabOffsetY)
            .putBoolean("lensWrapping", lensWrapping)
            .putFloat("lensDistortion", lensDistortion)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })"""
content = content.replace(save_target, save_replace)

# Add to LaunchedEffect dependencies
dep_target = "scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId) {"
dep_replace = "scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion) {"
content = content.replace(dep_target, dep_replace)

# Add Modifier to BoxWithConstraints
box_target = "BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {"
box_replace = "BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black).vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {"
content = content.replace(box_target, box_replace)

# Add UI controls
ui_target = """                            Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)"""
ui_replace = """                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                            }
                            if (lensWrapping) {
                                Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = lensDistortion,
                                    onValueChange = { lensDistortion = it },
                                    valueRange = 0.01f..0.5f
                                )
                            }
                            Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)"""
content = content.replace(ui_target, ui_replace)

# Add reset params
reset_target = """                                    isRightHandMode = true
                                    isDesktopMode = true
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f"""
reset_replace = """                                    isRightHandMode = true
                                    isDesktopMode = true
                                    lensWrapping = true
                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f"""
content = content.replace(reset_target, reset_replace)

# Add the modifier extension at the end of the file
extension = """

@android.annotation.SuppressLint("NewApi")
fun Modifier.vrLensDistortion(distortion: Float): Modifier = this.then(
    if (android.os.Build.VERSION.SDK_INT >= 33 && distortion > 0f) {
        androidx.compose.ui.graphics.graphicsLayer {
            val shader = android.graphics.RuntimeShader(\"\"\"
                uniform float2 resolution;
                uniform float distortion;
                uniform shader composable;
                
                half4 main(float2 fragCoord) {
                    float halfWidth = resolution.x * 0.5;
                    float isRight = step(halfWidth, fragCoord.x);
                    float offsetX = isRight * halfWidth;
                    
                    float2 uv = float2(fragCoord.x - offsetX, fragCoord.y) / float2(halfWidth, resolution.y);
                    
                    float2 centered = uv - 0.5;
                    float r2 = dot(centered, centered);
                    float2 distorted = centered * (1.0 + distortion * r2);
                    
                    float2 outUv = distorted + 0.5;
                    if (outUv.x < 0.0 || outUv.x > 1.0 || outUv.y < 0.0 || outUv.y > 1.0) {
                        return half4(0.0, 0.0, 0.0, 1.0);
                    }
                    
                    float2 screenUv = float2(outUv.x * halfWidth + offsetX, outUv.y * resolution.y);
                    return composable.eval(screenUv);
                }
            \"\"\")
            shader.setFloatUniform("resolution", size.width, size.height)
            shader.setFloatUniform("distortion", distortion)
            renderEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "composable").asComposeRenderEffect()
        }
    } else {
        Modifier
    }
)
"""
content += extension

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
