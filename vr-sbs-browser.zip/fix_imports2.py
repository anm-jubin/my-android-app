with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

imports_to_add = """
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.clickable
"""

content = content.replace("package com.example", "package com.example\n" + imports_to_add)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

