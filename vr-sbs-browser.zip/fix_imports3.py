with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix the broken import line
# It looks like: package com.exampleimport androidx.compose.foundation.lazy.itemsIndexedimport androidx.compose.foundation.lazy.itemsimport ...
# Let's just find that first line and split it.
first_line = content.split('\n')[0]
new_first_line = first_line.replace("import ", "\nimport ")

content = content.replace(first_line, new_first_line)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
