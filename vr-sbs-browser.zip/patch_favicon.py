import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_lazyrow = """            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    val url = shortcut.second.lowercase()
                    val icon = when {
                        url.contains("youtube.com") -> Icons.Default.PlayArrow
                        url.contains("reddit.com") -> Icons.Default.Menu
                        url.contains("github.com") -> Icons.Default.Info
                        url.contains("twitter.com") || url.contains("x.com") -> Icons.Default.Clear
                        url.contains("google.com") -> Icons.Default.Search
                        else -> Icons.Default.Public
                    }
                    val color = when {
                        url.contains("youtube.com") -> Color.Red
                        url.contains("reddit.com") -> Color(0xFFFF4500)
                        url.contains("github.com") -> Color.DarkGray
                        url.contains("twitter.com") || url.contains("x.com") -> Color.Black
                        url.contains("google.com") -> Color.Blue
                        else -> Color(0xFF6200EE)
                    }
                    ShortcutIcon(shortcut.first, icon, color) { onSearch(shortcut.second) }
                }
            }"""

replace_lazyrow = """            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    ShortcutIcon(shortcut.first, shortcut.second) { onSearch(shortcut.second) }
                }
            }"""

content = content.replace(target_lazyrow, replace_lazyrow)

target_icon = """@Composable
fun ShortcutIcon(name: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.FloatingActionButton(
            onClick = onClick,
            containerColor = Color.White,
            contentColor = color,
            modifier = Modifier.size(64.dp)
        ) {
            Icon(icon, contentDescription = name, modifier = Modifier.size(32.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(name, color = Color.White, style = MaterialTheme.typography.bodyMedium)
    }
}"""

replace_icon = """@Composable
fun ShortcutIcon(name: String, url: String, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.FloatingActionButton(
            onClick = onClick,
            containerColor = Color.White,
            modifier = Modifier.size(64.dp)
        ) {
            val domain = try { android.net.Uri.parse(url).host ?: url } catch (e: Exception) { url }
            coil.compose.AsyncImage(
                model = "https://www.google.com/s2/favicons?domain=$domain&sz=128",
                contentDescription = name,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(name, color = Color.White, style = MaterialTheme.typography.bodyMedium)
    }
}"""
content = content.replace(target_icon, replace_icon)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
