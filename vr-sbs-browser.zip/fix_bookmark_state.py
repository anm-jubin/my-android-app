import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = "    var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }"
replacement = target + "\n    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }"
content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
