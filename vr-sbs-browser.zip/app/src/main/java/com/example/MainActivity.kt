package com.example

import android.annotation.SuppressLint
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.filled.Add

import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import android.media.MediaPlayer
import android.view.TextureView
import android.view.Surface
import android.graphics.SurfaceTexture
import android.content.Context
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    VRBrowserScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = androidx.compose.runtime.remember { context.getSharedPreferences("vr_prefs", android.content.Context.MODE_PRIVATE) }
    
    val savedTabsStr = prefs.getString("savedTabs", "1|https://m.youtube.com") ?: "1|https://m.youtube.com"
    var tabs by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf(savedTabsStr.split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) WebTab(parts[0], parts[1]) else null
        }.ifEmpty { listOf(WebTab("1", "https://m.youtube.com")) }) 
    }
    var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("activeTabId", tabs.firstOrNull()?.id ?: "1")) }

    var urlInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.firstOrNull { it.id == activeTabId }?.url ?: "https://m.youtube.com") }
    var currentUrl by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(urlInput) }
    var isUiVisible by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
    var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
        
    var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isDesktopMode", true)) }
    var isRightHandMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isRightHandMode", true)) }
    var scale by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("scale", 1f)) }
    var ipd by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("ipd", 0f)) }
    var verticalShift by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("verticalShift", 0f)) }
        
    var fabOffsetX by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetX", 50f)) }
    var fabOffsetY by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetY", 300f)) }

    val browserManager = androidx.compose.runtime.remember { 
        BrowserManager(context).apply {
            tabs.forEach { addTab(it.id, it.url, isDesktopMode) }
            this.activeTabId = activeTabId
        }
    }
    
    var canGoBack by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        browserManager.onUrlChanged = { newUrl ->
            urlInput = newUrl
            currentUrl = newUrl
            tabs = tabs.map { if (it.id == activeTabId) it.copy(url = newUrl) else it }
        }
        browserManager.onCanGoBackChanged = { canGoBack = it }
    }
    
    androidx.activity.compose.BackHandler(enabled = canGoBack) {
        browserManager.goBack()
    }
    
    androidx.compose.runtime.LaunchedEffect(isDesktopMode) {
        browserManager.updateDesktopMode(isDesktopMode)
    }

    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId) {
        prefs.edit()
            .putBoolean("isDesktopMode", isDesktopMode)
            .putBoolean("isRightHandMode", isRightHandMode)
            .putFloat("scale", scale)
            .putFloat("ipd", ipd)
            .putFloat("verticalShift", verticalShift)
            .putFloat("fabOffsetX", fabOffsetX)
            .putFloat("fabOffsetY", fabOffsetY)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("activeTabId", activeTabId)
            .apply()
    }

    var localVideoUri by remember { mutableStateOf<Uri?>(null) }
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            localVideoUri = uri
            isUiVisible = false
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        // The single WebView container, drawn twice using Compose rendering!
        // Using graphicsLayer maps the affine transform (scale/translate) natively to the View layer,
        // which perfectly fixes the touch mapping offsets when scaling or shifting the IPD.
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = if (isRightHandMode) ipd else -ipd
                    translationY = verticalShift
                }
                .drawWithContent {
                    // 1. Draw Active Eye (Already transformed by graphicsLayer, so touch works perfectly!)
                    drawContent()

                    // 2. Draw Mirror Eye (shifted to the opposite lens)
                    drawContext.canvas.save()
                    val distance = if (isRightHandMode) {
                        (-size.width - 2 * ipd) / scale
                    } else {
                        (size.width + 2 * ipd) / scale
                    }
                    drawContext.canvas.translate(distance, 0f)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(uri = localVideoUri!!)
            } else {
                AndroidView(
                    factory = { browserManager.container },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // Left Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        // Right Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset((fabOffsetX + eyeWidthPx).roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        if (isUiVisible) {
            Column(
                modifier = Modifier
                    .align(if (isRightHandMode) Alignment.TopEnd else Alignment.TopStart) // Constrain UI to active Screen
                    .width(eyeWidth)
                    .padding(8.dp)
            ) {
                // Tab Bar
                ScrollableTabRow(
                    selectedTabIndex = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0),
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp),
                    containerColor = Color.DarkGray.copy(alpha = 0.8f),
                    contentColor = Color.White,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        val index = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0)
                        if (index < tabPositions.size) {
                            TabRowDefaults.Indicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[index]),
                                color = Color.White
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, tab ->
                        Tab(
                            selected = tab.id == activeTabId,
                            onClick = { 
                                activeTabId = tab.id
                                browserManager.activeTabId = tab.id
                            },
                            text = { Text("Tab ${index + 1}") }
                        )
                    }
                    IconButton(onClick = { 
                        val newId = java.util.UUID.randomUUID().toString().take(4)
                        val newTab = WebTab(newId, "https://m.youtube.com")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                        activeTabId = newId
                        browserManager.activeTabId = newId
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                    }
                }

                // Address Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            videoPickerLauncher.launch("video/*")
                        }) {
                            Icon(Icons.Default.Folder, contentDescription = "Open Local Video", tint = Color.White)
                        }
                        IconButton(onClick = { urlInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { showControls = !showControls }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }
                }
                
                if (showControls) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Controls
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp).verticalScroll(rememberScrollState())) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Right-Hand Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isRightHandMode, onCheckedChange = { isRightHandMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = scale,
                                onValueChange = { scale = it },
                                valueRange = 0.5f..1.5f
                            )
                            Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = ipd,
                                onValueChange = { ipd = it },
                                valueRange = -150f..150f
                            )
                            Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = verticalShift,
                                onValueChange = { verticalShift = it },
                                valueRange = -300f..300f
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    scale = 1f
                                    ipd = 0f
                                    verticalShift = 0f
                                    isRightHandMode = true
                                    isDesktopMode = true
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                            ) {
                                Text("Reset View Settings", color = Color.White)
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                    android.webkit.CookieManager.getInstance().flush()
                                    android.webkit.WebStorage.getInstance().deleteAllData()
                                    android.widget.Toast.makeText(context, "Sign-in data cleared!", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                            ) {
                                Text("Clear Sign-in Data", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingleBrowser(
    url: String,
    isDesktopMode: Boolean,
    onLoadUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            val frameLayout = android.widget.FrameLayout(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }

            val webView = WebView(context).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                
                webChromeClient = object : WebChromeClient() {
                    private var customView: android.view.View? = null
                    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                    override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                        if (customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        this@apply.visibility = android.view.View.GONE
                        frameLayout.addView(view, android.widget.FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                    }

                    override fun onHideCustomView() {
                        if (customView == null) return
                        frameLayout.removeView(customView)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                        this@apply.visibility = android.view.View.VISIBLE
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        request?.url?.toString()?.let { newUrl ->
                            onLoadUrl(newUrl)
                        }
                        return false
                    }
                }
                loadUrl(url)
            }
            frameLayout.addView(webView)
            frameLayout
        },
        update = { frameLayout ->
            val webView = frameLayout.getChildAt(0) as WebView
            val wantsDesktop = isDesktopMode
            val isCurrentlyDesktop = webView.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    webView.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    webView.settings.userAgentString = WebSettings.getDefaultUserAgent(webView.context)
                }
                webView.reload()
            }

            if (webView.url != url && url.isNotEmpty()) {
                webView.loadUrl(url)
            }
        },
        modifier = modifier.fillMaxSize()
    )
}


@Composable
fun TextureVideoPlayer(uri: Uri, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(true) }
    var currentPos by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }

    DisposableEffect(uri) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    LaunchedEffect(isPlaying, showControls) {
        if (showControls) {
            while (true) {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        currentPos = it.currentPosition
                    }
                }
                kotlinx.coroutines.delay(500)
            }
        }
    }

    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            kotlinx.coroutines.delay(3000)
            showControls = false
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                    
                    setOnClickListener {
                        showControls = !showControls
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        
        if (showControls) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))
            
            Column(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition - 10000).coerceAtLeast(0))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastRewind, "Rewind 10s", tint = Color.White)
                    }
                    
                    FloatingActionButton(
                        onClick = {
                            mediaPlayer?.let { player ->
                                if (player.isPlaying) {
                                    player.pause()
                                    isPlaying = false
                                } else {
                                    player.start()
                                    isPlaying = true
                                }
                            }
                        },
                        containerColor = Color.White.copy(alpha = 0.2f)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, 
                            "Play/Pause", 
                            tint = Color.White
                        )
                    }

                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition + 10000).coerceAtMost(duration))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastForward, "Forward 10s", tint = Color.White)
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = if (duration > 0) currentPos.toFloat() / duration.toFloat() else 0f,
                    onValueChange = { percent ->
                        val newPos = (percent * duration).toInt()
                        currentPos = newPos
                        mediaPlayer?.seekTo(newPos)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                
                fun formatTime(ms: Int): String {
                    val s = ms / 1000
                    val m = s / 60
                    val secs = s % 60
                    return String.format("%02d:%02d", m, secs)
                }
                
                Text(
                    "${formatTime(currentPos)} / ${formatTime(duration)}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

class BrowserManager(val context: Context) {
    val container = android.widget.FrameLayout(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }
    private val webViews = mutableMapOf<String, WebView>()
    
    var onUrlChanged: ((String) -> Unit)? = null
    var onCanGoBackChanged: ((Boolean) -> Unit)? = null

    var activeTabId: String? = null
        set(value) {
            field = value
            webViews.forEach { (id, webView) ->
                webView.visibility = if (id == value) android.view.View.VISIBLE else android.view.View.GONE
            }
            getActiveWebView()?.let {
                onUrlChanged?.invoke(it.url ?: it.originalUrl ?: "")
                onCanGoBackChanged?.invoke(it.canGoBack())
            }
        }

    fun getActiveWebView(): WebView? = activeTabId?.let { webViews[it] }

    @SuppressLint("SetJavaScriptEnabled")
    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)
            }
            
            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webChromeClient = object : WebChromeClient() {
                private var customView: android.view.View? = null
                private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    this@apply.visibility = android.view.View.GONE
                    container.addView(view, android.widget.FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    ))
                }

                override fun onHideCustomView() {
                    if (customView == null) return
                    container.removeView(customView)
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    this@apply.visibility = android.view.View.VISIBLE
                }
            }
            webViewClient = object : WebViewClient() {
                override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
                override fun onPageFinished(view: WebView, url: String) {
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
            }
            loadUrl(url)
        }
        webViews[id] = webView
        container.addView(webView)
        
        if (id == activeTabId) {
            webView.visibility = android.view.View.VISIBLE
        } else {
            webView.visibility = android.view.View.GONE
        }
    }

    fun removeTab(id: String) {
        webViews.remove(id)?.let {
            container.removeView(it)
            it.destroy()
        }
    }

    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.loadUrl(url)
    }
    
    fun updateDesktopMode(isDesktopMode: Boolean) {
        webViews.values.forEach { view ->
            val wantsDesktop = isDesktopMode
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    view.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    view.settings.userAgentString = WebSettings.getDefaultUserAgent(view.context)
                }
                view.reload()
            }
        }
    }
    
    fun goBack(): Boolean {
        val wv = getActiveWebView()
        return if (wv?.canGoBack() == true) {
            wv.goBack()
            true
        } else false
    }
}

data class WebTab(val id: String, val url: String)
