package com.example

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.graphicsLayer
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    VRBrowserScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    var urlInput by remember { mutableStateOf("https://m.youtube.com") }
    var currentUrl by remember { mutableStateOf("https://m.youtube.com") }
    
    var leftWebView by remember { mutableStateOf<WebView?>(null) }
    var rightWebView by remember { mutableStateOf<WebView?>(null) }

    val coroutineScope = rememberCoroutineScope()

    var isUiVisible by remember { mutableStateOf(true) }

    var scale by remember { mutableFloatStateOf(1f) }
    var ipd by remember { mutableFloatStateOf(0f) }

    // Sync state to prevent infinite loops of syncing
    var isLeftSyncing by remember { mutableStateOf(false) }
    var isRightSyncing by remember { mutableStateOf(false) }

    Row(modifier = modifier.fillMaxSize().background(Color.Black)) {
        // Left Eye
        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            BrowserEye(
                url = currentUrl,
                onUrlInputChanged = { urlInput = it },
                urlInput = urlInput,
                onLoadUrl = { 
                    currentUrl = it
                    isUiVisible = false
                },
                onWebViewCreated = { webView ->
                    leftWebView = webView
                    setupWebView(webView, "LeftBridge") { x, y ->
                        if (!isLeftSyncing) {
                            isRightSyncing = true
                            rightWebView?.post {
                                rightWebView?.evaluateJavascript("window.scrollTo($x, $y);", null)
                                coroutineScope.launch { delay(50); isRightSyncing = false }
                            }
                        }
                    }
                },
                isMaster = true,
                isUiVisible = isUiVisible,
                onToggleUi = { isUiVisible = !isUiVisible },
                scale = scale,
                onScaleChange = { scale = it },
                ipd = ipd,
                onIpdChange = { ipd = it }
            )
        }

        Spacer(modifier = Modifier.width(4.dp).fillMaxHeight().background(Color.Black))

        // Right Eye
        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            BrowserEye(
                url = currentUrl,
                onUrlInputChanged = { urlInput = it },
                urlInput = urlInput,
                onLoadUrl = { 
                    currentUrl = it
                    isUiVisible = false
                },
                onWebViewCreated = { webView ->
                    rightWebView = webView
                    setupWebView(webView, "RightBridge") { x, y ->
                        if (!isRightSyncing) {
                            isLeftSyncing = true
                            leftWebView?.post {
                                leftWebView?.evaluateJavascript("window.scrollTo($x, $y);", null)
                                coroutineScope.launch { delay(50); isLeftSyncing = false }
                            }
                        }
                    }
                },
                isMaster = false,
                isUiVisible = isUiVisible,
                onToggleUi = { isUiVisible = !isUiVisible },
                scale = scale,
                onScaleChange = { scale = it },
                ipd = ipd,
                onIpdChange = { ipd = it }
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun setupWebView(webView: WebView, bridgeName: String, onScroll: (Int, Int) -> Unit) {
    webView.settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        mediaPlaybackRequiresUserGesture = false
        useWideViewPort = true
        loadWithOverviewMode = true
        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
    }

    webView.addJavascriptInterface(object {
        @JavascriptInterface
        fun syncScroll(x: Int, y: Int) {
            onScroll(x, y)
        }
    }, bridgeName)
}

@Composable
fun BrowserEye(
    url: String,
    onUrlInputChanged: (String) -> Unit,
    urlInput: String,
    onLoadUrl: (String) -> Unit,
    onWebViewCreated: (WebView) -> Unit,
    isMaster: Boolean,
    isUiVisible: Boolean,
    onToggleUi: () -> Unit,
    scale: Float,
    onScaleChange: (Float) -> Unit,
    ipd: Float,
    onIpdChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            val bridgeName = if (isMaster) "LeftBridge" else "RightBridge"
                            
                            // Inject scroll sync
                            view?.evaluateJavascript(
                                "(function() { " +
                                "  window.addEventListener('scroll', function() { " +
                                "    $bridgeName.syncScroll(window.scrollX, window.scrollY); " +
                                "  }); " +
                                "})();", null
                            )

                            // If not master, aggressively mute media
                            if (!isMaster) {
                                val muteScript = "(function() { " +
                                "  const muteMedia = () => { " +
                                "    document.querySelectorAll('video, audio').forEach(v => { v.muted = true; }); " +
                                "  }; " +
                                "  muteMedia(); " +
                                "  setInterval(muteMedia, 500); " + // Repeatedly try to mute in case new media loads
                                "})();"
                                view?.evaluateJavascript(muteScript, null)
                            }
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            request?.url?.toString()?.let { newUrl ->
                                if (isMaster) {
                                    onLoadUrl(newUrl)
                                }
                            }
                            return false
                        }
                    }
                    onWebViewCreated(this)
                    webViewRef = this
                    loadUrl(url)
                }
            },
            update = { view ->
                if (view.url != url && url.isNotEmpty()) {
                    view.loadUrl(url)
                }
            },
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationX = if (isMaster) -ipd else ipd
            }
        )

        // Floating Action Button to toggle UI
        FloatingActionButton(
            onClick = onToggleUi,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black)
        }

        if (isUiVisible) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                // Address Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = urlInput,
                            onValueChange = onUrlInputChanged,
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    onLoadUrl(finalUrl)
                                }
                            )
                        )
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            onLoadUrl(finalUrl)
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Controls
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = scale,
                            onValueChange = onScaleChange,
                            valueRange = 0.5f..1.5f
                        )
                        Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = ipd,
                            onValueChange = onIpdChange,
                            valueRange = -150f..150f
                        )
                    }
                }
            }
        }
    }
}
