import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Update the drawWithContent to include clipping
draw_pattern = re.compile(r"(\.drawWithContent \{)\n\s+// 1\. Draw Active Eye.*?\n\s+drawContent\(\)\n\n\s+// 2\. Draw Mirror Eye.*?\n\s+drawContext\.canvas\.save\(\)\n\s+val distance = if \(isRightHandMode\) \{\n\s+-size\.width - 2 \* ipd\n\s+\} else \{\n\s+size\.width \+ 2 \* ipd\n\s+\}\n\s+drawContext\.canvas\.translate\(distance, 0f\)\n\s+drawContent\(\)\n\s+drawContext\.canvas\.restore\(\)\n\s+\}", re.MULTILINE | re.DOTALL)

draw_replacement = """\\1
                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye (shifted to the opposite lens)
                    drawContext.canvas.save()
                    val distance = if (isRightHandMode) {
                        -size.width - 2 * ipd
                    } else {
                        size.width + 2 * ipd
                    }
                    drawContext.canvas.translate(distance, 0f)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()
                }"""

if draw_pattern.search(content):
    content = draw_pattern.sub(draw_replacement, content)
    print("drawWithContent updated")
else:
    print("drawWithContent not found")

# 2. Update AndroidView inside VRBrowserScreen
android_view_pattern = re.compile(r"AndroidView\(\n\s+factory = \{ browserManager\.container \},\n\s+modifier = Modifier\.fillMaxSize\(\),\n\s+update = \{ container ->\n\s+container\.scaleX = scale\n\s+container\.scaleY = scale\n\s+container\.translationX = if \(isRightHandMode\) ipd else -ipd\n\s+container\.translationY = verticalShift\n\s+\}\n\s+\)")

android_view_replacement = """androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize(fraction = scale)
                            .offset(
                                x = with(density) { (if (isRightHandMode) ipd else -ipd).toDp() },
                                y = with(density) { verticalShift.toDp() }
                            )
                    )
                }"""

if android_view_pattern.search(content):
    content = android_view_pattern.sub(android_view_replacement, content)
    print("AndroidView updated")
else:
    print("AndroidView not found")
    
with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
