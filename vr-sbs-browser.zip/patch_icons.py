import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    ShortcutIcon(shortcut.first, Icons.Default.Public, Color.Blue) { onSearch(shortcut.second) }
                }
            }"""

replace = """            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    val url = shortcut.second.lowercase()
                    val icon = when {
                        url.contains("youtube.com") -> Icons.Default.PlayArrow
                        url.contains("reddit.com") -> Icons.Default.Menu
                        url.contains("github.com") -> Icons.Default.Info
                        url.contains("twitter.com") || url.contains("x.com") -> Icons.Default.Clear
                        url.contains("google.com") -> Icons.Default.Search
                        else -> Icons.Default.Public
                    }
                    val color = when {
                        url.contains("youtube.com") -> Color.Red
                        url.contains("reddit.com") -> Color(0xFFFF4500)
                        url.contains("github.com") -> Color.DarkGray
                        url.contains("twitter.com") || url.contains("x.com") -> Color.Black
                        url.contains("google.com") -> Color.Blue
                        else -> Color(0xFF6200EE)
                    }
                    ShortcutIcon(shortcut.first, icon, color) { onSearch(shortcut.second) }
                }
            }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
