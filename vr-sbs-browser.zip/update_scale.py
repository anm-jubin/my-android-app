import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Replace graphicsLayer block
graphics_pattern = re.compile(r"(\.fillMaxHeight\(\))\n\s+\.graphicsLayer \{\n\s+scaleX = scale\n\s+scaleY = scale\n\s+translationX = if \(isRightHandMode\) ipd else -ipd\n\s+translationY = verticalShift\n\s+\}", re.MULTILINE)
if graphics_pattern.search(content):
    content = graphics_pattern.sub(r"\1", content)
else:
    print("graphicsLayer not found")

# Replace AndroidView inside VRBrowserScreen
android_view_pattern = re.compile(r"AndroidView\(\n\s+factory = \{ browserManager\.container \},\n\s+modifier = Modifier\.fillMaxSize\(\)\n\s+\)")
android_view_replacement = """AndroidView(
                    factory = { browserManager.container },
                    modifier = Modifier.fillMaxSize(),
                    update = { container ->
                        container.scaleX = scale
                        container.scaleY = scale
                        container.translationX = if (isRightHandMode) ipd else -ipd
                        container.translationY = verticalShift
                    }
                )"""

if android_view_pattern.search(content):
    content = android_view_pattern.sub(android_view_replacement, content)
else:
    print("AndroidView not found")

# Replace TextureVideoPlayer signature and AndroidView
tex_sig_pattern = re.compile(r"fun TextureVideoPlayer\(uri: Uri, modifier: Modifier = Modifier\) \{")
tex_sig_replacement = """fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    modifier: Modifier = Modifier
) {"""

if tex_sig_pattern.search(content):
    content = tex_sig_pattern.sub(tex_sig_replacement, content)
else:
    print("TextureVideoPlayer signature not found")

# Now update TextureVideoPlayer usage in VRBrowserScreen
usage_pattern = re.compile(r"TextureVideoPlayer\(uri = localVideoUri!!\)")
usage_replacement = """TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode
                )"""
if usage_pattern.search(content):
    content = usage_pattern.sub(usage_replacement, content)
else:
    print("TextureVideoPlayer usage not found")

# Finally update TextureVideoPlayer's AndroidView to apply scale
tex_av_pattern = re.compile(r"modifier = Modifier\.fillMaxSize\(\)\n\s+\)")
# we only want to replace the SECOND match (in TextureVideoPlayer, but maybe just replace the one inside it)
# Let's find the position of TextureVideoPlayer and replace there.
tex_idx = content.find("fun TextureVideoPlayer")
if tex_idx != -1:
    av_idx = content.find("modifier = Modifier.fillMaxSize()", tex_idx)
    if av_idx != -1:
        end_idx = content.find(")", av_idx)
        tex_av_replacement = """modifier = Modifier.fillMaxSize(),
            update = { textureView ->
                textureView.scaleX = scale
                textureView.scaleY = scale
                textureView.translationX = if (isRightHandMode) ipd else -ipd
                textureView.translationY = verticalShift
            }"""
        content = content[:av_idx] + tex_av_replacement + content[end_idx+1:]
else:
    print("TextureVideoPlayer function not found")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Updated successfully")
