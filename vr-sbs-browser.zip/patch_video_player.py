import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)"""

replace = """    var videoAspectRatio by remember { mutableFloatStateOf(16f/9f) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)"""
content = content.replace(target, replace)

target2 = """                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }"""

replace2 = """                                try {
                                    setDataSource(ctx, uri)
                                    setOnVideoSizeChangedListener { _, vWidth, vHeight ->
                                        if (vWidth > 0 && vHeight > 0) {
                                            videoAspectRatio = vWidth.toFloat() / vHeight.toFloat()
                                        }
                                    }
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }"""
content = content.replace(target2, replace2)

target3 = """            AndroidView(
                factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnVideoSizeChangedListener { _, vWidth, vHeight ->
                                        if (vWidth > 0 && vHeight > 0) {
                                            videoAspectRatio = vWidth.toFloat() / vHeight.toFloat()
                                        }
                                    }
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                }
            },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
            )"""

replace3 = """            AndroidView(
                factory = { ctx ->
                    val frameLayout = android.widget.FrameLayout(ctx)
                    val textureView = TextureView(ctx).apply {
                        layoutParams = android.widget.FrameLayout.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.Gravity.CENTER
                        )
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                                mediaPlayer = MediaPlayer().apply {
                                    setSurface(Surface(surface))
                                    try {
                                        setDataSource(ctx, uri)
                                        setOnVideoSizeChangedListener { _, vWidth, vHeight ->
                                            if (vWidth > 0 && vHeight > 0) {
                                                videoAspectRatio = vWidth.toFloat() / vHeight.toFloat()
                                            }
                                        }
                                        setOnPreparedListener { 
                                            duration = it.duration
                                            isLooping = true
                                            start() 
                                        }
                                        prepareAsync()
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                            }
                            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                                mediaPlayer?.release()
                                mediaPlayer = null
                                return true
                            }
                            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                        }
                    }
                    frameLayout.addView(textureView)
                    frameLayout
                },
                update = { frameLayout ->
                    val textureView = frameLayout.getChildAt(0) as TextureView
                    // When URI changes, re-init MediaPlayer if Surface is already available
                    if (mediaPlayer == null && textureView.isAvailable) {
                        mediaPlayer = MediaPlayer().apply {
                            setSurface(Surface(textureView.surfaceTexture))
                            try {
                                setDataSource(frameLayout.context, uri)
                                setOnVideoSizeChangedListener { _, vWidth, vHeight ->
                                    if (vWidth > 0 && vHeight > 0) {
                                        videoAspectRatio = vWidth.toFloat() / vHeight.toFloat()
                                    }
                                }
                                setOnPreparedListener { 
                                    duration = it.duration
                                    isLooping = true
                                    start() 
                                }
                                prepareAsync()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .aspectRatio(videoAspectRatio)
                    .graphicsLayer { scaleX = scale; scaleY = scale }
            )"""
content = content.replace(target3, replace3)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
