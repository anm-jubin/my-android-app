import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """        if (showControls) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))"""

replace = """        if (seekingPos != null) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) {
                Text(
                    text = String.format("%02d:%02d", (seekingPos!! / 1000) / 60, (seekingPos!! / 1000) % 60),
                    color = Color.White,
                    style = MaterialTheme.typography.displayMedium
                )
            }
        } else if (showControls) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
