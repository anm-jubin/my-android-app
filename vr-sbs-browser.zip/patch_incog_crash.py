import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    fun clearIncognitoData() {
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
            val profileStore = androidx.webkit.ProfileStore.getInstance()
            profileStore.deleteProfile("incognito")
        }
    }"""

replace = """    fun clearIncognitoData() {
        try {
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val profileStore = androidx.webkit.ProfileStore.getInstance()
                val profile = profileStore.getProfile("incognito")
                if (profile != null) {
                    profile.cookieManager.removeAllCookies(null)
                    profile.webStorage.deleteAllData()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
