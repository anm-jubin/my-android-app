import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

tab_block = """                // Tab Bar
                ScrollableTabRow(
                    selectedTabIndex = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0),
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp),
                    containerColor = Color.DarkGray.copy(alpha = 0.8f),
                    contentColor = Color.White,
                    edgePadding = 8.dp,
                    indicator = { tabPositions ->
                        val index = tabs.indexOfFirst { it.id == activeTabId }.coerceAtLeast(0)
                        if (index < tabPositions.size) {
                            TabRowDefaults.Indicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[index]),
                                color = Color.White
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, tab ->
                        Tab(
                            selected = tab.id == activeTabId,
                            onClick = { 
                                activeTabId = tab.id
                                browserManager.activeTabId = tab.id
                            },
                            text = { 
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Tab ${index + 1}")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            browserManager.removeTab(tab.id)
                                            val newTabs = tabs.filter { it.id != tab.id }
                                            if (newTabs.isEmpty()) {
                                                val newId = java.util.UUID.randomUUID().toString().take(4)
                                                val newTab = WebTab(newId, "https://m.youtube.com")
                                                tabs = listOf(newTab)
                                                browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                                                activeTabId = newId
                                                browserManager.activeTabId = newId
                                            } else {
                                                tabs = newTabs
                                                if (activeTabId == tab.id) {
                                                    val nextTab = newTabs.last()
                                                    activeTabId = nextTab.id
                                                    browserManager.activeTabId = nextTab.id
                                                }
                                            }
                                        },
                                        modifier = Modifier.size(16.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        )
                    }
                    IconButton(onClick = { 
                        val newId = java.util.UUID.randomUUID().toString().take(4)
                        val newTab = WebTab(newId, "https://m.youtube.com")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                        activeTabId = newId
                        browserManager.activeTabId = newId
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                    }
                }"""

new_tab_block = """                // Tab Bar
                androidx.compose.foundation.lazy.LazyRow(
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    itemsIndexed(tabs) { index, tab ->
                        val isSelected = tab.id == activeTabId
                        Surface(
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp).clickable {
                                activeTabId = tab.id
                                browserManager.activeTabId = tab.id
                            },
                            color = if (isSelected) Color.White.copy(alpha = 0.2f) else Color.Transparent,
                            shape = MaterialTheme.shapes.small
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text("Tab ${index + 1}", color = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = {
                                        browserManager.removeTab(tab.id)
                                        val newTabs = tabs.filter { it.id != tab.id }
                                        if (newTabs.isEmpty()) {
                                            val newId = java.util.UUID.randomUUID().toString().take(4)
                                            val newTab = WebTab(newId, "https://m.youtube.com")
                                            tabs = listOf(newTab)
                                            browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                                            activeTabId = newId
                                            browserManager.activeTabId = newId
                                        } else {
                                            tabs = newTabs
                                            if (activeTabId == tab.id) {
                                                val nextTab = newTabs.last()
                                                activeTabId = nextTab.id
                                                browserManager.activeTabId = nextTab.id
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(16.dp)
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(12.dp))
                                }
                            }
                        }
                    }
                    item {
                        IconButton(onClick = { 
                            val newId = java.util.UUID.randomUUID().toString().take(4)
                            val newTab = WebTab(newId, "https://m.youtube.com")
                            tabs = tabs + newTab
                            browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                            activeTabId = newId
                            browserManager.activeTabId = newId
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                        }
                    }
                }"""

content = content.replace("import androidx.compose.foundation.lazy.items", "")
content = content.replace("import androidx.compose.foundation.lazy.LazyColumn", "import androidx.compose.foundation.lazy.LazyColumn\nimport androidx.compose.foundation.lazy.itemsIndexed")
content = content.replace(tab_block, new_tab_block)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

