import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """            // Shortcuts
            var showAddDialog by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    androidx.compose.foundation.layout.Box(modifier = Modifier.pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = { onRemoveShortcut(shortcut) }
                        ) { change, _ -> change.consume() }
                    }) {
                        ShortcutIcon(shortcut.first, Icons.Default.Public, Color.Blue) { onSearch(shortcut.second) }
                        IconButton(
                            onClick = { onRemoveShortcut(shortcut) },
                            modifier = Modifier.align(Alignment.TopEnd).size(24.dp).background(Color.Red, androidx.compose.foundation.shape.CircleShape)
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
                item {
                    ShortcutIcon("Add", Icons.Default.Add, Color.Gray) { showAddDialog = true }
                }
            }

            if (showAddDialog) {
                var newName by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
                var newUrl by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { showAddDialog = false },
                    title = { Text("Add Shortcut") },
                    text = {
                        Column {
                            TextField(value = newName, onValueChange = { newName = it }, label = { Text("Name") }, singleLine = true)
                            Spacer(modifier = Modifier.height(8.dp))
                            TextField(value = newUrl, onValueChange = { newUrl = it }, label = { Text("URL") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (newName.isNotBlank() && newUrl.isNotBlank()) {
                                val u = if (!newUrl.startsWith("http")) "https://$newUrl" else newUrl
                                onAddShortcut(newName, u)
                            }
                            showAddDialog = false
                        }) { Text("Add") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
                    }
                )
            }"""

replace = """            // Shortcuts
            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    ShortcutIcon(shortcut.first, Icons.Default.Public, Color.Blue) { onSearch(shortcut.second) }
                }
            }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
