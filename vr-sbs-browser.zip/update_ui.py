import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Replace Tab Bar
tab_bar_old = """                // Tab Bar
                androidx.compose.foundation.lazy.LazyRow(
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    itemsIndexed(tabs) { index, tab ->
                        val isSelected = tab.id == activeTabId
                        Surface(
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp).clickable {
                                activeTabId = tab.id
                                browserManager.activeTabId = tab.id
                            },
                            color = if (isSelected) Color.White.copy(alpha = 0.2f) else Color.Transparent,
                            shape = MaterialTheme.shapes.small
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text("Tab ${index + 1}", color = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(
                                    onClick = {
                                        browserManager.removeTab(tab.id)
                                        val newTabs = tabs.filter { it.id != tab.id }
                                        if (newTabs.isEmpty()) {
                                            val newId = java.util.UUID.randomUUID().toString().take(4)
                                            val newTab = WebTab(newId, "https://m.youtube.com")
                                            tabs = listOf(newTab)
                                            browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                                            activeTabId = newId
                                            browserManager.activeTabId = newId
                                        } else {
                                            tabs = newTabs
                                            if (activeTabId == tab.id) {
                                                val nextTab = newTabs.last()
                                                activeTabId = nextTab.id
                                                browserManager.activeTabId = nextTab.id
                                            }
                                        }
                                    },
                                    modifier = Modifier.size(16.dp)
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(12.dp))
                                }
                            }
                        }
                    }
                    item {
                        IconButton(onClick = { 
                            val newId = java.util.UUID.randomUUID().toString().take(4)
                            val newTab = WebTab(newId, "https://m.youtube.com")
                            tabs = tabs + newTab
                            browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                            activeTabId = newId
                            browserManager.activeTabId = newId
                        }) {
                            Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                        }
                    }
                }"""

tab_bar_new = """                // Tab Bar
                Row(
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        itemsIndexed(tabs) { index, tab ->
                            val isSelected = tab.id == activeTabId
                            Surface(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp).clickable {
                                    activeTabId = tab.id
                                    browserManager.activeTabId = tab.id
                                },
                                color = if (isSelected) Color.White.copy(alpha = 0.2f) else Color.Transparent,
                                shape = MaterialTheme.shapes.small
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text("Tab ${index + 1}", color = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            browserManager.removeTab(tab.id)
                                            val newTabs = tabs.filter { it.id != tab.id }
                                            if (newTabs.isEmpty()) {
                                                val newId = java.util.UUID.randomUUID().toString().take(4)
                                                val newTab = WebTab(newId, "https://m.youtube.com")
                                                tabs = listOf(newTab)
                                                browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                                                activeTabId = newId
                                                browserManager.activeTabId = newId
                                            } else {
                                                tabs = newTabs
                                                if (activeTabId == tab.id) {
                                                    val nextTab = newTabs.last()
                                                    activeTabId = nextTab.id
                                                    browserManager.activeTabId = nextTab.id
                                                }
                                            }
                                        },
                                        modifier = Modifier.size(16.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                    
                    IconButton(onClick = { 
                        val newId = java.util.UUID.randomUUID().toString().take(4)
                        val newTab = WebTab(newId, "https://m.youtube.com")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                        activeTabId = newId
                        browserManager.activeTabId = newId
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                    }
                    
                    Box {
                        var menuExpanded by remember { mutableStateOf(false) }
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(androidx.compose.material.icons.Icons.Default.MoreVert, contentDescription = "More Options", tint = Color.White)
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Local Video") },
                                onClick = { 
                                    menuExpanded = false
                                    videoPickerLauncher.launch("video/*")
                                },
                                leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Bookmarks") },
                                onClick = { 
                                    menuExpanded = false
                                    showBookmarksList = !showBookmarksList
                                    if (showBookmarksList) showControls = false
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = { 
                                    menuExpanded = false
                                    showControls = !showControls
                                    if (showControls) showBookmarksList = false
                                },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) }
                            )
                        }
                    }
                }"""
content = content.replace(tab_bar_old, tab_bar_new)


# Replace Address Bar
address_bar_old = """                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            videoPickerLauncher.launch("video/*")
                        }) {
                            Icon(Icons.Default.Folder, contentDescription = "Open Local Video", tint = Color.White)
                        }
                        IconButton(onClick = { urlInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { 
                            val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (title to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark", tint = Color.White)
                        }
                        IconButton(onClick = { showBookmarksList = !showBookmarksList; if (showBookmarksList) showControls = false }) {
                            Icon(Icons.Default.List, contentDescription = "Bookmarks", tint = Color.White)
                        }
                        IconButton(onClick = { showControls = !showControls; if (showControls) showBookmarksList = false }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }"""

address_bar_new = """                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (title to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark", tint = Color.White)
                        }
                        IconButton(onClick = { urlInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            browserManager.loadUrlInActiveTab(finalUrl)
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }"""
content = content.replace(address_bar_old, address_bar_new)

# Ensure MoreVert is imported properly
if "import androidx.compose.material.icons.filled.MoreVert" not in content:
    content = content.replace("import androidx.compose.material.icons.filled.List", "import androidx.compose.material.icons.filled.List\nimport androidx.compose.material.icons.filled.MoreVert")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

