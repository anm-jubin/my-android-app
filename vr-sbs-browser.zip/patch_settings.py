import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                            Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = verticalShift,
                                onValueChange = { verticalShift = it },
                                valueRange = -300f..300f
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button("""

replace = """                            Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = verticalShift,
                                onValueChange = { verticalShift = it },
                                valueRange = -300f..300f
                            )
                            
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Gyroscope Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = gyroEnabled, onCheckedChange = { 
                                    gyroEnabled = it 
                                    if (it) shouldRecenter = true
                                })
                            }
                            if (gyroEnabled) {
                                Text("Gyro Sensitivity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = gyroSensitivity,
                                    onValueChange = { gyroSensitivity = it },
                                    valueRange = 500f..3000f
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button("""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
