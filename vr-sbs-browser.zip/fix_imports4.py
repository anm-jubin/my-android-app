import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("import androidx.compose.material.icons.Icons.Default.Check", "import androidx.compose.material.icons.filled.Check")
content = content.replace("import androidx.compose.material.icons.Icons.Default.Add", "import androidx.compose.material.icons.filled.Add")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
