import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("androidx.compose.material.icons.Icons.Default.Check", "Icons.Default.Done")
content = content.replace("androidx.compose.material.icons.Icons.Default.Add", "Icons.Default.Add")
content = content.replace("import androidx.compose.material.icons.filled.Check", "import androidx.compose.material.icons.filled.Done")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
