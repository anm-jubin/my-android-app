with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# I will just rewrite the AndroidView block in TextureVideoPlayer cleanly
pattern = """        androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = { ctx ->AndroidView(
            factory = { ctx ->"""

replacement = """        androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->"""

content = content.replace(pattern, replacement)

pattern2 = """            modifier = Modifier
                .fillMaxSize(fraction = scale)
        }
                .offset(
                    x = with(androidx.compose.ui.platform.LocalDensity.current) { (if (isRightHandMode) ipd else -ipd).toDp() },
                    y = with(androidx.compose.ui.platform.LocalDensity.current) { verticalShift.toDp() }
                )
        )"""

replacement2 = """                modifier = Modifier
                    .fillMaxSize(fraction = scale)
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { (if (isRightHandMode) ipd else -ipd).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { verticalShift.toDp() }
                    )
            )
        }"""
content = content.replace(pattern2, replacement2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
