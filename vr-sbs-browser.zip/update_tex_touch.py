import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

tex_av_pattern = re.compile(r"modifier = Modifier\.fillMaxSize\(\),\n\s+update = \{ textureView ->\n\s+textureView\.scaleX = scale\n\s+textureView\.scaleY = scale\n\s+textureView\.translationX = if \(isRightHandMode\) ipd else -ipd\n\s+textureView\.translationY = verticalShift\n\s+\}")

tex_av_replacement = """modifier = Modifier
                .fillMaxSize(fraction = scale)
                .offset(
                    x = with(androidx.compose.ui.platform.LocalDensity.current) { (if (isRightHandMode) ipd else -ipd).toDp() },
                    y = with(androidx.compose.ui.platform.LocalDensity.current) { verticalShift.toDp() }
                )"""

tex_sig = content.find("fun TextureVideoPlayer")
if tex_sig != -1:
    av_idx = content.find("modifier = Modifier.fillMaxSize(),", tex_sig)
    if av_idx != -1:
        end_idx = content.find("}", av_idx)
        content = content[:av_idx] + tex_av_replacement + content[end_idx+1:]
        print("TextureVideoPlayer AndroidView updated")
        with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
            f.write(content)
else:
    print("Not found")
