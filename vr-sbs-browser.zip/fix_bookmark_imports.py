import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

imports_to_add = """
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.List
"""

content = content.replace("import androidx.compose.material.icons.filled.Done", "import androidx.compose.material.icons.filled.Done\n" + imports_to_add)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
