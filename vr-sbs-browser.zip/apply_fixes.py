import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix 1: Wrap the split screen Box with a new Box that handles vrLensDistortion, 
# removing it from the outermost BoxWithConstraints.
target1 = "BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black).vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {"
replace1 = "BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {"
content = content.replace(target1, replace1)

# Now, right before "Box(" for the split screen, we insert the wrapper.
target2 = """        // The single WebView container, drawn twice using Compose rendering!
        // Using graphicsLayer maps the affine transform (scale/translate) natively to the View layer,
        // which perfectly fixes the touch mapping offsets when scaling or shifting the IPD.
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)"""
replace2 = """        // Wrapper for the lens distortion, so it only distorts the content, not the UI!
        Box(modifier = Modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {
        // The single WebView container, drawn twice using Compose rendering!
        // Using graphicsLayer maps the affine transform (scale/translate) natively to the View layer,
        // which perfectly fixes the touch mapping offsets when scaling or shifting the IPD.
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)"""
content = content.replace(target2, replace2)

# We must close the wrapper Box after the inner Box finishes.
# The inner Box ends before "// Left Eye Floating Action Button"
target3 = """            }
        }

        // Left Eye Floating Action Button"""
replace3 = """            }
        }
        } // Close distortion wrapper

        // Left Eye Floating Action Button"""
content = content.replace(target3, replace3)


# Fix 2: AndroidView scaling
target4 = """                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize(fraction = scale)
                            .offset("""
replace4 = """                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                            .offset("""
content = content.replace(target4, replace4)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
