import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target1 = """                            onAddShortcut = { name, url ->
                                val newList = customShortcuts + Pair(name, url)
                                customShortcuts = newList
                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                            },
                            onRemoveShortcut = { shortcut ->
                                val newList = customShortcuts.filter { it != shortcut }
                                customShortcuts = newList
                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                            }"""
replace1 = """"""
content = content.replace(target1, replace1)

target2 = """@Composable
fun NewTabPage(
    isPassthroughEnabled: Boolean,
    shortcuts: List<Pair<String, String>>,
    onSearch: (String) -> Unit,
    onAddShortcut: (String, String) -> Unit,
    onRemoveShortcut: (Pair<String, String>) -> Unit
) {"""
replace2 = """@Composable
fun NewTabPage(
    isPassthroughEnabled: Boolean,
    shortcuts: List<Pair<String, String>>,
    onSearch: (String) -> Unit
) {"""
content = content.replace(target2, replace2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
