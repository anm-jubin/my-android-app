import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix 1: Type hint the bookmarks
content = content.replace(
    'androidx.compose.runtime.mutableStateOf((prefs.getString("bookmarks", "") ?: "").split(",").mapNotNull {',
    'androidx.compose.runtime.mutableStateOf<List<Pair<String, String>>>((prefs.getString("bookmarks", "") ?: "").split(",").mapNotNull {'
)
content = content.replace(
    'if (parts.size == 2) parts[0] to parts[1] else null',
    'if (parts.size == 2) Pair(parts[0], parts[1]) else null'
)

# Fix 2: Import items
if "import androidx.compose.foundation.lazy.items" not in content:
    content = content.replace("package com.example", "package com.example\nimport androidx.compose.foundation.lazy.items")

# Fix 3: Remove the qualified items call
content = content.replace("androidx.compose.foundation.lazy.items(bookmarks)", "items(bookmarks)")

# Fix 4: Change Star/StarBorder to Favorite/FavoriteBorder if Star doesn't work.
content = content.replace("androidx.compose.material.icons.Icons.Default.Star", "androidx.compose.material.icons.Icons.Default.Favorite")
content = content.replace("androidx.compose.material.icons.Icons.Default.StarBorder", "androidx.compose.material.icons.Icons.Default.FavoriteBorder")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

