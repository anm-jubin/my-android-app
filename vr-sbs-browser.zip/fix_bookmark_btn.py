import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_btn = """                        IconButton(onClick = { 
                            val host = try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (host to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) Icons.Default.Done else Icons.Default.Add, "Bookmark", tint = Color.White)
                        }"""

# Replace host with title from webview
replacement_btn = """                        IconButton(onClick = { 
                            val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (title to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) androidx.compose.material.icons.Icons.Default.Bookmark else androidx.compose.material.icons.Icons.Default.BookmarkBorder, "Bookmark", tint = Color.White)
                        }"""

content = content.replace(target_btn, replacement_btn)

# Add Bookmarks List Toggle Button
settings_btn = """                        IconButton(onClick = { showControls = !showControls }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }"""

bookmarks_toggle_btn = """                        IconButton(onClick = { showBookmarksList = !showBookmarksList; if (showBookmarksList) showControls = false }) {
                            Icon(androidx.compose.material.icons.Icons.Default.List, contentDescription = "Bookmarks", tint = Color.White)
                        }
                        IconButton(onClick = { showControls = !showControls; if (showControls) showBookmarksList = false }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                        }"""

content = content.replace(settings_btn, bookmarks_toggle_btn)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
