import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Incognito Mode", color = if (isIncognito) Color.Cyan else Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(
                                        checked = isIncognito, 
                                        onCheckedChange = { 
                                            isIncognito = it 
                                            browserManager.updateIncognitoMode(it)
                                        }
                                    )
                                }
                                androidx.compose.material3.TextButton(onClick = { browserManager.clearIncognitoData() }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Clear Incognito Data", color = Color.Red)
                                }"""

replace = """                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Incognito Mode", color = if (isIncognito) Color.Cyan else Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(
                                        checked = isIncognito, 
                                        onCheckedChange = { 
                                            isIncognito = it 
                                            browserManager.updateIncognitoMode(it)
                                        }
                                    )
                                }
                                if (isIncognito) {
                                    androidx.compose.material3.TextButton(onClick = { browserManager.clearIncognitoData() }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Clear Incognito Data", color = Color.Red)
                                    }
                                }"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
