import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add states for incognito
target_states = """    var showHistoryList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }"""

replace_states = """    var showHistoryList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var isIncognito by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isIncognito", false)) }"""
content = content.replace(target_states, replace_states)

# Add saving prefs and preventing tabs/history from saving if incognito
target_prefs = """            .putString("searchEngine", searchEngine)
            .putBoolean("historyEnabled", historyEnabled)
            .putString("historyList", historyList.joinToString(",") { "${it.first}|${it.second}" })
            .putBoolean("gyroEnabled", gyroEnabled)
            .putFloat("gyroSensitivity", gyroSensitivity)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("bookmarks", bookmarks.joinToString(",") { "${it.first}|${it.second}" })
            .putString("activeTabId", activeTabId)
            .apply()"""

replace_prefs = """            .putString("searchEngine", searchEngine)
            .putBoolean("historyEnabled", historyEnabled)
            .putString("historyList", historyList.joinToString(",") { "${it.first}|${it.second}" })
            .putBoolean("gyroEnabled", gyroEnabled)
            .putFloat("gyroSensitivity", gyroSensitivity)
            .putBoolean("isIncognito", isIncognito)
            .putString("savedTabs", if (isIncognito) "" else tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("bookmarks", bookmarks.joinToString(",") { "${it.first}|${it.second}" })
            .putString("activeTabId", if (isIncognito) "" else activeTabId)
            .apply()"""
content = content.replace(target_prefs, replace_prefs)

# Add to LaunchedEffect dependencies
target_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList) {"""
replace_effect = """    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito) {"""
content = content.replace(target_effect, replace_effect)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
