with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("androidx.compose.material.icons.Icons.Default.FavoriteBorder", "androidx.compose.material.icons.Icons.Default.Add")
content = content.replace("androidx.compose.material.icons.Icons.Default.Favorite", "androidx.compose.material.icons.Icons.Default.Check")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
