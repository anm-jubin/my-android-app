with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("valueRange = 0.01f..0.5f", "valueRange = 0.0f..1.5f")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
