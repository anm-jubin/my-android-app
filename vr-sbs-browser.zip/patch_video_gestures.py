import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                    
                    setOnClickListener {
                        showControls = !showControls
                    }
                }
            },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
            )
        }"""

replace = """    var seekingPos by remember { mutableStateOf<Int?>(null) }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        mediaPlayer?.let { player ->
                            val halfWidth = size.width / 2
                            val seekAmount = 10000
                            if (offset.x < halfWidth) {
                                val newPos = (player.currentPosition - seekAmount).coerceAtLeast(0)
                                player.seekTo(newPos)
                                currentPos = newPos
                            } else {
                                val newPos = (player.currentPosition + seekAmount).coerceAtMost(duration)
                                player.seekTo(newPos)
                                currentPos = newPos
                            }
                            showControls = true
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                var dragAccumulator = 0f
                detectHorizontalDragGestures(
                    onDragStart = { 
                        dragAccumulator = 0f
                        seekingPos = mediaPlayer?.currentPosition
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        dragAccumulator += dragAmount
                        // 10 pixels = 1 second
                        val seekMs = (dragAccumulator / 10f) * 1000f
                        seekingPos = ((mediaPlayer?.currentPosition ?: 0) + seekMs.toInt()).coerceIn(0, duration)
                    },
                    onDragEnd = {
                        seekingPos?.let { pos ->
                            mediaPlayer?.seekTo(pos)
                            currentPos = pos
                        }
                        seekingPos = null
                        showControls = true
                    },
                    onDragCancel = { seekingPos = null }
                )
            }
    ) {
        androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                }
            },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
            )
        }"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
