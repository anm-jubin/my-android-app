with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

imports = """import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.filled.Add
"""

# add it after the first import
content = content.replace("import android.annotation.SuppressLint", "import android.annotation.SuppressLint\n" + imports)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
