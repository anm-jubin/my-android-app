import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("androidx.compose.material.icons.Icons.Default.BookmarkBorder", "Icons.Default.BookmarkBorder")
content = content.replace("androidx.compose.material.icons.Icons.Default.Bookmark", "Icons.Default.Bookmark")
content = content.replace("androidx.compose.material.icons.Icons.Default.List", "Icons.Default.List")
content = content.replace("androidx.compose.material.icons.Icons.Default.Clear", "Icons.Default.Clear")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
