import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_horizontal = """
                if (bookmarks.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.fillMaxWidth().height(32.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        items(bookmarks) { bookmark ->
                            Surface(
                                modifier = Modifier.padding(horizontal = 4.dp).clickable {
                                    urlInput = bookmark.second
                                    currentUrl = bookmark.second
                                    browserManager.loadUrlInActiveTab(bookmark.second)
                                    localVideoUri = null
                                    isUiVisible = false
                                },
                                color = Color.White.copy(alpha = 0.2f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Text(bookmark.first, color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(onClick = { bookmarks = bookmarks.filter { it != bookmark } }, modifier = Modifier.size(16.dp)) {
                                        Icon(androidx.compose.material.icons.Icons.Default.Clear, "Remove", tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                }"""

vertical_bookmarks = """
                if (showBookmarksList) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("Bookmarks", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                if (bookmarks.isNotEmpty()) {
                                    androidx.compose.material3.TextButton(onClick = { bookmarks = emptyList() }) {
                                        Text("Clear All", color = Color.Red.copy(alpha = 0.8f))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(bookmarks) { bookmark ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                                            urlInput = bookmark.second
                                            currentUrl = bookmark.second
                                            browserManager.loadUrlInActiveTab(bookmark.second)
                                            localVideoUri = null
                                            isUiVisible = false
                                        },
                                        color = Color.White.copy(alpha = 0.1f),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(bookmark.first, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                                Text(bookmark.second, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                            }
                                            IconButton(onClick = { bookmarks = bookmarks.filter { it != bookmark } }) {
                                                Icon(androidx.compose.material.icons.Icons.Default.Clear, "Remove", tint = Color.White)
                                            }
                                        }
                                    }
                                }
                                if (bookmarks.isEmpty()) {
                                    item {
                                        Text("No bookmarks yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }"""

content = content.replace(target_horizontal, vertical_bookmarks)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
