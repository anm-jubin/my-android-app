import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix all the sliders
content = re.sub(r'Text\("([^"]+): \$\{String\.format\(\\"([^"]+)\\", ([^\}]+)\)\}", color = Color\.White, style = MaterialTheme\.typography\.labelSmall\)',
                 r'Text(String.format("\1: \2", \3), color = Color.White, style = MaterialTheme.typography.labelSmall)', content)
# And the one with unescaped quotes if any
content = re.sub(r'Text\("([^"]+): \$\{String\.format\("([^"]+)", ([^\}]+)\)\}", color = Color\.White, style = MaterialTheme\.typography\.labelSmall\)',
                 r'Text(String.format("\1: \2", \3), color = Color.White, style = MaterialTheme.typography.labelSmall)', content)


# Fix ShortcutIcon
target_icon = """@Composable
fun ShortcutIcon(name: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.FloatingActionButton(
            onClick = onClick,
            containerColor = Color.White,
            contentColor = color,
            modifier = Modifier.size(64.dp)
        ) {
            Icon(icon, contentDescription = name, modifier = Modifier.size(32.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(name, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}"""

replace_icon = """@Composable
fun ShortcutIcon(name: String, url: String, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.FloatingActionButton(
            onClick = onClick,
            containerColor = Color.White,
            modifier = Modifier.size(64.dp)
        ) {
            val domain = try { android.net.Uri.parse(url).host ?: url } catch (e: Exception) { url }
            coil.compose.AsyncImage(
                model = "https://www.google.com/s2/favicons?domain=$domain&sz=128",
                contentDescription = name,
                modifier = Modifier.size(32.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(name, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}"""
content = content.replace(target_icon, replace_icon)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
