import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

clear_target = """                            Button(
                                onClick = {
                                    android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                    android.webkit.CookieManager.getInstance().flush()
                                    android.webkit.WebStorage.getInstance().deleteAllData()
                                    android.widget.Toast.makeText(context, "Sign-in data cleared!", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                            ) {
                                Text("Clear Sign-in Data", color = Color.White)
                            }"""

clear_replace = """                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        android.webkit.WebStorage.getInstance().deleteOrigin(currentUrl)
                                        android.widget.Toast.makeText(context, "Cleared data for this site!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                                ) {
                                    Text("Clear This Site", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                                Button(
                                    onClick = {
                                        android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                        android.webkit.CookieManager.getInstance().flush()
                                        android.webkit.WebStorage.getInstance().deleteAllData()
                                        android.widget.Toast.makeText(context, "All data cleared!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                                ) {
                                    Text("Clear All Data", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                            }"""

content = content.replace(clear_target, clear_replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

