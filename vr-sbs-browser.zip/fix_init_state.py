with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = "var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }"
replace = "var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }"

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
