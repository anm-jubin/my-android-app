import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target1 = """                val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
                val wantsDesktop = isDesktopMode && !isMobileFriendly
                userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)"""

replace1 = """                userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)"""

content = content.replace(target1, replace1)

target2 = """                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    view?.let {
                        val isMobileFriendly = newUrl.contains("instagram.com") || newUrl.contains("tiktok.com")
                        val wantsDesktop = this@BrowserManager.isDesktopMode && !isMobileFriendly
                        val isCurrentlyDesktop = it.settings.userAgentString.contains("Windows NT")
                        if (wantsDesktop != isCurrentlyDesktop) {
                            it.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            it.loadUrl(newUrl)
                            return true
                        }
                    }
                    return false
                }"""

replace2 = """                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    view?.let {
                        val isCurrentlyDesktop = it.settings.userAgentString.contains("Windows NT")
                        if (this@BrowserManager.isDesktopMode != isCurrentlyDesktop) {
                            it.settings.userAgentString = if (this@BrowserManager.isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            it.loadUrl(newUrl)
                            return true
                        }
                    }
                    return false
                }"""

content = content.replace(target2, replace2)

target3 = """                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        val js = \"\"\"
                            var meta = document.querySelector('meta[name="viewport"]');
                            if (meta) {
                                meta.content = 'width=500, user-scalable=no';
                            } else {
                                meta = document.createElement('meta');
                                meta.name = 'viewport';
                                meta.content = 'width=500, user-scalable=no';
                                document.head.appendChild(meta);
                            }
                            var style = document.createElement('style');
                            style.innerHTML = 'html, body { width: 100% !important; overflow-x: hidden !important; } #react-root, main, #mount_0_0 { margin: 0 auto !important; display: flex !important; justify-content: center !important; flex-direction: column !important; align-items: center !important; }';
                            document.head.appendChild(style);
                        \"\"\".trimIndent()
                        view.evaluateJavascript(js, null)
                    }"""
content = content.replace(target3, "")

target4 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.let { view ->
            val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
            val wantsDesktop = this.isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                view.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(view.context)
            }
            view.loadUrl(url)
        }
    }"""
replace4 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.let { view ->
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (this.isDesktopMode != isCurrentlyDesktop) {
                view.settings.userAgentString = if (this.isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(view.context)
            }
            view.loadUrl(url)
        }
    }"""
content = content.replace(target4, replace4)

target5 = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val isMobileFriendly = view.url?.contains("instagram.com") == true || view.url?.contains("tiktok.com") == true
            val wantsDesktop = isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    view.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    view.settings.userAgentString = WebSettings.getDefaultUserAgent(view.context)
                }
                view.reload()
            }
        }
    }"""
replace5 = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (isDesktopMode != isCurrentlyDesktop) {
                if (isDesktopMode) {
                    view.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    view.settings.userAgentString = WebSettings.getDefaultUserAgent(view.context)
                }
                view.reload()
            }
        }
    }"""
content = content.replace(target5, replace5)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
