import os
print("Checking syntax...")
