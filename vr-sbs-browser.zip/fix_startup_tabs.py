import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    val savedTabsStr = "1|https://m.youtube.com"
    var tabs by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf(savedTabsStr.split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) WebTab(parts[0], parts[1]) else null
        }.ifEmpty { listOf(WebTab("1", "https://m.youtube.com")) }) 
    }
    var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("1") }"""

replacement = """    val savedTabsStr = prefs.getString("savedTabs", "") ?: ""
    var tabs by androidx.compose.runtime.remember { 
        val loadedTabs = savedTabsStr.split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) WebTab(parts[0], parts[1]) else null
        }
        val newId = java.util.UUID.randomUUID().toString().take(4)
        val freshTab = WebTab(newId, "https://m.youtube.com")
        // Check if there's already an empty default tab from previous session, to avoid infinite empty tabs
        val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" || loadedTabs.size == 1 }
        androidx.compose.runtime.mutableStateOf(listOf(freshTab) + filteredLoaded)
    }
    var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.first().id) }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Startup tabs updated.")
