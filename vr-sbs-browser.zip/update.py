import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

pattern = re.compile(r"@Composable\nfun VRBrowserScreen\(modifier: Modifier = Modifier\) \{.*?\n    \}\n", re.DOTALL)

replacement = """@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = androidx.compose.runtime.remember { context.getSharedPreferences("vr_prefs", android.content.Context.MODE_PRIVATE) }
    
    val savedTabsStr = prefs.getString("savedTabs", "1|https://m.youtube.com") ?: "1|https://m.youtube.com"
    var tabs by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf(savedTabsStr.split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) WebTab(parts[0], parts[1]) else null
        }.ifEmpty { listOf(WebTab("1", "https://m.youtube.com")) }) 
    }
    var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("activeTabId", tabs.firstOrNull()?.id ?: "1")) }

    var urlInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.firstOrNull { it.id == activeTabId }?.url ?: "https://m.youtube.com") }
    var currentUrl by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(urlInput) }
    var isUiVisible by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
    var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
        
    var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isDesktopMode", true)) }
    var isRightHandMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isRightHandMode", true)) }
    var scale by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("scale", 1f)) }
    var ipd by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("ipd", 0f)) }
    var verticalShift by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("verticalShift", 0f)) }
        
    var fabOffsetX by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetX", 50f)) }
    var fabOffsetY by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetY", 300f)) }

    val browserManager = androidx.compose.runtime.remember { 
        BrowserManager(context).apply {
            tabs.forEach { addTab(it.id, it.url, isDesktopMode) }
            this.activeTabId = activeTabId
        }
    }
    
    var canGoBack by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        browserManager.onUrlChanged = { newUrl ->
            urlInput = newUrl
            currentUrl = newUrl
            tabs = tabs.map { if (it.id == activeTabId) it.copy(url = newUrl) else it }
        }
        browserManager.onCanGoBackChanged = { canGoBack = it }
    }
    
    androidx.activity.compose.BackHandler(enabled = canGoBack) {
        browserManager.goBack()
    }
    
    androidx.compose.runtime.LaunchedEffect(isDesktopMode) {
        browserManager.updateDesktopMode(isDesktopMode)
    }

    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId) {
        prefs.edit()
            .putBoolean("isDesktopMode", isDesktopMode)
            .putBoolean("isRightHandMode", isRightHandMode)
            .putFloat("scale", scale)
            .putFloat("ipd", ipd)
            .putFloat("verticalShift", verticalShift)
            .putFloat("fabOffsetX", fabOffsetX)
            .putFloat("fabOffsetY", fabOffsetY)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("activeTabId", activeTabId)
            .apply()
    }
"""

if pattern.search(content):
    content = pattern.sub(replacement, content, count=1)
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content)
    print("Success")
else:
    print("Pattern not found")
