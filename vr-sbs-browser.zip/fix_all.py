import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix 1: Filter to take max 2 tabs
content = content.replace(
    'val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" }',
    'val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" }.take(2)'
)

# Fix 2: Revert Smart Screen Control
content = content.replace(
    'onClick = { isUiVisible = !isUiVisible; isRightHandMode = false }',
    'onClick = { isUiVisible = !isUiVisible }'
)
content = content.replace(
    'onClick = { isUiVisible = !isUiVisible; isRightHandMode = true }',
    'onClick = { isUiVisible = !isUiVisible }'
)

# Fix 3: Add Bookmarks State
bookmarks_state = """    var bookmarks by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf((prefs.getString("bookmarks", "") ?: "").split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) parts[0] to parts[1] else null
        }) 
    }"""
content = content.replace("    var tabs by androidx.compose.runtime.remember {", bookmarks_state + "\n    var tabs by androidx.compose.runtime.remember {")

# Add Bookmarks to LaunchedEffect for saving
launched_effect_target = """            .putFloat("lensDistortion", lensDistortion)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })"""
launched_effect_replace = """            .putFloat("lensDistortion", lensDistortion)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("bookmarks", bookmarks.joinToString(",") { "${it.first}|${it.second}" })"""
content = content.replace(launched_effect_target, launched_effect_replace)

launched_effect_deps_target = "tabs, activeTabId, lensWrapping, lensDistortion) {"
launched_effect_deps_replace = "tabs, activeTabId, lensWrapping, lensDistortion, bookmarks) {"
content = content.replace(launched_effect_deps_target, launched_effect_deps_replace)

# Add Bookmark star button
star_target = """                        IconButton(onClick = { showControls = !showControls }) {"""
star_replace = """                        IconButton(onClick = { 
                            val host = try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (host to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) androidx.compose.material.icons.Icons.Default.Star else androidx.compose.material.icons.Icons.Default.StarBorder, "Bookmark", tint = Color.White)
                        }
                        IconButton(onClick = { showControls = !showControls }) {"""
content = content.replace(star_target, star_replace)

# Add Bookmarks Row UI
bookmarks_row = """
                if (bookmarks.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.fillMaxWidth().height(32.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.foundation.lazy.items(bookmarks) { bookmark ->
                            Surface(
                                modifier = Modifier.padding(horizontal = 4.dp).clickable {
                                    urlInput = bookmark.second
                                    currentUrl = bookmark.second
                                    browserManager.loadUrlInActiveTab(bookmark.second)
                                    localVideoUri = null
                                    isUiVisible = false
                                },
                                color = Color.White.copy(alpha = 0.2f),
                                shape = MaterialTheme.shapes.small
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)) {
                                    Text(bookmark.first, color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(onClick = { bookmarks = bookmarks.filter { it != bookmark } }, modifier = Modifier.size(16.dp)) {
                                        Icon(androidx.compose.material.icons.Icons.Default.Clear, "Remove", tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                }
"""

if "if (showControls) {" in content:
    content = content.replace("                if (showControls) {", bookmarks_row + "                if (showControls) {", 1)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

