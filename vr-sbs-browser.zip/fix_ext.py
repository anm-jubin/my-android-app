import re
with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# find where it starts
start_idx = content.find("@android.annotation.SuppressLint(\"NewApi\")")
if start_idx != -1:
    content = content[:start_idx]

extension = """
@android.annotation.SuppressLint("NewApi")
fun Modifier.vrLensDistortion(distortion: Float): Modifier = this.then(
    if (android.os.Build.VERSION.SDK_INT >= 33 && distortion > 0f) {
        androidx.compose.ui.Modifier.graphicsLayer {
            val shader = android.graphics.RuntimeShader(\"\"\"
                uniform float2 resolution;
                uniform float distortion;
                uniform shader composable;
                
                half4 main(float2 fragCoord) {
                    float halfWidth = resolution.x * 0.5;
                    float isRight = step(halfWidth, fragCoord.x);
                    float offsetX = isRight * halfWidth;
                    
                    float2 uv = float2(fragCoord.x - offsetX, fragCoord.y) / float2(halfWidth, resolution.y);
                    
                    float2 centered = uv - 0.5;
                    float r2 = dot(centered, centered);
                    float2 distorted = centered * (1.0 + distortion * r2);
                    
                    float2 outUv = distorted + 0.5;
                    if (outUv.x < 0.0 || outUv.x > 1.0 || outUv.y < 0.0 || outUv.y > 1.0) {
                        return half4(0.0, 0.0, 0.0, 1.0);
                    }
                    
                    float2 screenUv = float2(outUv.x * halfWidth + offsetX, outUv.y * resolution.y);
                    return composable.eval(screenUv);
                }
            \"\"\")
            shader.setFloatUniform("resolution", size.width, size.height)
            shader.setFloatUniform("distortion", distortion)
            renderEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "composable").asComposeRenderEffect()
        }
    } else {
        androidx.compose.ui.Modifier
    }
)
"""
content += extension

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
