import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix 1: Stop restoring tabs on launch to give a fresh view
content = content.replace(
    'val savedTabsStr = prefs.getString("savedTabs", "1|https://m.youtube.com") ?: "1|https://m.youtube.com"',
    'val savedTabsStr = "1|https://m.youtube.com"'
)
content = content.replace(
    'var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("activeTabId", tabs.firstOrNull()?.id ?: "1")) }',
    'var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("1") }'
)

# Fix 2: Smart Control Side (Left FAB -> Left side, Right FAB -> Right side)
fab1_old = "onClick = { isUiVisible = !isUiVisible }"
fab1_new = "onClick = { isUiVisible = !isUiVisible; isRightHandMode = false }"
content = content.replace(fab1_old, fab1_new, 1)

fab2_old = "onClick = { isUiVisible = !isUiVisible }"
fab2_new = "onClick = { isUiVisible = !isUiVisible; isRightHandMode = true }"
content = content.replace(fab2_old, fab2_new, 1)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
