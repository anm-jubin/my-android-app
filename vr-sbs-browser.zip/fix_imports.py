with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace(
    "androidx.compose.ui.graphics.graphicsLayer {",
    "androidx.compose.ui.Modifier.Companion.run {\n        this@vrLensDistortion.graphicsLayer {\n"
)
# Actually, I can just add imports at the top
imports = """import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asComposeRenderEffect
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
"""

content = content.replace("package com.example", "package com.example\n\n" + imports)

# Then fix the modifier
content = content.replace(
    "androidx.compose.ui.Modifier.Companion.run {\\n        this@vrLensDistortion.graphicsLayer {\\n",
    "this.graphicsLayer {"
)
# Re-read and just string-replace the bad line
content = content.replace("androidx.compose.ui.graphics.graphicsLayer {", "graphicsLayer {")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
