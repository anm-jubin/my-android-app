import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                            SettingsSection("Virtual Screen") {"""

replace = """                            SettingsSection("Custom Shortcuts") {
                                var newShortcutName by remember { mutableStateOf("") }
                                var newShortcutUrl by remember { mutableStateOf("") }
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    customShortcuts.forEach { shortcut ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(shortcut.first, color = Color.White, style = MaterialTheme.typography.bodySmall)
                                                Text(shortcut.second, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                            }
                                            IconButton(onClick = { 
                                                val newList = customShortcuts.filter { it != shortcut }
                                                customShortcuts = newList
                                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                                            }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Remove", tint = Color.Red)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            TextField(value = newShortcutName, onValueChange = { newShortcutName = it }, placeholder = { Text("Name", style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.fillMaxWidth().height(48.dp), textStyle = MaterialTheme.typography.labelSmall)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            TextField(value = newShortcutUrl, onValueChange = { newShortcutUrl = it }, placeholder = { Text("URL", style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.fillMaxWidth().height(48.dp), textStyle = MaterialTheme.typography.labelSmall)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        androidx.compose.material3.TextButton(onClick = {
                                            if (newShortcutName.isNotBlank() && newShortcutUrl.isNotBlank()) {
                                                val u = if (!newShortcutUrl.startsWith("http")) "https://$newShortcutUrl" else newShortcutUrl
                                                val newList = customShortcuts + Pair(newShortcutName, u)
                                                customShortcuts = newList
                                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                                                newShortcutName = ""
                                                newShortcutUrl = ""
                                            }
                                        }) {
                                            Text("Add", color = Color.Cyan)
                                        }
                                    }
                                }
                            }
                            
                            SettingsSection("Virtual Screen") {"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
