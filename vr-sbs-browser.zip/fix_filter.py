import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = 'val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" || loadedTabs.size == 1 }'
replacement = 'val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" }'

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
