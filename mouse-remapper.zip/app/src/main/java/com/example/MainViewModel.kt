package com.example

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ButtonMapping
import com.example.data.ButtonMappingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ButtonMappingRepository
    val mappings: StateFlow<List<ButtonMapping>>

    private val _isServiceEnabled = MutableStateFlow(false)
    val isServiceEnabled: StateFlow<Boolean> = _isServiceEnabled.asStateFlow()

    private val _onlyRemapMouse = MutableStateFlow(true)
    val onlyRemapMouse: StateFlow<Boolean> = _onlyRemapMouse.asStateFlow()

    private val sharedPrefs = application.getSharedPreferences("mouse_remapper_prefs", Context.MODE_PRIVATE)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ButtonMappingRepository(database.buttonMappingDao())
        
        mappings = repository.allMappings.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        _onlyRemapMouse.value = sharedPrefs.getBoolean("only_remap_mouse", true)
        checkServiceStatus()
    }

    fun checkServiceStatus() {
        _isServiceEnabled.value = isAccessibilityServiceEnabled(getApplication(), MouseRemapperService::class.java)
    }

    fun setOnlyRemapMouse(enabled: Boolean) {
        _onlyRemapMouse.value = enabled
        sharedPrefs.edit().putBoolean("only_remap_mouse", enabled).apply()
    }

    fun insertMapping(keyCode: Int, keyName: String, actionType: String, packageName: String? = null, appName: String? = null) {
        viewModelScope.launch {
            repository.insert(
                ButtonMapping(
                    keyCode = keyCode,
                    keyName = keyName,
                    actionType = actionType,
                    packageName = packageName,
                    appName = appName,
                    isEnabled = true
                )
            )
        }
    }

    fun updateMapping(mapping: ButtonMapping) {
        viewModelScope.launch {
            repository.update(mapping)
        }
    }

    fun deleteMapping(id: Int) {
        viewModelScope.launch {
            repository.delete(id)
        }
    }

    private fun isAccessibilityServiceEnabled(context: Context, serviceClass: Class<*>): Boolean {
        val expectedComponentName = ComponentName(context, serviceClass)
        val enabledServicesSetting = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServicesSetting)
        while (colonSplitter.hasNext()) {
            val componentNameString = colonSplitter.next()
            val enabledService = ComponentName.unflattenFromString(componentNameString)
            if (enabledService != null && enabledService == expectedComponentName) {
                return true
            }
        }
        return false
    }
}
