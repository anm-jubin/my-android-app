package com.example.data

import android.content.Context
import android.view.KeyEvent
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [ButtonMapping::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun buttonMappingDao(): ButtonMappingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mouse_remapper_database"
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        val database = INSTANCE ?: return
                        CoroutineScope(Dispatchers.IO).launch {
                            database.buttonMappingDao().insertMapping(
                                ButtonMapping(
                                    id = 1,
                                    keyCode = KeyEvent.KEYCODE_BACK,
                                    keyName = "Right Mouse Click",
                                    actionType = ButtonMapping.ACTION_FLOATING_MENU,
                                    isEnabled = true
                                )
                            )
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
