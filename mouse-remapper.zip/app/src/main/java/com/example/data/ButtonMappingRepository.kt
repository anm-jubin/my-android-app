package com.example.data

import kotlinx.coroutines.flow.Flow

class ButtonMappingRepository(private val dao: ButtonMappingDao) {
    val allMappings: Flow<List<ButtonMapping>> = dao.getAllMappings()

    suspend fun getMappingByKeyCode(keyCode: Int): ButtonMapping? {
        return dao.getMappingByKeyCode(keyCode)
    }

    suspend fun insert(mapping: ButtonMapping) {
        dao.insertMapping(mapping)
    }

    suspend fun update(mapping: ButtonMapping) {
        dao.updateMapping(mapping)
    }

    suspend fun delete(id: Int) {
        dao.deleteMapping(id)
    }
}
