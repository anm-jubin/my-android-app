package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ButtonMappingDao {
    @Query("SELECT * FROM button_mappings ORDER BY id ASC")
    fun getAllMappings(): Flow<List<ButtonMapping>>

    @Query("SELECT * FROM button_mappings WHERE keyCode = :keyCode AND isEnabled = 1 LIMIT 1")
    suspend fun getMappingByKeyCode(keyCode: Int): ButtonMapping?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMapping(mapping: ButtonMapping)

    @Update
    suspend fun updateMapping(mapping: ButtonMapping)

    @Query("DELETE FROM button_mappings WHERE id = :id")
    suspend fun deleteMapping(id: Int)
}
