package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "button_mappings")
data class ButtonMapping(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val keyCode: Int,
    val keyName: String,
    val actionType: String,
    val packageName: String? = null,
    val appName: String? = null,
    val isEnabled: Boolean = true
) {
    companion object {
        const val ACTION_FLOATING_MENU = "FLOATING_MENU"
        const val ACTION_BACK = "BACK"
        const val ACTION_HOME = "HOME"
        const val ACTION_RECENTS = "RECENTS"
        const val ACTION_NOTIFICATIONS = "NOTIFICATIONS"
        const val ACTION_QUICK_SETTINGS = "QUICK_SETTINGS"
        const val ACTION_POWER_DIALOG = "POWER_DIALOG"
        const val ACTION_SPLIT_SCREEN = "SPLIT_SCREEN"
        const val ACTION_LAUNCH_APP = "LAUNCH_APP"
    }
}
