package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Color Palette
val GeoBackground = Color(0xFFFDFBFF)
val GeoOnBackground = Color(0xFF1B1B1F)

val GeoPrimary = Color(0xFF005FB0)
val GeoOnPrimary = Color(0xFFFFFFFF)
val GeoPrimaryContainer = Color(0xFFD6E3FF)
val GeoOnPrimaryContainer = Color(0xFF001B3E)

val GeoSecondary = Color(0xFF565E71)
val GeoOnSecondary = Color(0xFFFFFFFF)
val GeoSecondaryContainer = Color(0xFFE2E2E6)
val GeoOnSecondaryContainer = Color(0xFF1B1B1F)

val GeoSurface = Color(0xFFFFFFFF)
val GeoOnSurface = Color(0xFF1B1B1F)
val GeoSurfaceVariant = Color(0xFFF2F0F4)
val GeoOnSurfaceVariant = Color(0xFF44474E)

val GeoOutline = Color(0xFFC4C6D0)
val GeoError = Color(0xFFBA1A1A)

// Dark version equivalents for Geometric Balance
val GeoDarkBackground = Color(0xFF1B1B1F)
val GeoDarkOnBackground = Color(0xFFE3E2E6)

val GeoDarkPrimary = Color(0xFFA6C8FF)
val GeoDarkOnPrimary = Color(0xFF003060)
val GeoDarkPrimaryContainer = Color(0xFF004786)
val GeoDarkOnPrimaryContainer = Color(0xFFD6E3FF)

val GeoDarkSecondary = Color(0xFFBEC6DC)
val GeoDarkOnSecondary = Color(0xFF283041)
val GeoDarkSecondaryContainer = Color(0xFF3E4759)
val GeoDarkOnSecondaryContainer = Color(0xFFDAE2F9)

val GeoDarkSurface = Color(0xFF131316)
val GeoDarkOnSurface = Color(0xFFC7C6CA)
val GeoDarkSurfaceVariant = Color(0xFF252528)
val GeoDarkOnSurfaceVariant = Color(0xFFC4C6D0)
