package com.example

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.data.AppDatabase
import com.example.data.ButtonMapping
import com.example.data.ButtonMappingRepository
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class MouseRemapperService : AccessibilityService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private var activeMappings = mapOf<Int, ButtonMapping>()
    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var overlayView: ComposeView? = null
    private val windowManager by lazy { getSystemService(Context.WINDOW_SERVICE) as WindowManager }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        
        // Start collecting mappings and cache them in memory for 0ms lookup latency
        val repository = ButtonMappingRepository(AppDatabase.getDatabase(this).buttonMappingDao())
        serviceScope.launch {
            repository.allMappings.collect { mappings ->
                activeMappings = mappings.filter { it.isEnabled }.associateBy { it.keyCode }
                android.util.Log.d("MouseRemapper", "Mappings cache updated: ${activeMappings.keys}")
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No-op - we only listen to key events
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val action = event.action

        val mapping = activeMappings[keyCode] ?: return false

        // Check if we should restrict to mouse inputs
        val sharedPrefs = getSharedPreferences("mouse_remapper_prefs", Context.MODE_PRIVATE)
        val onlyMouse = sharedPrefs.getBoolean("only_remap_mouse", true)

        if (onlyMouse) {
            val isMouse = (event.source and InputDevice.SOURCE_MOUSE) != 0 || 
                          (event.source and InputDevice.SOURCE_CLASS_POINTER) != 0
            if (!isMouse) {
                return false
            }
        }

        // Intercept and consume both DOWN and UP to prevent the default system actions from running.
        if (action == KeyEvent.ACTION_UP) {
            Handler(Looper.getMainLooper()).post {
                handleAction(mapping.actionType, mapping.packageName)
            }
        }
        return true
    }

    private fun handleAction(actionType: String, packageName: String?) {
        when (actionType) {
            ButtonMapping.ACTION_FLOATING_MENU -> {
                showOverlayMenu()
            }
            ButtonMapping.ACTION_BACK -> {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
            ButtonMapping.ACTION_HOME -> {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
            ButtonMapping.ACTION_RECENTS -> {
                performGlobalAction(GLOBAL_ACTION_RECENTS)
            }
            ButtonMapping.ACTION_NOTIFICATIONS -> {
                performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            }
            ButtonMapping.ACTION_QUICK_SETTINGS -> {
                performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            }
            ButtonMapping.ACTION_SPLIT_SCREEN -> {
                performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            }
            ButtonMapping.ACTION_POWER_DIALOG -> {
                performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            }
            ButtonMapping.ACTION_LAUNCH_APP -> {
                if (packageName != null) {
                    val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(launchIntent)
                    }
                }
            }
        }
    }

    private fun showOverlayMenu() {
        if (overlayView != null) return

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@MouseRemapperService)
            setViewTreeViewModelStoreOwner(this@MouseRemapperService)
            setViewTreeSavedStateRegistryOwner(this@MouseRemapperService)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or 
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or 
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        composeView.setContent {
            MyApplicationTheme {
                var isVisible by remember { mutableStateOf(false) }
                LaunchedEffect(Unit) {
                    isVisible = true
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            isVisible = false
                        },
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedVisibility(
                        visible = isVisible,
                        enter = fadeIn() + scaleIn(),
                        exit = fadeOut() + scaleOut()
                    ) {
                        FloatingMenuContent(
                            onAction = { action, pkg ->
                                isVisible = false
                                handleAction(action, pkg)
                            },
                            onDismiss = {
                                isVisible = false
                            }
                        )
                    }
                }

                LaunchedEffect(isVisible) {
                    if (!isVisible) {
                        kotlinx.coroutines.delay(180)
                        removeOverlayMenu()
                    }
                }
            }
        }

        try {
            windowManager.addView(composeView, params)
            overlayView = composeView
        } catch (e: Exception) {
            android.util.Log.e("MouseRemapper", "Failed to add overlay menu window", e)
        }
    }

    private fun removeOverlayMenu() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // Ignore
            }
            overlayView = null
        }
    }

    override fun onDestroy() {
        removeOverlayMenu()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        serviceScope.cancel()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloatingMenuContent(
    onAction: (String, String?) -> Unit,
    onDismiss: () -> Unit
) {
    val items = listOf(
        MenuActionItem("Back", ButtonMapping.ACTION_BACK, Icons.Default.ArrowBack, MaterialTheme.colorScheme.primary),
        MenuActionItem("Home", ButtonMapping.ACTION_HOME, Icons.Default.Home, MaterialTheme.colorScheme.secondary),
        MenuActionItem("Recents", ButtonMapping.ACTION_RECENTS, Icons.Default.Menu, MaterialTheme.colorScheme.tertiary),
        MenuActionItem("Notifications", ButtonMapping.ACTION_NOTIFICATIONS, Icons.Default.Notifications, MaterialTheme.colorScheme.error),
        MenuActionItem("Quick Settings", ButtonMapping.ACTION_QUICK_SETTINGS, Icons.Default.Settings, MaterialTheme.colorScheme.primary),
        MenuActionItem("Split Screen", ButtonMapping.ACTION_SPLIT_SCREEN, Icons.Default.Grid3x3, MaterialTheme.colorScheme.secondary),
        MenuActionItem("Power Dialog", ButtonMapping.ACTION_POWER_DIALOG, Icons.Default.PowerSettingsNew, MaterialTheme.colorScheme.error),
        MenuActionItem("Dismiss", "DISMISS", Icons.Default.Close, MaterialTheme.colorScheme.outline)
    )

    Card(
        modifier = Modifier
            .widthIn(max = 420.dp)
            .padding(24.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { /* Consume clicks to prevent dismissal */ },
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Quick Command Center",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.heightIn(max = 300.dp)
            ) {
                items(items) { item ->
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable {
                                if (item.actionType == "DISMISS") {
                                    onDismiss()
                                } else {
                                    onAction(item.actionType, null)
                                }
                            }
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            modifier = Modifier
                                .size(56.dp)
                                .padding(2.dp),
                            shape = CircleShape,
                            color = item.color.copy(alpha = 0.15f),
                            contentColor = item.color
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelSmall,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

data class MenuActionItem(
    val label: String,
    val actionType: String,
    val icon: ImageVector,
    val color: Color
)
