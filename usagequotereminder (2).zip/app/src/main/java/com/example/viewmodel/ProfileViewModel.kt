package com.example.viewmodel

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppInfo
import com.example.model.Profile
import com.example.service.QuoteMonitorService
import com.example.storage.StorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ProfileViewModel : ViewModel() {

    private val _profiles = MutableStateFlow<List<Profile>>(emptyList())
    val profiles: StateFlow<List<Profile>> = _profiles.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    // Active Profile during editing
    private val _activeProfile = MutableStateFlow<Profile?>(null)
    val activeProfile: StateFlow<Profile?> = _activeProfile.asStateFlow()

    // Quote Selection States for Bulk Actions (stores indices)
    private val _selectedQuoteIndices = MutableStateFlow<Set<Int>>(emptySet())
    val selectedQuoteIndices: StateFlow<Set<Int>> = _selectedQuoteIndices.asStateFlow()

    private val _isQuoteSelectionMode = MutableStateFlow(false)
    val isQuoteSelectionMode: StateFlow<Boolean> = _isQuoteSelectionMode.asStateFlow()

    fun loadProfiles(context: Context) {
        _profiles.value = StorageManager.getAllProfiles(context)
    }

    fun updateServiceStatus(context: Context) {
        _isServiceRunning.value = isServiceRunningInSystem(context)
    }

    @Suppress("DEPRECATION")
    private fun isServiceRunningInSystem(context: Context): Boolean {
        if (QuoteMonitorService.isServiceRunning) return true
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return false
        try {
            for (service in manager.getRunningServices(Int.MAX_VALUE)) {
                if (QuoteMonitorService::class.java.name == service.service.className) {
                    return true
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun startService(context: Context) {
        val intent = Intent(context, QuoteMonitorService::class.java).apply {
            action = QuoteMonitorService.ACTION_START
        }
        context.startForegroundService(intent)
        _isServiceRunning.value = true
        _profiles.value = StorageManager.getAllProfiles(context) // refresh UI state
    }

    fun stopService(context: Context) {
        val intent = Intent(context, QuoteMonitorService::class.java).apply {
            action = QuoteMonitorService.ACTION_STOP
        }
        context.stopService(intent)
        _isServiceRunning.value = false
    }

    fun toggleProfileEnabled(context: Context, profileId: String, isEnabled: Boolean) {
        val list = _profiles.value.map {
            if (it.id == profileId) {
                it.copy(isEnabled = isEnabled)
            } else {
                it
            }
        }
        StorageManager.saveAllProfiles(context, list)
        _profiles.value = list
        triggerServiceRefresh(context)
    }

    fun triggerServiceRefresh(context: Context) {
        if (isServiceRunningInSystem(context)) {
            val intent = Intent(context, QuoteMonitorService::class.java).apply {
                action = QuoteMonitorService.ACTION_REFRESH
            }
            context.startService(intent)
        }
    }

    // Active Profile Editing
    fun setActiveProfile(profile: Profile?) {
        _activeProfile.value = profile
        clearQuoteSelection()
    }

    fun saveActiveProfile(context: Context) {
        _activeProfile.value?.let { profile ->
            StorageManager.saveProfile(context, profile)
            loadProfiles(context)
            triggerServiceRefresh(context)
        }
    }

    fun deleteActiveProfile(context: Context) {
        _activeProfile.value?.let { profile ->
            StorageManager.deleteProfile(context, profile.id)
            loadProfiles(context)
            triggerServiceRefresh(context)
        }
        _activeProfile.value = null
    }

    fun createAndSetActiveProfile(name: String) : Profile {
        val newProfile = Profile(profileName = name)
        _activeProfile.value = newProfile
        clearQuoteSelection()
        return newProfile
    }

    fun updateActiveProfileDetails(
        name: String,
        initialDelay: Int,
        rangeStart: Int,
        rangeEnd: Int,
        cooldown: Int,
        isCooldownMode: Boolean
    ) {
        _activeProfile.value = _activeProfile.value?.copy(
            profileName = name,
            initialDelayMinutes = initialDelay,
            rangeStartMinutes = rangeStart,
            rangeEndMinutes = rangeEnd,
            cooldownMinutes = cooldown,
            nagMode = if (isCooldownMode) com.example.model.NagMode.COOLDOWN else com.example.model.NagMode.CONSTANT
        )
    }

    fun addAppToActiveProfile(packageName: String) {
        _activeProfile.value?.let { profile ->
            if (!profile.monitoredApps.contains(packageName)) {
                val updatedApps = ArrayList(profile.monitoredApps)
                updatedApps.add(packageName)
                _activeProfile.value = profile.copy(monitoredApps = updatedApps)
            }
        }
    }

    fun removeAppFromActiveProfile(packageName: String) {
        _activeProfile.value?.let { profile ->
            val updatedApps = ArrayList(profile.monitoredApps)
            updatedApps.remove(packageName)
            _activeProfile.value = profile.copy(monitoredApps = updatedApps)
        }
    }

    // Quotes Management
    fun addQuoteToActiveProfile(quote: String) {
        _activeProfile.value?.let { profile ->
            val updatedQuotes = ArrayList(profile.quotes)
            updatedQuotes.add(quote)
            _activeProfile.value = profile.copy(quotes = updatedQuotes)
        }
    }

    fun editQuoteInActiveProfile(index: Int, newQuote: String) {
        _activeProfile.value?.let { profile ->
            if (index in profile.quotes.indices) {
                val updatedQuotes = ArrayList(profile.quotes)
                updatedQuotes[index] = newQuote
                _activeProfile.value = profile.copy(quotes = updatedQuotes)
            }
        }
    }

    // Quotes Selection/CAB Management
    fun toggleQuoteSelection(index: Int) {
        val current = _selectedQuoteIndices.value.toMutableSet()
        if (current.contains(index)) {
            current.remove(index)
        } else {
            current.add(index)
        }
        _selectedQuoteIndices.value = current
        _isQuoteSelectionMode.value = current.isNotEmpty()
    }

    fun selectAllQuotes() {
        val currentProfile = _activeProfile.value ?: return
        val allIndices = currentProfile.quotes.indices.toSet()
        _selectedQuoteIndices.value = allIndices
        _isQuoteSelectionMode.value = allIndices.isNotEmpty()
    }

    fun clearQuoteSelection() {
        _selectedQuoteIndices.value = emptySet()
        _isQuoteSelectionMode.value = false
    }

    // Bulk actions
    fun bulkDeleteQuotes() {
        val currentProfile = _activeProfile.value ?: return
        val indicesToDelete = _selectedQuoteIndices.value
        if (indicesToDelete.isEmpty()) return

        val updatedQuotes = ArrayList<String>()
        for (i in currentProfile.quotes.indices) {
            if (!indicesToDelete.contains(i)) {
                updatedQuotes.add(currentProfile.quotes[i])
            }
        }
        _activeProfile.value = currentProfile.copy(quotes = updatedQuotes)
        clearQuoteSelection()
    }

    fun replaceQuotesInActiveProfile(newQuotes: List<String>) {
        val profile = _activeProfile.value ?: return
        _activeProfile.value = profile.copy(quotes = ArrayList(newQuotes))
    }

    fun bulkCopyQuotes(context: Context) {
        val currentProfile = _activeProfile.value ?: return
        val indicesToCopy = _selectedQuoteIndices.value
        if (indicesToCopy.isEmpty()) return

        val textToCopy = indicesToCopy.sorted()
            .map { currentProfile.quotes[it] }
            .joinToString(separator = "\n\n\n\n")

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Copied Quotes", textToCopy)
        clipboard.setPrimaryClip(clip)
        
        Toast.makeText(context, "${indicesToCopy.size} Quotes copied to clipboard", Toast.LENGTH_SHORT).show()
        clearQuoteSelection()
    }

    // App Loading on Background Thread
    fun loadInstalledApps(context: Context) {
        _isLoadingApps.value = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pm = context.packageManager
                val intent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val resolveInfos = pm.queryIntentActivities(intent, 0)
                val appsList = ArrayList<AppInfo>()
                for (ri in resolveInfos) {
                    val packageName = ri.activityInfo.packageName
                    val label = ri.loadLabel(pm).toString()
                    // Filter package names to avoid adding self (though we could if we wanted, let's keep all launchable apps)
                    if (packageName != context.packageName) {
                        appsList.add(AppInfo(label, packageName))
                    }
                }
                constrainAppsResult(appsList.sortedBy { it.label.uppercase() })
            } catch (e: Exception) {
                e.printStackTrace()
                constrainAppsResult(emptyList())
            }
        }
    }

    private suspend fun constrainAppsResult(result: List<AppInfo>) {
        withContext(Dispatchers.Main) {
            _installedApps.value = result
            _isLoadingApps.value = false
        }
    }
}
