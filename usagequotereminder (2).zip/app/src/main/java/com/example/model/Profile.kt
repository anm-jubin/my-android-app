package com.example.model

import java.io.Serializable
import java.util.UUID

enum class NagMode {
    CONSTANT,
    COOLDOWN
}

data class Profile(
    val id: String = UUID.randomUUID().toString(),
    var profileName: String = "",
    var monitoredApps: ArrayList<String> = ArrayList(),
    var quotes: ArrayList<String> = ArrayList(),
    var initialDelayMinutes: Int = 1, // Defaulting to 1 for easier testing/use
    var rangeStartMinutes: Int = 1,
    var rangeEndMinutes: Int = 3,
    var cooldownMinutes: Int = 2,
    var nagMode: NagMode = NagMode.CONSTANT,
    var isEnabled: Boolean = true
) : Serializable
