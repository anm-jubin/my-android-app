package com.example.model

data class AppInfo(
    val label: String,
    val packageName: String
)
