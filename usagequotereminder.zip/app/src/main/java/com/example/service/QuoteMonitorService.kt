package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.NagMode
import com.example.model.Profile
import com.example.storage.StorageManager
import java.util.Random

class QuoteMonitorService : Service() {

    companion object {
        const val ACTION_START = "com.example.service.START"
        const val ACTION_STOP = "com.example.service.STOP"
        const val ACTION_REFRESH = "com.example.service.REFRESH"

        private const val NOTIFICATION_ID_FOREGROUND = 1001
        private const val NOTIFICATION_ID_QUOTE = 1002

        private const val CHANNEL_ID_FOREGROUND = "quote_monitor_fg_channel_v2"
        private const val CHANNEL_ID_QUOTE = "quote_monitor_quote_channel_v2"

        private const val CHECK_INTERVAL = 3000L // 3 seconds
        
        var isServiceRunning = false
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private val random = Random()

    // State Maps
    private val appToProfileMap = HashMap<String, Profile>()
    private val appStartTimers = HashMap<String, Long>()
    private val appCooldownEndTimes = HashMap<String, Long>()
    private val appNotificationScheduled = HashMap<String, Boolean>()

    private val checkRunnable = object : Runnable {
        override fun run() {
            if (!isServiceRunning) return
            try {
                performAppCheck()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            handler.postDelayed(this, CHECK_INTERVAL)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_START -> {
                isServiceRunning = true
                refreshMappings()
                startStealthForeground()
                
                // Start the check loop
                handler.removeCallbacks(checkRunnable)
                handler.post(checkRunnable)
            }
            ACTION_REFRESH -> {
                refreshMappings()
            }
            ACTION_STOP -> {
                stopServiceInternal()
            }
        }

        return START_STICKY
    }

    private fun stopServiceInternal() {
        isServiceRunning = false
        handler.removeCallbacksAndMessages(null)
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        isServiceRunning = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun refreshMappings() {
        appToProfileMap.clear()
        val profiles = StorageManager.getAllProfiles(this)
        for (profile in profiles) {
            if (profile.isEnabled) {
                for (app in profile.monitoredApps) {
                    appToProfileMap[app] = profile
                }
            }
        }
    }

    private fun startStealthForeground() {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID_FOREGROUND)
            .setContentTitle("")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_notification_clear_all) // Minimalist/stealth icon
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setSilent(true)

        val notification = builder.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
            try {
                startForeground(NOTIFICATION_ID_FOREGROUND, notification, type)
            } catch (e: Exception) {
                // Fallback if specialUse is restricted or fails
                startForeground(NOTIFICATION_ID_FOREGROUND, notification)
            }
        } else {
            startForeground(NOTIFICATION_ID_FOREGROUND, notification)
        }
    }

    private val appLastSeenActive = HashMap<String, Long>()

    private fun performAppCheck() {
        val currentApp = getForegroundApp()
        val nowForCheck = System.currentTimeMillis()
        
        if (currentApp != null) {
            appLastSeenActive[currentApp] = nowForCheck
        }
        if (currentApp != null && appToProfileMap.containsKey(currentApp)) {
            val profile = appToProfileMap[currentApp]!!
            
            // Check cooldown
            val cooldownEnd = appCooldownEndTimes[currentApp] ?: 0L
            val now = System.currentTimeMillis()
            
            if (now >= cooldownEnd) {
                // Store/retrieve the app's open time
                if (!appStartTimers.containsKey(currentApp)) {
                    appStartTimers[currentApp] = now
                }
                
                val firstOpenTime = appStartTimers[currentApp]!!
                val timeOpenMs = now - firstOpenTime
                val initialDelayMs = profile.initialDelayMinutes * 60L * 1000L
                
                val isScheduled = appNotificationScheduled[currentApp] ?: false
                
                if (timeOpenMs >= initialDelayMs && !isScheduled) {
                    // Calculate random delay
                    val min = profile.rangeStartMinutes
                    val max = profile.rangeEndMinutes
                    
                    val randomMin = if (max > min) {
                        min + random.nextInt(max - min + 1)
                    } else {
                        min
                    }
                    val randomDelayMs = randomMin * 60L * 1000L
                    
                    appNotificationScheduled[currentApp] = true
                    
                    val capturedApp = currentApp // Thread-safety / logical closure capture
                    
                    handler.postDelayed({
                        // Only fire if user is still in the app (cleanup step hasn't removed it)
                        if (appStartTimers.containsKey(capturedApp)) {
                            fireQuoteNotification(profile)
                            
                            // Check profile nagMode
                            val updatedNow = System.currentTimeMillis()
                            if (profile.nagMode == NagMode.CONSTANT) {
                                // Reset scheduled to allow next delayed run
                                appNotificationScheduled[capturedApp] = false
                            } else {
                                // Cooldown mode
                                val cooldownEndMs = updatedNow + (profile.cooldownMinutes * 60L * 1000L)
                                appCooldownEndTimes[capturedApp] = cooldownEndMs
                                appNotificationScheduled[capturedApp] = false
                            }
                        } else {
                            // User left the app during the delay
                            appNotificationScheduled.remove(capturedApp)
                        }
                    }, randomDelayMs)
                }
            }
        }

        // Cleanup Step (Every 3 seconds):
        // Only remove if an app hasn't been seen for 10 seconds (avoids drops on brief UI pauses)
        val appsInTimer = appStartTimers.keys.toList()
        for (app in appsInTimer) {
            val lastSeen = appLastSeenActive[app] ?: 0L
            if (nowForCheck - lastSeen > 10000L) {
                appStartTimers.remove(app)
                appNotificationScheduled.remove(app)
                appCooldownEndTimes.remove(app)
                appLastSeenActive.remove(app)
            }
        }
    }

    private fun fireQuoteNotification(profile: Profile) {
        if (profile.quotes.isEmpty()) return
        
        // Pick a random quote
        val randomQuote = profile.quotes[random.nextInt(profile.quotes.size)]
        
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        val builder = NotificationCompat.Builder(this, CHANNEL_ID_QUOTE)
            .setContentTitle("")
            .setContentText(randomQuote)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setStyle(NotificationCompat.BigTextStyle().bigText(randomQuote))
            .setAutoCancel(true)

        notificationManager.notify(NOTIFICATION_ID_QUOTE, builder.build())
        
        // Handle custom/random sound
        try {
            val uriToPlay: Uri? = if (profile.randomizeSound) {
                // Pick a random notification sound
                val rm = android.media.RingtoneManager(this)
                rm.setType(android.media.RingtoneManager.TYPE_NOTIFICATION)
                val cursor = rm.cursor
                if (cursor != null && cursor.count > 0) {
                    val idx = random.nextInt(cursor.count)
                    rm.getRingtoneUri(idx)
                } else null
            } else if (profile.soundUri != null) {
                Uri.parse(profile.soundUri)
            } else {
                android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
            }
            
            if (uriToPlay != null) {
                val player = MediaPlayer.create(this, uriToPlay)
                player?.setOnCompletionListener { it.release() }
                player?.start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // Handle custom/random vibration
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator != null && vibrator.hasVibrator()) {
                var vType = profile.vibrationType
                if (profile.randomizeVibration || vType == 3) {
                    vType = random.nextInt(3) // 0, 1, or 2
                }
                
                val pattern = when (vType) {
                    0 -> longArrayOf(0, 300) // Single
                    1 -> longArrayOf(0, 150, 150, 150) // Double
                    2 -> longArrayOf(0, 500, 200, 500) // Heavy
                    else -> longArrayOf(0, 300)
                }
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private var lastForegroundApp: String? = null
    private var lastCheckedTime: Long = System.currentTimeMillis() - 1000 * 60 // initially query last 1 min

    private fun getForegroundApp(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return lastForegroundApp
        val endTime = System.currentTimeMillis()
        val startTime = lastCheckedTime
        
        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        val event = android.app.usage.UsageEvents.Event()
        
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                 lastForegroundApp = event.packageName
            } else if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_PAUSED) {
                 if (lastForegroundApp == event.packageName) {
                     lastForegroundApp = null
                 }
            }
        }
        
        lastCheckedTime = endTime
        return lastForegroundApp
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            
            // Channel for foreground service (low priority)
            val fgChannel = NotificationChannel(
                CHANNEL_ID_FOREGROUND,
                "Stealth Monitor Service",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Keeps the quote monitoring service running in background"
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(fgChannel)
            
            // Channel for quote notifications (high priority)
            val qChannel = NotificationChannel(
                CHANNEL_ID_QUOTE,
                "Disruptive Digital Well-Being Quotes",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Shows high-priority quotes when addictive apps are open too long"
                enableVibration(false)
                setSound(null, null)
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(qChannel)
        }
    }
}
