package com.example.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.model.Profile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object StorageManager {
    private const val PREF_NAME = "UsageQuoteReminderPrefs"
    private const val KEY_PROFILES = "profiles"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun getAllProfiles(context: Context): List<Profile> {
        val prefs = getPrefs(context)
        val json = prefs.getString(KEY_PROFILES, null) ?: return getDefaultProfiles()
        return try {
            val type = object : TypeToken<List<Profile>>() {}.type
            Gson().fromJson(json, type) ?: getDefaultProfiles()
        } catch (e: Exception) {
            getDefaultProfiles()
        }
    }

    fun saveAllProfiles(context: Context, profiles: List<Profile>) {
        val prefs = getPrefs(context)
        val json = Gson().toJson(profiles)
        prefs.edit().putString(KEY_PROFILES, json).apply()
    }

    fun saveProfile(context: Context, profile: Profile) {
        val profiles = getAllProfiles(context).toMutableList()
        val index = profiles.indexOfFirst { it.id == profile.id }
        if (index != -1) {
            profiles[index] = profile
        } else {
            profiles.add(profile)
        }
        saveAllProfiles(context, profiles)
    }

    fun deleteProfile(context: Context, profileId: String) {
        val profiles = getAllProfiles(context).toMutableList()
        profiles.removeAll { it.id == profileId }
        saveAllProfiles(context, profiles)
    }

    private fun getDefaultProfiles(): List<Profile> {
        return listOf(
            Profile(
                profileName = "Social Detox",
                monitoredApps = arrayListOf("com.instagram.android", "com.twitter.android", "com.facebook.katana", "com.zhiliaoapp.musically"),
                quotes = arrayListOf(
                    "Is scrolling more important than your actual life?",
                    "Another minute spent here is a minute stolen from your future.",
                    "They are monetizing your attention. Get out of here.",
                    "Look around you. This screen is not real life.",
                    "Are you really finding value here, or is this just muscle memory?",
                    "Put the phone down and go read a book or talk to a human.",
                    "The dopamine hit is temporary. The regret of lost time is permanent."
                ),
                initialDelayMinutes = 1,
                rangeStartMinutes = 1,
                rangeEndMinutes = 3,
                cooldownMinutes = 2,
                isEnabled = true
            ),
            Profile(
                profileName = "Productivity Preservation",
                monitoredApps = arrayListOf("com.android.chrome", "com.google.android.youtube"),
                quotes = arrayListOf(
                    "Stop procrastinating. Back to work!",
                    "You opened this app for 'one quick thing'. Remember?",
                    "Distraction is the enemy of greatness.",
                    "Are you running away from difficult work of value right now?"
                ),
                initialDelayMinutes = 1,
                rangeStartMinutes = 1,
                rangeEndMinutes = 4,
                cooldownMinutes = 5,
                isEnabled = false
            )
        )
    }
}
