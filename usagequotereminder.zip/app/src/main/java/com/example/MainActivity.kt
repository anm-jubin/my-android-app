package com.example

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.screens.MainScreen
import com.example.ui.screens.ProfileDetailScreen
import com.example.ui.screens.AddAppScreen
import com.example.ui.screens.AddDisguiseAppScreen
import com.example.viewmodel.ProfileViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ProfileViewModel by viewModels()
    private var hasUsagePermission by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Sync initial app loading
        viewModel.loadProfiles(this)
        requestNotificationPermission()

        setContent {
            MyApplicationTheme {
                val navController = rememberNavController()

                // Register standard app permissions check state in composition
                LaunchedEffect(Unit) {
                    hasUsagePermission = checkUsageStatsPermission(this@MainActivity)
                }

                NavHost(
                    navController = navController,
                    startDestination = "main",
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable("main") {
                        MainScreen(
                            viewModel = viewModel,
                            onNavigateToDetail = { navController.navigate("profile_detail") },
                            onNavigateToSettings = { navigateToUsageSettings() },
                            hasUsagePermission = hasUsagePermission
                        )
                    }

                    composable("profile_detail") {
                        ProfileDetailScreen(
                            viewModel = viewModel,
                            onNavigateToAddApp = { navController.navigate("add_app") },
                            onNavigateToAddDisguiseApp = { navController.navigate("add_disguise_app") },
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable("add_app") {
                        AddAppScreen(
                            viewModel = viewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable("add_disguise_app") {
                        AddDisguiseAppScreen(
                            viewModel = viewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.updateServiceStatus(this)
        hasUsagePermission = checkUsageStatsPermission(this)
        viewModel.loadProfiles(this)
    }

    private fun checkUsageStatsPermission(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun navigateToUsageSettings() {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                // Try direct focus on self package if supported (otherwise defaults to list)
                data = android.net.Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            this.requestPermissions(
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                1001
            )
        }
    }
}
