package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = GeoTertiary,
    secondary = GeoSecondary,
    tertiary = Purple80,
    background = Color(0xFF141214),
    surface = Color(0xFF1D1B1E),
    onBackground = Color(0xFFE6E1E5),
    onSurface = Color(0xFFE6E1E5),
    surfaceVariant = Color(0xFF49454F),
    outline = Color(0xFF938F99),
    onPrimary = Color(0xFF381E72)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = GeoPrimary,
    secondary = GeoSecondary,
    tertiary = GeoTertiary,
    background = GeoBackground,
    surface = GeoSurface,
    onPrimary = GeoOnPrimary,
    onSecondary = GeoPrimary,
    onTertiary = GeoPrimary,
    onBackground = GeoOnBackground,
    onSurface = GeoOnSurface,
    surfaceVariant = GeoSurfaceVariant,
    outline = GeoOutline
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Set to false by default to ensure Geometric Balance styling prevails
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
