package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6750A4)
val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)

// Geometric Balance Tones
val GeoPrimary = Color(0xFF6750A4)
val GeoSecondary = Color(0xFFE8DEF8)
val GeoTertiary = Color(0xFFD0BCFF)
val GeoBackground = Color(0xFFFDF8F6)
val GeoSurface = Color(0xFFFFFFFF)
val GeoOnBackground = Color(0xFF1D1B1E)
val GeoOnSurface = Color(0xFF1D1B1E)
val GeoSurfaceVariant = Color(0xFFF4EFF4)
val GeoOutline = Color(0xFFCAC4D0)
val GeoOnPrimary = Color(0xFFFFFFFF)
