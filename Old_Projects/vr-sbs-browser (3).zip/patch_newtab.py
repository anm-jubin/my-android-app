import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Update VRBrowserScreen to hold the shortcuts state and pass to NewTabPage
target1 = """    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }"""
replace1 = """    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }
    
    var customShortcuts by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(
            (prefs.getString("customShortcuts", "YouTube|https://m.youtube.com,Google|https://www.google.com,Reddit|https://www.reddit.com,Wikipedia|https://www.wikipedia.org") ?: "").split(",").mapNotNull {
                val parts = it.split("|")
                if (parts.size >= 2) Pair(parts[0], parts[1]) else null
            }
        )
    }"""
content = content.replace(target1, replace1)

# 2. Update NewTabPage call
target2 = """                        NewTabPage(
                            isPassthroughEnabled = cameraPassthroughEnabled,
                            onSearch = { query ->
                                val finalUrl = processInput(query)
                                currentUrl = finalUrl
                                urlInput = finalUrl
                                browserManager.loadUrlInActiveTab(finalUrl)
                                localVideoUri = null
                                isUiVisible = false
                            }
                        )"""
replace2 = """                        NewTabPage(
                            isPassthroughEnabled = cameraPassthroughEnabled,
                            shortcuts = customShortcuts,
                            onSearch = { query ->
                                val finalUrl = processInput(query)
                                currentUrl = finalUrl
                                urlInput = finalUrl
                                browserManager.loadUrlInActiveTab(finalUrl)
                                localVideoUri = null
                                isUiVisible = false
                            },
                            onAddShortcut = { name, url ->
                                val newList = customShortcuts + Pair(name, url)
                                customShortcuts = newList
                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                            },
                            onRemoveShortcut = { shortcut ->
                                val newList = customShortcuts.filter { it != shortcut }
                                customShortcuts = newList
                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                            }
                        )"""
content = content.replace(target2, replace2)

# 3. Update NewTabPage signature and content
target3 = """@Composable
fun NewTabPage(
    isPassthroughEnabled: Boolean,
    onSearch: (String) -> Unit
) {"""
replace3 = """@Composable
fun NewTabPage(
    isPassthroughEnabled: Boolean,
    shortcuts: List<Pair<String, String>>,
    onSearch: (String) -> Unit,
    onAddShortcut: (String, String) -> Unit,
    onRemoveShortcut: (Pair<String, String>) -> Unit
) {"""
content = content.replace(target3, replace3)

# 4. Replace hardcoded shortcuts with LazyRow and Dialog
target4 = """            // Shortcuts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ShortcutIcon("YouTube", Icons.Default.PlayArrow, Color.Red) { onSearch("https://m.youtube.com") }
                ShortcutIcon("Google", Icons.Default.Search, Color.Blue) { onSearch("https://www.google.com") }
                ShortcutIcon("Reddit", Icons.Default.Menu, Color(0xFFFF4500)) { onSearch("https://www.reddit.com") }
                ShortcutIcon("Wikipedia", Icons.Default.Info, Color.Gray) { onSearch("https://www.wikipedia.org") }
            }"""
replace4 = """            // Shortcuts
            var showAddDialog by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    androidx.compose.foundation.layout.Box(modifier = Modifier.pointerInput(Unit) {
                        detectDragGestures(
                            onDragEnd = { onRemoveShortcut(shortcut) }
                        ) { change, _ -> change.consume() }
                    }) {
                        ShortcutIcon(shortcut.first, Icons.Default.Public, Color.Blue) { onSearch(shortcut.second) }
                        IconButton(
                            onClick = { onRemoveShortcut(shortcut) },
                            modifier = Modifier.align(Alignment.TopEnd).size(24.dp).background(Color.Red, androidx.compose.foundation.shape.CircleShape)
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
                item {
                    ShortcutIcon("Add", Icons.Default.Add, Color.Gray) { showAddDialog = true }
                }
            }

            if (showAddDialog) {
                var newName by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
                var newUrl by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
                AlertDialog(
                    onDismissRequest = { showAddDialog = false },
                    title = { Text("Add Shortcut") },
                    text = {
                        Column {
                            TextField(value = newName, onValueChange = { newName = it }, label = { Text("Name") }, singleLine = true)
                            Spacer(modifier = Modifier.height(8.dp))
                            TextField(value = newUrl, onValueChange = { newUrl = it }, label = { Text("URL") }, singleLine = true)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            if (newName.isNotBlank() && newUrl.isNotBlank()) {
                                val u = if (!newUrl.startsWith("http")) "https://$newUrl" else newUrl
                                onAddShortcut(newName, u)
                            }
                            showAddDialog = false
                        }) { Text("Add") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
                    }
                )
            }"""
content = content.replace(target4, replace4)

# Import fix
target5 = """import androidx.compose.material.icons.filled.Add"""
replace5 = """import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Public"""
if "import androidx.compose.material.icons.filled.Public" not in content:
    content = content.replace(target5, replace5, 1)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
