import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                        val css = \"\"\"
                            var style = document.createElement('style');
                            style.innerHTML = 'video { object-fit: contain !important; width: 100vw !important; height: 100vh !important; } main, body { overflow-x: hidden !important; }';
                            document.head.appendChild(style);
                        \"\"\".trimIndent()"""

replace = """                        val css = \"\"\"
                            var style = document.createElement('style');
                            style.innerHTML = 'video { object-fit: contain !important; max-width: 100% !important; max-height: 100% !important; } main, body { max-width: 100vw !important; overflow-x: hidden !important; }';
                            document.head.appendChild(style);
                        \"\"\".trimIndent()"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
