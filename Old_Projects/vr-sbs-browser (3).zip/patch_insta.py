import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }"""

replace = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        val css = \"\"\"
                            var style = document.createElement('style');
                            style.innerHTML = 'video { object-fit: contain !important; width: 100vw !important; height: 100vh !important; } main, body { overflow-x: hidden !important; }';
                            document.head.appendChild(style);
                        \"\"\".trimIndent()
                        view.evaluateJavascript(css, null)
                    }"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
