import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Force Mobile UA for Instagram and TikTok
target1 = """                userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)"""
replace1 = """                val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
                val wantsDesktop = isDesktopMode && !isMobileFriendly
                userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)"""
content = content.replace(target1, replace1)

# 2. Force UA update on navigation
target2 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.loadUrl(url)
    }"""
replace2 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.let { view ->
            val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
            val wantsDesktop = this.isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                view.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(view.context)
            }
            view.loadUrl(url)
        }
    }"""
content = content.replace(target2, replace2)

# 3. Update shouldOverrideUrlLoading to change UA for SPA internal links
target3 = """                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    return false
                }"""
replace3 = """                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    view?.let {
                        val isMobileFriendly = newUrl.contains("instagram.com") || newUrl.contains("tiktok.com")
                        val wantsDesktop = this@BrowserManager.isDesktopMode && !isMobileFriendly
                        val isCurrentlyDesktop = it.settings.userAgentString.contains("Windows NT")
                        if (wantsDesktop != isCurrentlyDesktop) {
                            it.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            it.loadUrl(newUrl)
                            return true
                        }
                    }
                    return false
                }"""
content = content.replace(target3, replace3)

# 4. Remove the CSS injection completely
target4 = """                    if (url?.contains("instagram.com") == true || url?.contains("tiktok.com") == true) {
                        val js = \"\"\"
                            var instaFixInterval = setInterval(function() {
                                if (document.head) {
                                    clearInterval(instaFixInterval);
                                    if (!document.getElementById('vr-insta-fix')) {
                                        var style = document.createElement('style');
                                        style.id = 'vr-insta-fix';
                                        style.innerHTML = 'html, body { overflow-x: hidden !important; } video { object-fit: contain !important; width: 100% !important; height: 100% !important; max-width: 100% !important; max-height: 100% !important; left: 0 !important; top: 0 !important; transform: none !important; margin: auto !important; }';
                                        document.head.appendChild(style);
                                    }
                                }
                            }, 50);
                        \"\"\".trimIndent()
                        view.evaluateJavascript(js, null)
                    }"""
replace4 = """"""
content = content.replace(target4, replace4)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
