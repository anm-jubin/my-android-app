import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val wantsDesktop = isDesktopMode"""
replace = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val isMobileFriendly = view.url?.contains("instagram.com") == true || view.url?.contains("tiktok.com") == true
            val wantsDesktop = isDesktopMode && !isMobileFriendly"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
