import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }"""

replace = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        val js = \"\"\"
                            var meta = document.querySelector('meta[name="viewport"]');
                            if (meta) {
                                meta.content = 'width=500, user-scalable=no';
                            } else {
                                meta = document.createElement('meta');
                                meta.name = 'viewport';
                                meta.content = 'width=500, user-scalable=no';
                                document.head.appendChild(meta);
                            }
                            var style = document.createElement('style');
                            style.innerHTML = 'html, body { width: 100% !important; overflow-x: hidden !important; } #react-root, main, #mount_0_0 { margin: 0 auto !important; display: flex !important; justify-content: center !important; flex-direction: column !important; align-items: center !important; }';
                            document.head.appendChild(style);
                        \"\"\".trimIndent()
                        view.evaluateJavascript(js, null)
                    }"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
