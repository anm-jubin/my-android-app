import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Revert addTab userAgentString logic
target1 = """                val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
                val wantsDesktop = isDesktopMode && !isMobileFriendly
                userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)"""
replace1 = """                userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)"""
content = content.replace(target1, replace1)

# 2. Revert loadUrlInActiveTab
target2 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.let { view ->
            val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
            val wantsDesktop = this.isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                view.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(view.context)
            }
            view.loadUrl(url)
        }
    }"""
replace2 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.loadUrl(url)
    }"""
content = content.replace(target2, replace2)

# 3. Revert shouldOverrideUrlLoading logic
target3 = """                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    view?.let {
                        val isMobileFriendly = newUrl.contains("instagram.com") || newUrl.contains("tiktok.com")
                        val wantsDesktop = this@BrowserManager.isDesktopMode && !isMobileFriendly
                        val isCurrentlyDesktop = it.settings.userAgentString.contains("Windows NT")
                        if (wantsDesktop != isCurrentlyDesktop) {
                            it.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            it.loadUrl(newUrl)
                            return true
                        }
                    }
                    return false
                }"""
replace3 = """                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    return false
                }"""
content = content.replace(target3, replace3)

# 4. Revert updateDesktopMode logic
target4 = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val isMobileFriendly = view.url?.contains("instagram.com") == true || view.url?.contains("tiktok.com") == true
            val wantsDesktop = isDesktopMode && !isMobileFriendly"""
replace4 = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val wantsDesktop = isDesktopMode"""
content = content.replace(target4, replace4)

# 5. Remove onPageFinished CSS injection, move it to onPageStarted with setInterval
target5 = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        val css = \"\"\"
                            var style = document.createElement('style');
                            style.innerHTML = 'video { object-fit: contain !important; max-width: 100% !important; max-height: 100% !important; } main, body { max-width: 100vw !important; overflow-x: hidden !important; }';
                            document.head.appendChild(style);
                        \"\"\".trimIndent()
                        view.evaluateJavascript(css, null)
                    }
                    if (id == activeTabId) {"""
replace5 = """                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    if (url?.contains("instagram.com") == true || url?.contains("tiktok.com") == true) {
                        val js = \"\"\"
                            var instaFixInterval = setInterval(function() {
                                if (document.head) {
                                    clearInterval(instaFixInterval);
                                    if (!document.getElementById('vr-insta-fix')) {
                                        var style = document.createElement('style');
                                        style.id = 'vr-insta-fix';
                                        style.innerHTML = 'html, body { overflow-x: hidden !important; width: 100vw !important; } video { object-fit: contain !important; max-width: 100% !important; max-height: 100% !important; }';
                                        document.head.appendChild(style);
                                    }
                                }
                            }, 50);
                        \"\"\".trimIndent()
                        view.evaluateJavascript(js, null)
                    }
                }
                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    if (id == activeTabId) {"""
content = content.replace(target5, replace5)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
