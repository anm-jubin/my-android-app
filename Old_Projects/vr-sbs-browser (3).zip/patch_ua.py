import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Add isDesktopMode to BrowserManager
target1 = """    var isIncognito: Boolean = false"""
replace1 = """    var isIncognito: Boolean = false
    var isDesktopMode: Boolean = true"""
content = content.replace(target1, replace1)

# Update addTab to use the dynamic logic
target2 = """                userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)
            }"""
replace2 = """                val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
                val wantsDesktop = isDesktopMode && !isMobileFriendly
                userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)
            }"""
content = content.replace(target2, replace2)

# Update loadUrlInActiveTab to handle User Agent change on navigation
target3 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.loadUrl(url)
    }"""
replace3 = """    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.let { view ->
            val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
            val wantsDesktop = this.isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                view.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(view.context)
            }
            view.loadUrl(url)
        }
    }"""
content = content.replace(target3, replace3)

# Add shouldOverrideUrlLoading to addTab's WebViewClient to catch internal link clicks
target4 = """            webViewClient = object : WebViewClient() {
                override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {"""
replace4 = """            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    view?.let {
                        val isMobileFriendly = newUrl.contains("instagram.com") || newUrl.contains("tiktok.com")
                        val wantsDesktop = this@BrowserManager.isDesktopMode && !isMobileFriendly
                        val isCurrentlyDesktop = it.settings.userAgentString.contains("Windows NT")
                        if (wantsDesktop != isCurrentlyDesktop) {
                            it.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            it.loadUrl(newUrl)
                            return true
                        }
                    }
                    return false
                }
                override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {"""
content = content.replace(target4, replace4)

# Update updateDesktopMode
target5 = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        webViews.values.forEach { view ->
            val wantsDesktop = isDesktopMode"""
replace5 = """    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val isMobileFriendly = view.url?.contains("instagram.com") == true || view.url?.contains("tiktok.com") == true
            val wantsDesktop = isDesktopMode && !isMobileFriendly"""
content = content.replace(target5, replace5)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
