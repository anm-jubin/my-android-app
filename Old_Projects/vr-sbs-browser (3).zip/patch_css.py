import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                                        var style = document.createElement('style');
                                        style.id = 'vr-insta-fix';
                                        style.innerHTML = 'html, body { overflow-x: hidden !important; width: 100vw !important; } video { object-fit: contain !important; max-width: 100% !important; max-height: 100% !important; }';
                                        document.head.appendChild(style);"""

replace = """                                        var style = document.createElement('style');
                                        style.id = 'vr-insta-fix';
                                        style.innerHTML = 'html, body { overflow-x: hidden !important; } video { object-fit: contain !important; width: 100% !important; height: 100% !important; max-width: 100% !important; max-height: 100% !important; left: 0 !important; top: 0 !important; transform: none !important; margin: auto !important; }';
                                        document.head.appendChild(style);"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
