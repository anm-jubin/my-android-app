import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                // prevent consecutive duplicates
                if (historyList.isEmpty() || historyList.first().second != newUrl) {
                    historyList = listOf(Pair(title, newUrl)) + historyList
                    if (historyList.size > 100) {
                        historyList = historyList.take(100)
                    }
                }"""

replace = """                // prevent consecutive duplicates
                val cleanUrl = newUrl.trimEnd('/')
                val prevCleanUrl = historyList.firstOrNull()?.second?.trimEnd('/')
                if (cleanUrl != prevCleanUrl) {
                    historyList = listOf(Pair(title, newUrl)) + historyList
                    if (historyList.size > 100) {
                        historyList = historyList.take(100)
                    }
                } else if (historyList.isNotEmpty() && historyList.first().first != title && title != "Site") {
                    val mutableList = historyList.toMutableList()
                    mutableList[0] = Pair(title, historyList.first().second)
                    historyList = mutableList
                }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
