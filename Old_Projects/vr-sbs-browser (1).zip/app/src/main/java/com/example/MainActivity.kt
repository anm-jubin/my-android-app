package com.example

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    VRBrowserScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    var urlInput by remember { mutableStateOf("https://m.youtube.com") }
    var currentUrl by remember { mutableStateOf("https://m.youtube.com") }
    var isUiVisible by remember { mutableStateOf(true) }
    var scale by remember { mutableFloatStateOf(1f) }
    var ipd by remember { mutableFloatStateOf(0f) }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {
        val eyeWidth = maxWidth / 2

        // The single WebView container, drawn twice using Compose rendering!
        // This completely eliminates sync lag, cuts network usage in half, 
        // and guarantees exact millisecond frame rendering.
        Box(
            modifier = Modifier
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    val halfWidth = size.width / 2f
                    val halfHeight = size.height / 2f

                    // 1. Draw Left Eye
                    drawContext.canvas.save()
                    drawContext.canvas.translate(-ipd, 0f)
                    drawContext.canvas.translate(halfWidth, halfHeight)
                    drawContext.canvas.scale(scale, scale)
                    drawContext.canvas.translate(-halfWidth, -halfHeight)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Right Eye (Shifted by 1 full eyeWidth)
                    drawContext.canvas.save()
                    drawContext.canvas.translate(size.width + ipd, 0f)
                    drawContext.canvas.translate(halfWidth, halfHeight)
                    drawContext.canvas.scale(scale, scale)
                    drawContext.canvas.translate(-halfWidth, -halfHeight)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            SingleBrowser(
                url = currentUrl,
                onLoadUrl = { 
                    currentUrl = it
                    isUiVisible = false
                }
            )
        }

        // Floating Action Button to toggle UI
        FloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black)
        }

        if (isUiVisible) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                // Address Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Controls
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = scale,
                            onValueChange = { scale = it },
                            valueRange = 0.5f..1.5f
                        )
                        Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        Slider(
                            value = ipd,
                            onValueChange = { ipd = it },
                            valueRange = -150f..150f
                        )
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingleBrowser(
    url: String,
    onLoadUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        request?.url?.toString()?.let { newUrl ->
                            onLoadUrl(newUrl)
                        }
                        return false
                    }
                }
                loadUrl(url)
            }
        },
        update = { view ->
            if (view.url != url && url.isNotEmpty()) {
                view.loadUrl(url)
            }
        },
        modifier = modifier.fillMaxSize()
    )
}

