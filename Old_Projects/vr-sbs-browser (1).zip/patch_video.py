import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                override fun onHideCustomView() {
                    if (customView == null) return
                    container.removeView(customView)
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    this@apply.visibility = android.view.View.VISIBLE
                }"""

replace = """                override fun onHideCustomView() {
                    if (customView == null) return
                    container.removeView(customView)
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    this@apply.visibility = android.view.View.VISIBLE
                }
                
                override fun getDefaultVideoPoster(): android.graphics.Bitmap? {
                    return android.graphics.Bitmap.createBitmap(1, 1, android.graphics.Bitmap.Config.ARGB_8888)
                }"""
content = content.replace(target, replace)

target2 = """    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {"""

replace2 = """    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)"""

content = content.replace(target2, replace2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
