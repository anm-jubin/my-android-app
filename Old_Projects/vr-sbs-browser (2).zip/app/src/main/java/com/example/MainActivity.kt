package com.example

import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asComposeRenderEffect
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.annotation.SuppressLint
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Done

import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert

import androidx.compose.material.icons.filled.Add

import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import android.media.MediaPlayer
import android.view.TextureView
import android.view.Surface
import android.graphics.SurfaceTexture
import android.content.Context
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    VRBrowserScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = androidx.compose.runtime.remember { context.getSharedPreferences("vr_prefs", android.content.Context.MODE_PRIVATE) }
    
    val savedTabsStr = prefs.getString("savedTabs", "") ?: ""
    var bookmarks by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf<List<Pair<String, String>>>((prefs.getString("bookmarks", "") ?: "").split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) Pair(parts[0], parts[1]) else null
        }) 
    }
    var tabs by androidx.compose.runtime.remember { 
        val loadedTabs = savedTabsStr.split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) WebTab(parts[0], parts[1]) else null
        }
        val newId = java.util.UUID.randomUUID().toString().take(4)
        val freshTab = WebTab(newId, "https://m.youtube.com")
        // Check if there's already an empty default tab from previous session, to avoid infinite empty tabs
        val filteredLoaded = loadedTabs.filter { it.url != "https://m.youtube.com" }.take(2)
        androidx.compose.runtime.mutableStateOf(listOf(freshTab) + filteredLoaded)
    }
    var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.first().id) }

    var urlInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.firstOrNull { it.id == activeTabId }?.url ?: "https://m.youtube.com") }
    var currentUrl by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(urlInput) }
    var isUiVisible by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
    var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
        
    var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isDesktopMode", true)) }
    var isRightHandMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isRightHandMode", true)) }
    var scale by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("scale", 1f)) }
    var ipd by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("ipd", 0f)) }
    var verticalShift by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("verticalShift", 0f)) }
        
    var fabOffsetX by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetX", 50f)) }
    var fabOffsetY by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetY", 300f)) }

    var lensWrapping by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("lensWrapping", true)) }
    var lensDistortion by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("lensDistortion", 0.1f)) }

    val browserManager = androidx.compose.runtime.remember { 
        BrowserManager(context).apply {
            tabs.forEach { addTab(it.id, it.url, isDesktopMode) }
            this.activeTabId = activeTabId
        }
    }
    
    var canGoBack by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        browserManager.onUrlChanged = { newUrl ->
            urlInput = newUrl
            currentUrl = newUrl
            tabs = tabs.map { if (it.id == activeTabId) it.copy(url = newUrl) else it }
        }
        browserManager.onCanGoBackChanged = { canGoBack = it }
    }
    
    androidx.activity.compose.BackHandler(enabled = canGoBack) {
        browserManager.goBack()
    }
    
    androidx.compose.runtime.LaunchedEffect(isDesktopMode) {
        browserManager.updateDesktopMode(isDesktopMode)
    }

    androidx.compose.runtime.LaunchedEffect(isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks) {
        prefs.edit()
            .putBoolean("isDesktopMode", isDesktopMode)
            .putBoolean("isRightHandMode", isRightHandMode)
            .putFloat("scale", scale)
            .putFloat("ipd", ipd)
            .putFloat("verticalShift", verticalShift)
            .putFloat("fabOffsetX", fabOffsetX)
            .putFloat("fabOffsetY", fabOffsetY)
            .putBoolean("lensWrapping", lensWrapping)
            .putFloat("lensDistortion", lensDistortion)
            .putString("savedTabs", tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("bookmarks", bookmarks.joinToString(",") { "${it.first}|${it.second}" })
            .putString("activeTabId", activeTabId)
            .apply()
    }

    var localVideoUri by remember { mutableStateOf<Uri?>(null) }
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            localVideoUri = uri
            isUiVisible = false
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black).vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        // The single WebView container, drawn twice using Compose rendering!
        // Using graphicsLayer maps the affine transform (scale/translate) natively to the View layer,
        // which perfectly fixes the touch mapping offsets when scaling or shifting the IPD.
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye (shifted to the opposite lens)
                    drawContext.canvas.save()
                    val distance = if (isRightHandMode) {
                        -size.width - 2 * ipd
                    } else {
                        size.width + 2 * ipd
                    }
                    drawContext.canvas.translate(distance, 0f)
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale,
                    ipd = ipd,
                    verticalShift = verticalShift,
                    isRightHandMode = isRightHandMode
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize(fraction = scale)
                            .offset(
                                x = with(density) { (if (isRightHandMode) ipd else -ipd).toDp() },
                                y = with(density) { verticalShift.toDp() }
                            )
                    )
                }
            }
        }

        // Left Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        // Right Eye Floating Action Button
        SmallFloatingActionButton(
            onClick = { isUiVisible = !isUiVisible },
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset((fabOffsetX + eyeWidthPx).roundToInt(), fabOffsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        fabOffsetX += dragAmount.x
                        fabOffsetY += dragAmount.y
                    }
                },
            containerColor = Color.White.copy(alpha = 0.5f)
        ) {
            Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
        }

        if (isUiVisible) {
            Column(
                modifier = Modifier
                    .align(if (isRightHandMode) Alignment.TopEnd else Alignment.TopStart) // Constrain UI to active Screen
                    .width(eyeWidth)
                    .padding(8.dp)
            ) {
                // Tab Bar
                Row(
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        itemsIndexed(tabs) { index, tab ->
                            val isSelected = tab.id == activeTabId
                            Surface(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp).clickable {
                                    activeTabId = tab.id
                                    browserManager.activeTabId = tab.id
                                },
                                color = if (isSelected) Color.White.copy(alpha = 0.2f) else Color.Transparent,
                                shape = MaterialTheme.shapes.small
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text("Tab ${index + 1}", color = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            browserManager.removeTab(tab.id)
                                            val newTabs = tabs.filter { it.id != tab.id }
                                            if (newTabs.isEmpty()) {
                                                val newId = java.util.UUID.randomUUID().toString().take(4)
                                                val newTab = WebTab(newId, "https://m.youtube.com")
                                                tabs = listOf(newTab)
                                                browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                                                activeTabId = newId
                                                browserManager.activeTabId = newId
                                            } else {
                                                tabs = newTabs
                                                if (activeTabId == tab.id) {
                                                    val nextTab = newTabs.last()
                                                    activeTabId = nextTab.id
                                                    browserManager.activeTabId = nextTab.id
                                                }
                                            }
                                        },
                                        modifier = Modifier.size(16.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                    
                    IconButton(onClick = { 
                        val newId = java.util.UUID.randomUUID().toString().take(4)
                        val newTab = WebTab(newId, "https://m.youtube.com")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "https://m.youtube.com", isDesktopMode)
                        activeTabId = newId
                        browserManager.activeTabId = newId
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                    }
                    
                    Box {
                        var menuExpanded by remember { mutableStateOf(false) }
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(androidx.compose.material.icons.Icons.Default.MoreVert, contentDescription = "More Options", tint = Color.White)
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Local Video") },
                                onClick = { 
                                    menuExpanded = false
                                    videoPickerLauncher.launch("video/*")
                                },
                                leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Bookmarks") },
                                onClick = { 
                                    menuExpanded = false
                                    showBookmarksList = !showBookmarksList
                                    if (showBookmarksList) showControls = false
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = { 
                                    menuExpanded = false
                                    showControls = !showControls
                                    if (showControls) showBookmarksList = false
                                },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) }
                            )
                        }
                    }
                }

                // Address Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (title to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark", tint = Color.White)
                        }
                        IconButton(onClick = { urlInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    var finalUrl = urlInput
                                    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                        finalUrl = "https://$finalUrl"
                                    }
                                    currentUrl = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { 
                            var finalUrl = urlInput
                            if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
                                finalUrl = "https://$finalUrl"
                            }
                            currentUrl = finalUrl
                            browserManager.loadUrlInActiveTab(finalUrl)
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }
                }
                

                if (showBookmarksList) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("Bookmarks", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                if (bookmarks.isNotEmpty()) {
                                    androidx.compose.material3.TextButton(onClick = { bookmarks = emptyList() }) {
                                        Text("Clear All", color = Color.Red.copy(alpha = 0.8f))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(bookmarks) { bookmark ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                                            urlInput = bookmark.second
                                            currentUrl = bookmark.second
                                            browserManager.loadUrlInActiveTab(bookmark.second)
                                            localVideoUri = null
                                            isUiVisible = false
                                        },
                                        color = Color.White.copy(alpha = 0.1f),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(bookmark.first, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                                Text(bookmark.second, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                            }
                                            IconButton(onClick = { bookmarks = bookmarks.filter { it != bookmark } }) {
                                                Icon(Icons.Default.Clear, "Remove", tint = Color.White)
                                            }
                                        }
                                    }
                                }
                                if (bookmarks.isEmpty()) {
                                    item {
                                        Text("No bookmarks yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                if (showControls) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Controls
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp).verticalScroll(rememberScrollState())) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Right-Hand Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isRightHandMode, onCheckedChange = { isRightHandMode = it })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                            }
                            Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = scale,
                                onValueChange = { scale = it },
                                valueRange = 0.5f..1.5f
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                            }
                            if (lensWrapping) {
                                Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = lensDistortion,
                                    onValueChange = { lensDistortion = it },
                                    valueRange = 0.01f..0.5f
                                )
                            }
                            Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = ipd,
                                onValueChange = { ipd = it },
                                valueRange = -150f..150f
                            )
                            Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = verticalShift,
                                onValueChange = { verticalShift = it },
                                valueRange = -300f..300f
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    scale = 1f
                                    ipd = 0f
                                    verticalShift = 0f
                                    isRightHandMode = true
                                    isDesktopMode = true
                                    lensWrapping = true
                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                            ) {
                                Text("Reset View Settings", color = Color.White)
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        android.webkit.WebStorage.getInstance().deleteOrigin(currentUrl)
                                        android.widget.Toast.makeText(context, "Cleared data for this site!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                                ) {
                                    Text("Clear This Site", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                                Button(
                                    onClick = {
                                        android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                        android.webkit.CookieManager.getInstance().flush()
                                        android.webkit.WebStorage.getInstance().deleteAllData()
                                        android.widget.Toast.makeText(context, "All data cleared!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                                ) {
                                    Text("Clear All Data", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingleBrowser(
    url: String,
    isDesktopMode: Boolean,
    onLoadUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            val frameLayout = android.widget.FrameLayout(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }

            val webView = WebView(context).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                
                webChromeClient = object : WebChromeClient() {
                    private var customView: android.view.View? = null
                    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                    override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                        if (customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        this@apply.visibility = android.view.View.GONE
                        frameLayout.addView(view, android.widget.FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                    }

                    override fun onHideCustomView() {
                        if (customView == null) return
                        frameLayout.removeView(customView)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                        this@apply.visibility = android.view.View.VISIBLE
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        request?.url?.toString()?.let { newUrl ->
                            onLoadUrl(newUrl)
                        }
                        return false
                    }
                }
                loadUrl(url)
            }
            frameLayout.addView(webView)
            frameLayout
        },
        update = { frameLayout ->
            val webView = frameLayout.getChildAt(0) as WebView
            val wantsDesktop = isDesktopMode
            val isCurrentlyDesktop = webView.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    webView.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    webView.settings.userAgentString = WebSettings.getDefaultUserAgent(webView.context)
                }
                webView.reload()
            }

            if (webView.url != url && url.isNotEmpty()) {
                webView.loadUrl(url)
            }
        },
        modifier = modifier.fillMaxSize()
    )
}


@Composable
fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    ipd: Float = 0f,
    verticalShift: Float = 0f,
    isRightHandMode: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(true) }
    var currentPos by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }

    DisposableEffect(uri) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    LaunchedEffect(isPlaying, showControls) {
        if (showControls) {
            while (true) {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        currentPos = it.currentPosition
                    }
                }
                kotlinx.coroutines.delay(500)
            }
        }
    }

    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            kotlinx.coroutines.delay(3000)
            showControls = false
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Black)) {
        androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                    
                    setOnClickListener {
                        showControls = !showControls
                    }
                }
            },
                modifier = Modifier
                    .fillMaxSize(fraction = scale)
                    .offset(
                        x = with(androidx.compose.ui.platform.LocalDensity.current) { (if (isRightHandMode) ipd else -ipd).toDp() },
                        y = with(androidx.compose.ui.platform.LocalDensity.current) { verticalShift.toDp() }
                    )
            )
        }
        
        if (showControls) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))
            
            Column(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition - 10000).coerceAtLeast(0))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastRewind, "Rewind 10s", tint = Color.White)
                    }
                    
                    FloatingActionButton(
                        onClick = {
                            mediaPlayer?.let { player ->
                                if (player.isPlaying) {
                                    player.pause()
                                    isPlaying = false
                                } else {
                                    player.start()
                                    isPlaying = true
                                }
                            }
                        },
                        containerColor = Color.White.copy(alpha = 0.2f)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, 
                            "Play/Pause", 
                            tint = Color.White
                        )
                    }

                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition + 10000).coerceAtMost(duration))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastForward, "Forward 10s", tint = Color.White)
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = if (duration > 0) currentPos.toFloat() / duration.toFloat() else 0f,
                    onValueChange = { percent ->
                        val newPos = (percent * duration).toInt()
                        currentPos = newPos
                        mediaPlayer?.seekTo(newPos)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                
                fun formatTime(ms: Int): String {
                    val s = ms / 1000
                    val m = s / 60
                    val secs = s % 60
                    return String.format("%02d:%02d", m, secs)
                }
                
                Text(
                    "${formatTime(currentPos)} / ${formatTime(duration)}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

class BrowserManager(val context: Context) {
    val container = android.widget.FrameLayout(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }
    private val webViews = mutableMapOf<String, WebView>()
    
    var onUrlChanged: ((String) -> Unit)? = null
    var onCanGoBackChanged: ((Boolean) -> Unit)? = null

    var activeTabId: String? = null
        set(value) {
            field = value
            webViews.forEach { (id, webView) ->
                webView.visibility = if (id == value) android.view.View.VISIBLE else android.view.View.GONE
            }
            getActiveWebView()?.let {
                onUrlChanged?.invoke(it.url ?: it.originalUrl ?: "")
                onCanGoBackChanged?.invoke(it.canGoBack())
            }
        }

    fun getActiveWebView(): WebView? = activeTabId?.let { webViews[it] }

    @SuppressLint("SetJavaScriptEnabled")
    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)
            }
            
            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webChromeClient = object : WebChromeClient() {
                private var customView: android.view.View? = null
                private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    this@apply.visibility = android.view.View.GONE
                    container.addView(view, android.widget.FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    ))
                }

                override fun onHideCustomView() {
                    if (customView == null) return
                    container.removeView(customView)
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    this@apply.visibility = android.view.View.VISIBLE
                }
            }
            webViewClient = object : WebViewClient() {
                override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
                override fun onPageFinished(view: WebView, url: String) {
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
            }
            loadUrl(url)
        }
        webViews[id] = webView
        container.addView(webView)
        
        if (id == activeTabId) {
            webView.visibility = android.view.View.VISIBLE
        } else {
            webView.visibility = android.view.View.GONE
        }
    }

    fun removeTab(id: String) {
        webViews.remove(id)?.let {
            container.removeView(it)
            it.destroy()
        }
    }

    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.loadUrl(url)
    }
    
    fun updateDesktopMode(isDesktopMode: Boolean) {
        webViews.values.forEach { view ->
            val wantsDesktop = isDesktopMode
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    view.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    view.settings.userAgentString = WebSettings.getDefaultUserAgent(view.context)
                }
                view.reload()
            }
        }
    }
    
    fun goBack(): Boolean {
        val wv = getActiveWebView()
        return if (wv?.canGoBack() == true) {
            wv.goBack()
            true
        } else false
    }
}

data class WebTab(val id: String, val url: String)



@android.annotation.SuppressLint("NewApi")
fun Modifier.vrLensDistortion(distortion: Float): Modifier = this.then(
    if (android.os.Build.VERSION.SDK_INT >= 33 && distortion > 0f) {
        androidx.compose.ui.Modifier.graphicsLayer {
            val shader = android.graphics.RuntimeShader("""
                uniform float2 resolution;
                uniform float distortion;
                uniform shader composable;
                
                half4 main(float2 fragCoord) {
                    float halfWidth = resolution.x * 0.5;
                    float isRight = step(halfWidth, fragCoord.x);
                    float offsetX = isRight * halfWidth;
                    
                    float2 uv = float2(fragCoord.x - offsetX, fragCoord.y) / float2(halfWidth, resolution.y);
                    
                    float2 centered = uv - 0.5;
                    float r2 = dot(centered, centered);
                    float2 distorted = centered * (1.0 + distortion * r2);
                    
                    float2 outUv = distorted + 0.5;
                    if (outUv.x < 0.0 || outUv.x > 1.0 || outUv.y < 0.0 || outUv.y > 1.0) {
                        return half4(0.0, 0.0, 0.0, 1.0);
                    }
                    
                    float2 screenUv = float2(outUv.x * halfWidth + offsetX, outUv.y * resolution.y);
                    return composable.eval(screenUv);
                }
            """)
            shader.setFloatUniform("resolution", size.width, size.height)
            shader.setFloatUniform("distortion", distortion)
            renderEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "composable").asComposeRenderEffect()
        }
    } else {
        androidx.compose.ui.Modifier
    }
)
