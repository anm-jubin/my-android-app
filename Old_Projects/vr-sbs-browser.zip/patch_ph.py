import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Fix the multiple windows breaking links/search
target = """                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(true)
                javaScriptCanOpenWindowsAutomatically = true"""

replace = """                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false"""
content = content.replace(target, replace)

# Change default desktop mode to FALSE for better video compatibility
target_dm1 = "var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean(\"isDesktopMode\", true)) }"
replace_dm1 = "var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean(\"isDesktopMode\", false)) }"
content = content.replace(target_dm1, replace_dm1)

target_dm2 = "var isDesktopMode: Boolean = true"
replace_dm2 = "var isDesktopMode: Boolean = false"
content = content.replace(target_dm2, replace_dm2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
