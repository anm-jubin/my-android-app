package com.example

import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asComposeRenderEffect
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.annotation.SuppressLint
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Done

import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MoreVert

import androidx.compose.material.icons.filled.Add

import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.ui.platform.LocalContext
import android.net.Uri
import android.media.MediaPlayer
import android.view.TextureView
import android.view.Surface
import android.graphics.SurfaceTexture
import android.content.Context
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    VRBrowserScreen(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun VRBrowserScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = androidx.compose.runtime.remember { context.getSharedPreferences("vr_prefs", android.content.Context.MODE_PRIVATE) }
    
    val savedTabsStr = prefs.getString("savedTabs", "") ?: ""
    var bookmarks by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf<List<Pair<String, String>>>((prefs.getString("bookmarks", "") ?: "").split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) Pair(parts[0], parts[1]) else null
        }) 
    }
    var tabs by androidx.compose.runtime.remember { 
        val loadedTabs = savedTabsStr.split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size == 2) WebTab(parts[0], parts[1]) else null
        }
        val newId = java.util.UUID.randomUUID().toString().take(4)
        val freshTab = WebTab(newId, "about:blank")
        // Check if there's already an empty default tab from previous session, to avoid infinite empty tabs
        val filteredLoaded = loadedTabs.filter { it.url != "about:blank" }.take(2)
        androidx.compose.runtime.mutableStateOf(listOf(freshTab) + filteredLoaded)
    }
    var activeTabId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.first().id) }

    var urlInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(tabs.firstOrNull { it.id == activeTabId }?.url ?: "about:blank") }
    var currentUrl by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(urlInput) }
    var isUiVisible by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
    var showControls by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var showBookmarksList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var searchEngine by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getString("searchEngine", "Google") ?: "Google") }
    
    var customShortcuts by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(
            (prefs.getString("customShortcuts", "YouTube|https://m.youtube.com,Google|https://www.google.com,Reddit|https://www.reddit.com,Wikipedia|https://www.wikipedia.org") ?: "").split(",").mapNotNull {
                val parts = it.split("|")
                if (parts.size >= 2) Pair(parts[0], parts[1]) else null
            }
        )
    }
    
    fun processInput(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return "https://www.google.com"
        val isUrl = !trimmed.contains(" ") && (trimmed.contains(".") || trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("localhost"))
        if (isUrl) {
            return if (!trimmed.startsWith("http://") && !trimmed.startsWith("https://")) "https://$trimmed" else trimmed
        } else {
            val encoded = java.net.URLEncoder.encode(trimmed, "UTF-8")
            return when (searchEngine) {
                "Bing" -> "https://www.bing.com/search?q=$encoded"
                "DuckDuckGo" -> "https://duckduckgo.com/?q=$encoded"
                else -> "https://www.google.com/search?q=$encoded"
            }
        }
    }
    var historyEnabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("historyEnabled", true)) }
    var historyList by androidx.compose.runtime.remember { 
        androidx.compose.runtime.mutableStateOf<List<Pair<String, String>>>((prefs.getString("historyList", "") ?: "").split(",").mapNotNull { 
            val parts = it.split("|")
            if (parts.size >= 2) Pair(parts[0], parts[1]) else null
        }) 
    }
    var showHistoryList by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var isIncognito by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isIncognito", false)) }
        
    var keepScreenOn by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("keepScreenOn", false)) }
    var isDesktopMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isDesktopMode", true)) }
    var isRightHandMode by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("isRightHandMode", true)) }
    var scale by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("scale", 1f)) }
    var ipd by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("ipd", 0f)) }
    var verticalShift by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("verticalShift", 0f)) }
        
    var fabOffsetX by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetX", 50f)) }
    var fabOffsetY by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("fabOffsetY", 300f)) }

    var lensWrapping by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("lensWrapping", true)) }
    var lensDistortion by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("lensDistortion", 0.1f)) }
    
    var gyroEnabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("gyroEnabled", false)) }
    var shouldRecenter by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    var baseRotationMatrix by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(9) { if (it % 4 == 0) 1f else 0f }) }
    var currentAngleChange by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(FloatArray(3)) }
    var gyroSensitivity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("gyroSensitivity", 1500f)) }
    
    var cameraPassthroughEnabled by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(prefs.getBoolean("cameraPassthroughEnabled", false)) }
    var contentOpacity by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("contentOpacity", 1.0f)) }
    var cameraIpd by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("cameraIpd", 0f)) }
    var cameraScale by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("cameraScale", 1f)) }
    var cameraVerticalShift by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(prefs.getFloat("cameraVerticalShift", 0f)) }

    val activity = context as? android.app.Activity
    androidx.compose.runtime.LaunchedEffect(keepScreenOn) {
        if (keepScreenOn) {
            activity?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    val browserManager = androidx.compose.runtime.remember { 
        BrowserManager(context).apply {
            this.updateIncognitoMode(isIncognito)
            tabs.forEach { addTab(it.id, it.url, isDesktopMode) }
            this.activeTabId = activeTabId
        }
    }
    
    var canGoBack by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        browserManager.onUrlChanged = { newUrl ->
            urlInput = newUrl
            currentUrl = newUrl
            tabs = tabs.map { if (it.id == activeTabId) it.copy(url = newUrl) else it }
            if (historyEnabled && !isIncognito) {
                val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(newUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                // prevent consecutive duplicates
                val cleanUrl = newUrl.trimEnd('/')
                val prevCleanUrl = historyList.firstOrNull()?.second?.trimEnd('/')
                if (cleanUrl != prevCleanUrl) {
                    historyList = listOf(Pair(title, newUrl)) + historyList
                    if (historyList.size > 100) {
                        historyList = historyList.take(100)
                    }
                } else if (historyList.isNotEmpty() && historyList.first().first != title && title != "Site") {
                    val mutableList = historyList.toMutableList()
                    mutableList[0] = Pair(title, historyList.first().second)
                    historyList = mutableList
                }
            }
        }
        browserManager.onCanGoBackChanged = { canGoBack = it }
    }
    
    androidx.activity.compose.BackHandler(enabled = canGoBack) {
        browserManager.goBack()
    }
    
    androidx.compose.runtime.LaunchedEffect(isDesktopMode) {
        browserManager.updateDesktopMode(isDesktopMode)
    }
    androidx.compose.runtime.LaunchedEffect(cameraPassthroughEnabled) {
        browserManager.updatePassthrough(cameraPassthroughEnabled)
    }

    androidx.compose.runtime.LaunchedEffect(keepScreenOn, isDesktopMode, isRightHandMode, scale, ipd, verticalShift, fabOffsetX, fabOffsetY, tabs, activeTabId, lensWrapping, lensDistortion, bookmarks, searchEngine, gyroEnabled, gyroSensitivity, historyEnabled, historyList, isIncognito, cameraPassthroughEnabled, contentOpacity, cameraIpd, cameraScale, cameraVerticalShift) {
        prefs.edit()
            .putBoolean("keepScreenOn", keepScreenOn)
            .putBoolean("isDesktopMode", isDesktopMode)
            .putBoolean("isRightHandMode", isRightHandMode)
            .putFloat("scale", scale)
            .putFloat("ipd", ipd)
            .putFloat("verticalShift", verticalShift)
            .putFloat("fabOffsetX", fabOffsetX)
            .putFloat("fabOffsetY", fabOffsetY)
            .putBoolean("lensWrapping", lensWrapping)
            .putFloat("lensDistortion", lensDistortion)
            .putString("searchEngine", searchEngine)
            .putBoolean("historyEnabled", historyEnabled)
            .putString("historyList", historyList.joinToString(",") { "${it.first}|${it.second}" })
            .putBoolean("gyroEnabled", gyroEnabled)
            .putFloat("gyroSensitivity", gyroSensitivity)
            .putBoolean("isIncognito", isIncognito)
            .putBoolean("cameraPassthroughEnabled", cameraPassthroughEnabled)
            .putFloat("contentOpacity", contentOpacity)
            .putFloat("cameraIpd", cameraIpd)
            .putFloat("cameraScale", cameraScale)
            .putFloat("cameraVerticalShift", cameraVerticalShift)
            .putString("savedTabs", if (isIncognito) "" else tabs.joinToString(",") { "${it.id}|${it.url}" })
            .putString("bookmarks", bookmarks.joinToString(",") { "${it.first}|${it.second}" })
            .putString("activeTabId", if (isIncognito) "" else activeTabId)
            .apply()
    }


    // Gyroscope Setup
    val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
    androidx.compose.runtime.DisposableEffect(gyroEnabled, shouldRecenter) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
        val rotationSensor = sensorManager.getDefaultSensor(android.hardware.Sensor.TYPE_GAME_ROTATION_VECTOR)
        
        val listener = object : android.hardware.SensorEventListener {
            override fun onSensorChanged(event: android.hardware.SensorEvent) {
                if (event.sensor.type == android.hardware.Sensor.TYPE_GAME_ROTATION_VECTOR) {
                    val rotationMatrix = FloatArray(9)
                    android.hardware.SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    
                    val remappedMatrix = FloatArray(9)
                    when (windowManager.defaultDisplay.rotation) {
                        android.view.Surface.ROTATION_90 -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_Y, android.hardware.SensorManager.AXIS_MINUS_X, remappedMatrix)
                        android.view.Surface.ROTATION_270 -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_MINUS_Y, android.hardware.SensorManager.AXIS_X, remappedMatrix)
                        android.view.Surface.ROTATION_180 -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_MINUS_X, android.hardware.SensorManager.AXIS_MINUS_Y, remappedMatrix)
                        else -> android.hardware.SensorManager.remapCoordinateSystem(rotationMatrix, android.hardware.SensorManager.AXIS_X, android.hardware.SensorManager.AXIS_Y, remappedMatrix)
                    }
                    
                    if (shouldRecenter) {
                        baseRotationMatrix = remappedMatrix.clone()
                        shouldRecenter = false
                    }
                    
                    val angleChange = FloatArray(3)
                    android.hardware.SensorManager.getAngleChange(angleChange, remappedMatrix, baseRotationMatrix)
                    currentAngleChange = angleChange.clone()
                }
            }
            override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
        }
        
        if (gyroEnabled && rotationSensor != null) {
            sensorManager.registerListener(listener, rotationSensor, android.hardware.SensorManager.SENSOR_DELAY_GAME)
        }
        
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }
    
    // getAngleChange indices: 0 = Z (Roll), 1 = X (Pitch), 2 = Y (Yaw)
    // We invert Yaw because turning head right (positive Y rotation) should move the screen left (negative offset)
    val gyroYawOffset = if (gyroEnabled) currentAngleChange[2] * (gyroSensitivity * 1.5f) else 0f
    val gyroPitchOffset = if (gyroEnabled) currentAngleChange[1] * -gyroSensitivity else 0f

    var localVideoUri by remember { mutableStateOf<Uri?>(null) }
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            localVideoUri = uri
            isUiVisible = false
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(if (cameraPassthroughEnabled) Color.Transparent else Color.Black)) {
        val eyeWidth = maxWidth / 2
        val density = LocalDensity.current
        val eyeWidthPx = with(density) { eyeWidth.toPx() }

        if (cameraPassthroughEnabled) {
            VrSplitScreenWrapper(
                isRightHandMode = isRightHandMode,
                ipd = cameraIpd,
                gyroYawOffset = 0f,
                gyroPitchOffset = 0f,
                verticalShift = cameraVerticalShift,
                lensWrapping = lensWrapping,
                lensDistortion = lensDistortion,
                eyeWidth = eyeWidth
            ) {
                CameraPassthroughLayer(
                    modifier = Modifier.graphicsLayer { scaleX = cameraScale; scaleY = cameraScale }
                )
            }
        }

        // Wrapper for the lens distortion, so it only distorts the content, not the UI!
        VrSplitScreenWrapper(
            isRightHandMode = isRightHandMode,
            ipd = ipd,
            gyroYawOffset = gyroYawOffset,
            gyroPitchOffset = gyroPitchOffset,
            verticalShift = verticalShift,
            lensWrapping = lensWrapping,
            lensDistortion = lensDistortion,
            eyeWidth = eyeWidth,
            modifier = Modifier.alpha(contentOpacity)
        ) {
            if (localVideoUri != null) {
                TextureVideoPlayer(
                    uri = localVideoUri!!,
                    scale = scale
                )
            } else {
                androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AndroidView(
                        factory = { browserManager.container },
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                    )
                    if (currentUrl == "about:blank" || currentUrl.isEmpty()) {
                        NewTabPage(
                            isPassthroughEnabled = cameraPassthroughEnabled,
                            shortcuts = customShortcuts,
                            onSearch = { query ->
                                val finalUrl = processInput(query)
                                currentUrl = finalUrl
                                urlInput = finalUrl
                                browserManager.loadUrlInActiveTab(finalUrl)
                                localVideoUri = null
                                isUiVisible = false
                            },

                        )
                    }
                }
            }
        } // Close distortion wrapper

        // Left Eye Floating Action Button
        Column(
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset(fabOffsetX.roundToInt(), fabOffsetY.roundToInt()) }
        ) {
            SmallFloatingActionButton(
                onClick = { isUiVisible = !isUiVisible },
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            fabOffsetX += dragAmount.x
                            fabOffsetY += dragAmount.y
                        }
                    },
                containerColor = Color.White.copy(alpha = 0.5f)
            ) {
                Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
            }
            if (gyroEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                SmallFloatingActionButton(
                    onClick = { shouldRecenter = true },
                    modifier = Modifier
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                fabOffsetX += dragAmount.x
                                fabOffsetY += dragAmount.y
                            }
                        },
                    containerColor = Color.Cyan.copy(alpha = 0.5f)
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Done, contentDescription = "Recenter", tint = Color.Black)
                }
            }
        }

        // Right Eye Floating Action Button
        Column(
            modifier = Modifier
                .zIndex(1f)
                .offset { IntOffset((fabOffsetX + eyeWidthPx).roundToInt(), fabOffsetY.roundToInt()) }
        ) {
            SmallFloatingActionButton(
                onClick = { isUiVisible = !isUiVisible },
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            fabOffsetX += dragAmount.x
                            fabOffsetY += dragAmount.y
                        }
                    },
                containerColor = Color.White.copy(alpha = 0.5f)
            ) {
                Text(if (isUiVisible) "Hide" else "UI", color = Color.Black, style = MaterialTheme.typography.labelSmall)
            }
            if (gyroEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                SmallFloatingActionButton(
                    onClick = { shouldRecenter = true },
                    modifier = Modifier
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                fabOffsetX += dragAmount.x
                                fabOffsetY += dragAmount.y
                            }
                        },
                    containerColor = Color.Cyan.copy(alpha = 0.5f)
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Done, contentDescription = "Recenter", tint = Color.Black)
                }
            }
        }

        if (isUiVisible) {
            Column(
                modifier = Modifier
                    .align(if (isRightHandMode) Alignment.TopEnd else Alignment.TopStart) // Constrain UI to active Screen
                    .width(eyeWidth)
                    .padding(8.dp)
            ) {
                // Tab Bar
                Row(
                    modifier = Modifier.height(48.dp).fillMaxWidth().padding(bottom = 4.dp).background(Color.DarkGray.copy(alpha = 0.8f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        itemsIndexed(tabs) { index, tab ->
                            val isSelected = tab.id == activeTabId
                            Surface(
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp).clickable {
                                    activeTabId = tab.id
                                    browserManager.activeTabId = tab.id
                                },
                                color = if (isSelected) Color.White.copy(alpha = 0.2f) else Color.Transparent,
                                shape = MaterialTheme.shapes.small
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text("Tab ${index + 1}", color = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            browserManager.removeTab(tab.id)
                                            val newTabs = tabs.filter { it.id != tab.id }
                                            if (newTabs.isEmpty()) {
                                                val newId = java.util.UUID.randomUUID().toString().take(4)
                                                val newTab = WebTab(newId, "about:blank")
                                                tabs = listOf(newTab)
                                                browserManager.addTab(newId, "about:blank", isDesktopMode)
                                                activeTabId = newId
                                                browserManager.activeTabId = newId
                                            } else {
                                                tabs = newTabs
                                                if (activeTabId == tab.id) {
                                                    val nextTab = newTabs.last()
                                                    activeTabId = nextTab.id
                                                    browserManager.activeTabId = nextTab.id
                                                }
                                            }
                                        },
                                        modifier = Modifier.size(16.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                    
                    IconButton(onClick = { 
                        val newId = java.util.UUID.randomUUID().toString().take(4)
                        val newTab = WebTab(newId, "about:blank")
                        tabs = tabs + newTab
                        browserManager.addTab(newId, "about:blank", isDesktopMode)
                        activeTabId = newId
                        browserManager.activeTabId = newId
                    }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Tab", tint = Color.White)
                    }
                    
                    Box {
                        var menuExpanded by remember { mutableStateOf(false) }
                        IconButton(onClick = { menuExpanded = true }) {
                            Icon(androidx.compose.material.icons.Icons.Default.MoreVert, contentDescription = "More Options", tint = Color.White)
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Local Video") },
                                onClick = { 
                                    menuExpanded = false
                                    videoPickerLauncher.launch("video/*")
                                },
                                leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Bookmarks") },
                                onClick = { 
                                    menuExpanded = false
                                    showBookmarksList = !showBookmarksList
                                    if (showBookmarksList) { showControls = false; showHistoryList = false }
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("History") },
                                onClick = { 
                                    menuExpanded = false
                                    showHistoryList = !showHistoryList
                                    if (showHistoryList) { showControls = false; showBookmarksList = false }
                                },
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) } // Use List icon or something else
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                onClick = { 
                                    menuExpanded = false
                                    showControls = !showControls
                                    if (showControls) { showBookmarksList = false; showHistoryList = false }
                                },
                                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) }
                            )
                        }
                    }
                }

                // Address Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.DarkGray.copy(alpha = 0.8f),
                    shape = MaterialTheme.shapes.small
                ) {
                    Row(
                        modifier = Modifier.padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { 
                            val title = browserManager.getActiveWebView()?.title ?: try { android.net.Uri.parse(currentUrl).host ?: "Site" } catch(e: Exception) { "Site" }
                            if (bookmarks.none { it.second == currentUrl }) {
                                bookmarks = bookmarks + (title to currentUrl)
                            } else {
                                bookmarks = bookmarks.filter { it.second != currentUrl }
                            }
                        }) {
                            val isBookmarked = bookmarks.any { it.second == currentUrl }
                            Icon(if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, "Bookmark", tint = Color.White)
                        }
                        IconButton(onClick = { urlInput = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White)
                        }
                        TextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            placeholder = { Text("Search or type URL", color = Color.Gray) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.DarkGray,
                                unfocusedContainerColor = Color.DarkGray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Uri,
                                imeAction = ImeAction.Go
                            ),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    val finalUrl = processInput(urlInput)
                                    currentUrl = finalUrl
                                    urlInput = finalUrl
                                    browserManager.loadUrlInActiveTab(finalUrl)
                                    localVideoUri = null
                                    isUiVisible = false
                                }
                            )
                        )
                        IconButton(onClick = { 
                            val finalUrl = processInput(urlInput)
                            currentUrl = finalUrl
                            urlInput = finalUrl
                            browserManager.loadUrlInActiveTab(finalUrl)
                            localVideoUri = null
                            isUiVisible = false
                        }) {
                            Text("Go", color = Color.White)
                        }
                    }
                }
                

                if (showBookmarksList) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("Bookmarks", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                if (bookmarks.isNotEmpty()) {
                                    androidx.compose.material3.TextButton(onClick = { bookmarks = emptyList() }) {
                                        Text("Clear All", color = Color.Red.copy(alpha = 0.8f))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(bookmarks) { bookmark ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                                            urlInput = bookmark.second
                                            currentUrl = bookmark.second
                                            browserManager.loadUrlInActiveTab(bookmark.second)
                                            localVideoUri = null
                                            isUiVisible = false
                                        },
                                        color = Color.White.copy(alpha = 0.1f),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(bookmark.first, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                                Text(bookmark.second, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                            }
                                            IconButton(onClick = { bookmarks = bookmarks.filter { it != bookmark } }) {
                                                Icon(Icons.Default.Clear, "Remove", tint = Color.White)
                                            }
                                        }
                                    }
                                }
                                if (bookmarks.isEmpty()) {
                                    item {
                                        Text("No bookmarks yet.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                if (showHistoryList) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Text("History", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Record", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Switch(checked = historyEnabled, onCheckedChange = { historyEnabled = it })
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (historyList.isNotEmpty()) {
                                        androidx.compose.material3.TextButton(onClick = { historyList = emptyList() }) {
                                            Text("Clear All", color = Color.Red.copy(alpha = 0.8f))
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(historyList) { historyItem ->
                                    Surface(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                                            urlInput = historyItem.second
                                            currentUrl = historyItem.second
                                            browserManager.loadUrlInActiveTab(historyItem.second)
                                            localVideoUri = null
                                            isUiVisible = false
                                        },
                                        color = Color.White.copy(alpha = 0.1f),
                                        shape = MaterialTheme.shapes.small
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(historyItem.first, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                                Text(historyItem.second, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                                            }
                                            IconButton(onClick = { historyList = historyList.filter { it != historyItem } }) {
                                                Icon(Icons.Default.Clear, "Remove", tint = Color.White)
                                            }
                                        }
                                    }
                                }
                                if (historyList.isEmpty()) {
                                    item {
                                        Text(if (historyEnabled) "No history yet." else "History is disabled.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                                    }
                                }
                            }
                        }
                    }
                }
                if (showControls) {
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Controls
                    Surface(
                        modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                        color = Color.DarkGray.copy(alpha = 0.8f),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Column(modifier = Modifier.padding(8.dp).verticalScroll(rememberScrollState())) {
                            SettingsSection("Browser & System") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Keep Screen On", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = keepScreenOn, onCheckedChange = { keepScreenOn = it })
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Right-Hand Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = isRightHandMode, onCheckedChange = { isRightHandMode = it })
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Desktop Mode", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = isDesktopMode, onCheckedChange = { isDesktopMode = it })
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Incognito Mode", color = if (isIncognito) Color.Cyan else Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(
                                        checked = isIncognito, 
                                        onCheckedChange = { 
                                            isIncognito = it 
                                            browserManager.updateIncognitoMode(it)
                                        }
                                    )
                                }
                                androidx.compose.material3.TextButton(onClick = { browserManager.clearIncognitoData() }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Clear Incognito Data", color = Color.Red)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                    Text("Search Engine", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    var engineExpanded by remember { mutableStateOf(false) }
                                    Box {
                                        androidx.compose.material3.TextButton(onClick = { engineExpanded = true }) {
                                            Text(searchEngine, color = Color.Cyan)
                                        }
                                        DropdownMenu(
                                            expanded = engineExpanded,
                                            onDismissRequest = { engineExpanded = false }
                                        ) {
                                            DropdownMenuItem(text = { Text("Google") }, onClick = { searchEngine = "Google"; engineExpanded = false })
                                            DropdownMenuItem(text = { Text("Bing") }, onClick = { searchEngine = "Bing"; engineExpanded = false })
                                            DropdownMenuItem(text = { Text("DuckDuckGo") }, onClick = { searchEngine = "DuckDuckGo"; engineExpanded = false })
                                        }
                                    }
                                }
                            }
                            
                            SettingsSection("Custom Shortcuts") {
                                var newShortcutName by remember { mutableStateOf("") }
                                var newShortcutUrl by remember { mutableStateOf("") }
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    customShortcuts.forEach { shortcut ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(shortcut.first, color = Color.White, style = MaterialTheme.typography.bodySmall)
                                                Text(shortcut.second, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                                            }
                                            IconButton(onClick = { 
                                                val newList = customShortcuts.filter { it != shortcut }
                                                customShortcuts = newList
                                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                                            }) {
                                                Icon(Icons.Default.Clear, contentDescription = "Remove", tint = Color.Red)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            TextField(value = newShortcutName, onValueChange = { newShortcutName = it }, placeholder = { Text("Name", style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.fillMaxWidth().height(48.dp), textStyle = MaterialTheme.typography.labelSmall)
                                            Spacer(modifier = Modifier.height(4.dp))
                                            TextField(value = newShortcutUrl, onValueChange = { newShortcutUrl = it }, placeholder = { Text("URL", style = MaterialTheme.typography.labelSmall) }, modifier = Modifier.fillMaxWidth().height(48.dp), textStyle = MaterialTheme.typography.labelSmall)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        androidx.compose.material3.TextButton(onClick = {
                                            if (newShortcutName.isNotBlank() && newShortcutUrl.isNotBlank()) {
                                                val u = if (!newShortcutUrl.startsWith("http")) "https://$newShortcutUrl" else newShortcutUrl
                                                val newList = customShortcuts + Pair(newShortcutName, u)
                                                customShortcuts = newList
                                                prefs.edit().putString("customShortcuts", newList.joinToString(",") { "${it.first}|${it.second}" }).apply()
                                                newShortcutName = ""
                                                newShortcutUrl = ""
                                            }
                                        }) {
                                            Text("Add", color = Color.Cyan)
                                        }
                                    }
                                }
                            }
                            
                            SettingsSection("Virtual Screen") {
                                Text("Screen Size", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = scale,
                                    onValueChange = { scale = it },
                                    valueRange = 0.1f..3.0f
                                )
                                Text("Pupil Distance (IPD)", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = ipd,
                                    onValueChange = { ipd = it },
                                    valueRange = -500f..500f
                                )
                                Text("Vertical Shift", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = verticalShift,
                                    onValueChange = { verticalShift = it },
                                    valueRange = -1000f..1000f
                                )
                                if (android.os.Build.VERSION.SDK_INT >= 33) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Lens Wrapping", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                        Switch(checked = lensWrapping, onCheckedChange = { lensWrapping = it })
                                    }
                                    if (lensWrapping) {
                                        Text("Distortion Amount", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                        Slider(
                                            value = lensDistortion,
                                            onValueChange = { lensDistortion = it },
                                            valueRange = 0.0f..1.5f
                                        )
                                    }
                                } else {
                                    Text("Lens Wrapping requires Android 13+", color = Color.Red.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(vertical = 4.dp))
                                }
                            }
                            
                            SettingsSection("Camera Passthrough") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Enable Passthrough", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = cameraPassthroughEnabled, onCheckedChange = { cameraPassthroughEnabled = it })
                                }
                                if (cameraPassthroughEnabled) {
                                    Text("Content Opacity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = contentOpacity,
                                        onValueChange = { contentOpacity = it },
                                        valueRange = 0.1f..1.0f
                                    )
                                    Text("Camera IPD", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = cameraIpd,
                                        onValueChange = { cameraIpd = it },
                                        valueRange = -200f..200f
                                    )
                                    Text("Camera Scale", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = cameraScale,
                                        onValueChange = { cameraScale = it },
                                        valueRange = 0.5f..2.5f
                                    )
                                    Text("Camera Vertical", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = cameraVerticalShift,
                                        onValueChange = { cameraVerticalShift = it },
                                        valueRange = -300f..300f
                                    )
                                }
                            }
                            
                            SettingsSection("Gyroscope") {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Enable Head Tracking", color = Color.White, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                                    Switch(checked = gyroEnabled, onCheckedChange = { 
                                        gyroEnabled = it 
                                        if (it) shouldRecenter = true
                                    })
                                }
                                if (gyroEnabled) {
                                    Text("Gyro Sensitivity", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = gyroSensitivity,
                                        onValueChange = { gyroSensitivity = it },
                                        valueRange = 500f..3000f
                                    )
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    scale = 1f
                                    ipd = 0f
                                    verticalShift = 0f
                                    isRightHandMode = true
                                    isDesktopMode = true
                                    lensWrapping = true
                                    lensDistortion = 0.1f
                                    fabOffsetX = 50f
                                    fabOffsetY = 300f
                                    gyroEnabled = false
                                    gyroSensitivity = 1500f
                                    shouldRecenter = true
                                    
                                    cameraIpd = 0f
                                    cameraScale = 1f
                                    cameraVerticalShift = 0f
                                    contentOpacity = 1f
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                            ) {
                                Text("Reset View Settings", color = Color.White)
                            }
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        android.webkit.WebStorage.getInstance().deleteOrigin(currentUrl)
                                        android.widget.Toast.makeText(context, "Cleared data for this site!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                                ) {
                                    Text("Clear This Site", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                                Button(
                                    onClick = {
                                        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                                            val profileName = if (isIncognito) "incognito" else androidx.webkit.Profile.DEFAULT_PROFILE_NAME
                                            val cookieManager = androidx.webkit.ProfileStore.getInstance().getProfile(profileName)?.cookieManager
                                            cookieManager?.removeAllCookies(null)
                                            cookieManager?.flush()
                                        } else {
                                            android.webkit.CookieManager.getInstance().removeAllCookies(null)
                                            android.webkit.CookieManager.getInstance().flush()
                                        }
                                        android.webkit.WebStorage.getInstance().deleteAllData()
                                        android.widget.Toast.makeText(context, "All data cleared!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.7f))
                                ) {
                                    Text("Clear All Data", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingleBrowser(
    url: String,
    isDesktopMode: Boolean,
    onLoadUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            val frameLayout = android.widget.FrameLayout(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }

            val webView = WebView(context).apply {
                layoutParams = android.widget.FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                
                webChromeClient = object : WebChromeClient() {
                    private var customView: android.view.View? = null
                    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                    override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                        if (customView != null) {
                            callback?.onCustomViewHidden()
                            return
                        }
                        customView = view
                        customViewCallback = callback
                        this@apply.visibility = android.view.View.GONE
                        frameLayout.addView(view, android.widget.FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        ))
                    }

                    override fun onHideCustomView() {
                        if (customView == null) return
                        frameLayout.removeView(customView)
                        customView = null
                        customViewCallback?.onCustomViewHidden()
                        customViewCallback = null
                        this@apply.visibility = android.view.View.VISIBLE
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        request?.url?.toString()?.let { newUrl ->
                            onLoadUrl(newUrl)
                        }
                        return false
                    }
                }
                loadUrl(url)
            }
            frameLayout.addView(webView)
            frameLayout
        },
        update = { frameLayout ->
            val webView = frameLayout.getChildAt(0) as WebView
            val wantsDesktop = isDesktopMode
            val isCurrentlyDesktop = webView.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    webView.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    webView.settings.userAgentString = WebSettings.getDefaultUserAgent(webView.context)
                }
                webView.reload()
            }

            if (webView.url != url && url.isNotEmpty()) {
                webView.loadUrl(url)
            }
        },
        modifier = modifier.fillMaxSize()
    )
}


@Composable
fun TextureVideoPlayer(
    uri: Uri, 
    scale: Float = 1f,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var showControls by remember { mutableStateOf(true) }
    var currentPos by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }

    DisposableEffect(uri) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    LaunchedEffect(isPlaying, showControls) {
        if (showControls) {
            while (true) {
                mediaPlayer?.let {
                    if (it.isPlaying) {
                        currentPos = it.currentPosition
                    }
                }
                kotlinx.coroutines.delay(500)
            }
        }
    }

    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            kotlinx.coroutines.delay(3000)
            showControls = false
        }
    }

    var seekingPos by remember { mutableStateOf<Int?>(null) }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { showControls = !showControls },
                    onDoubleTap = { offset ->
                        mediaPlayer?.let { player ->
                            val halfWidth = size.width / 2
                            val seekAmount = 10000
                            if (offset.x < halfWidth) {
                                val newPos = (player.currentPosition - seekAmount).coerceAtLeast(0)
                                player.seekTo(newPos)
                                currentPos = newPos
                            } else {
                                val newPos = (player.currentPosition + seekAmount).coerceAtMost(duration)
                                player.seekTo(newPos)
                                currentPos = newPos
                            }
                            showControls = true
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                var dragAccumulator = 0f
                detectHorizontalDragGestures(
                    onDragStart = { 
                        dragAccumulator = 0f
                        seekingPos = mediaPlayer?.currentPosition
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        dragAccumulator += dragAmount
                        // 10 pixels = 1 second
                        val seekMs = (dragAccumulator / 10f) * 1000f
                        seekingPos = ((mediaPlayer?.currentPosition ?: 0) + seekMs.toInt()).coerceIn(0, duration)
                    },
                    onDragEnd = {
                        seekingPos?.let { pos ->
                            mediaPlayer?.seekTo(pos)
                            currentPos = pos
                        }
                        seekingPos = null
                        showControls = true
                    },
                    onDragCancel = { seekingPos = null }
                )
            }
    ) {
        androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->
                TextureView(ctx).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            mediaPlayer = MediaPlayer().apply {
                                setSurface(Surface(surface))
                                try {
                                    setDataSource(ctx, uri)
                                    setOnPreparedListener { 
                                        duration = it.duration
                                        isLooping = true
                                        start() 
                                    }
                                    prepareAsync()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            mediaPlayer?.release()
                            mediaPlayer = null
                            return true
                        }
                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                }
            },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { scaleX = scale; scaleY = scale }
            )
        }
        
        if (seekingPos != null) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) {
                Text(
                    text = String.format("%02d:%02d", (seekingPos!! / 1000) / 60, (seekingPos!! / 1000) % 60),
                    color = Color.White,
                    style = MaterialTheme.typography.displayMedium
                )
            }
        } else if (showControls) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)))
            
            Column(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition - 10000).coerceAtLeast(0))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastRewind, "Rewind 10s", tint = Color.White)
                    }
                    
                    FloatingActionButton(
                        onClick = {
                            mediaPlayer?.let { player ->
                                if (player.isPlaying) {
                                    player.pause()
                                    isPlaying = false
                                } else {
                                    player.start()
                                    isPlaying = true
                                }
                            }
                        },
                        containerColor = Color.White.copy(alpha = 0.2f)
                    ) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, 
                            "Play/Pause", 
                            tint = Color.White
                        )
                    }

                    IconButton(onClick = { 
                        mediaPlayer?.let {
                            it.seekTo((it.currentPosition + 10000).coerceAtMost(duration))
                            currentPos = it.currentPosition
                        } 
                    }) {
                        Icon(Icons.Default.FastForward, "Forward 10s", tint = Color.White)
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Slider(
                    value = if (duration > 0) currentPos.toFloat() / duration.toFloat() else 0f,
                    onValueChange = { percent ->
                        val newPos = (percent * duration).toInt()
                        currentPos = newPos
                        mediaPlayer?.seekTo(newPos)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                
                fun formatTime(ms: Int): String {
                    val s = ms / 1000
                    val m = s / 60
                    val secs = s % 60
                    return String.format("%02d:%02d", m, secs)
                }
                
                Text(
                    "${formatTime(currentPos)} / ${formatTime(duration)}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
    }
}

class BrowserManager(val context: Context) {
    var isPassthroughEnabled: Boolean = false
    fun updatePassthrough(enabled: Boolean) {
        isPassthroughEnabled = enabled
        webViews.values.forEach { view ->
            if (enabled) {
                view.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
            } else {
                view.setBackgroundColor(android.graphics.Color.WHITE)
                view.evaluateJavascript("document.body.style.backgroundColor = ''; document.documentElement.style.backgroundColor = '';", null)
            }
        }
    }
    var isIncognito: Boolean = false
    var isDesktopMode: Boolean = true

    fun clearIncognitoData() {
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
            val profileStore = androidx.webkit.ProfileStore.getInstance()
            profileStore.deleteProfile("incognito")
        }
    }

    fun updateIncognitoMode(incognito: Boolean) {
        val didChange = isIncognito != incognito
        isIncognito = incognito
        
        if (didChange) {
            // Re-create all tabs to apply the new profile!
            val oldTabs = webViews.keys.toList()
            oldTabs.forEach { tabId ->
                val webView = webViews[tabId]
                val currentUrl = webView?.url ?: webView?.originalUrl ?: "about:blank"
                container.removeView(webView)
                webViews.remove(tabId)
                webView?.destroy()
                
                // Re-add tab which will now check the new isIncognito state and set Profile
                addTab(tabId, currentUrl, true) // Wait, isDesktopMode is hard to fetch here... we'll assume true or we can just let it reload the page.
            }
            // activeTabId setter will update visibility
            val oldActive = activeTabId
            activeTabId = oldActive
        }
    }

    val container = android.widget.FrameLayout(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }
    private val webViews = mutableMapOf<String, WebView>()
    
    var onUrlChanged: ((String) -> Unit)? = null
    var onCanGoBackChanged: ((Boolean) -> Unit)? = null

    var activeTabId: String? = null
        set(value) {
            field = value
            webViews.forEach { (id, webView) ->
                webView.visibility = if (id == value) android.view.View.VISIBLE else android.view.View.GONE
            }
            getActiveWebView()?.let {
                onUrlChanged?.invoke(it.url ?: it.originalUrl ?: "")
                onCanGoBackChanged?.invoke(it.canGoBack())
            }
        }

    fun getActiveWebView(): WebView? = activeTabId?.let { webViews[it] }

    @SuppressLint("SetJavaScriptEnabled")
    fun addTab(id: String, url: String, isDesktopMode: Boolean) {
        val webView = WebView(context).apply {
            if (this@BrowserManager.isPassthroughEnabled) {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            } else {
                setBackgroundColor(android.graphics.Color.WHITE)
            }
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val profileStore = androidx.webkit.ProfileStore.getInstance()
                if (this@BrowserManager.isIncognito) {
                    val profile = profileStore.getOrCreateProfile("incognito")
                    androidx.webkit.WebViewCompat.setProfile(this, profile.name)
                } else {
                    val profile = profileStore.getOrCreateProfile(androidx.webkit.Profile.DEFAULT_PROFILE_NAME) // or ProfileStore.getInstance().getProfile(androidx.webkit.Profile.DEFAULT_PROFILE_NAME)
                    androidx.webkit.WebViewCompat.setProfile(this, androidx.webkit.Profile.DEFAULT_PROFILE_NAME)
                }
            }

            layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = !this@BrowserManager.isIncognito
                databaseEnabled = !this@BrowserManager.isIncognito
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
                val wantsDesktop = isDesktopMode && !isMobileFriendly
                userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)
            }
            
            if (this@BrowserManager.isPassthroughEnabled) {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
            } else {
                setBackgroundColor(android.graphics.Color.WHITE)
            }
            if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
                val cookieManager = androidx.webkit.WebViewCompat.getProfile(this).cookieManager
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(this, true)
            } else {
                android.webkit.CookieManager.getInstance().setAcceptCookie(true)
                android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            }

            webChromeClient = object : WebChromeClient() {
                private var customView: android.view.View? = null
                private var customViewCallback: WebChromeClient.CustomViewCallback? = null

                override fun onShowCustomView(view: android.view.View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = view
                    customViewCallback = callback
                    this@apply.visibility = android.view.View.GONE
                    container.addView(view, android.widget.FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    ))
                }

                override fun onHideCustomView() {
                    if (customView == null) return
                    container.removeView(customView)
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    this@apply.visibility = android.view.View.VISIBLE
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val newUrl = request?.url?.toString() ?: return false
                    view?.let {
                        val isMobileFriendly = newUrl.contains("instagram.com") || newUrl.contains("tiktok.com")
                        val wantsDesktop = this@BrowserManager.isDesktopMode && !isMobileFriendly
                        val isCurrentlyDesktop = it.settings.userAgentString.contains("Windows NT")
                        if (wantsDesktop != isCurrentlyDesktop) {
                            it.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)
                            it.loadUrl(newUrl)
                            return true
                        }
                    }
                    return false
                }
                override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon)

                }
                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        val js = """
                            var meta = document.querySelector('meta[name="viewport"]');
                            if (meta) {
                                meta.content = 'width=500, user-scalable=no';
                            } else {
                                meta = document.createElement('meta');
                                meta.name = 'viewport';
                                meta.content = 'width=500, user-scalable=no';
                                document.head.appendChild(meta);
                            }
                            var style = document.createElement('style');
                            style.innerHTML = 'html, body { width: 100% !important; overflow-x: hidden !important; } #react-root, main, #mount_0_0 { margin: 0 auto !important; display: flex !important; justify-content: center !important; flex-direction: column !important; align-items: center !important; }';
                            document.head.appendChild(style);
                        """.trimIndent()
                        view.evaluateJavascript(js, null)
                    }
                    if (id == activeTabId) {
                        onUrlChanged?.invoke(url)
                        onCanGoBackChanged?.invoke(view.canGoBack())
                    }
                }
            }
            loadUrl(url)
        }
        webViews[id] = webView
        container.addView(webView)
        
        if (id == activeTabId) {
            webView.visibility = android.view.View.VISIBLE
        } else {
            webView.visibility = android.view.View.GONE
        }
    }

    fun removeTab(id: String) {
        webViews.remove(id)?.let {
            container.removeView(it)
            it.destroy()
        }
    }

    fun loadUrlInActiveTab(url: String) {
        getActiveWebView()?.let { view ->
            val isMobileFriendly = url.contains("instagram.com") || url.contains("tiktok.com")
            val wantsDesktop = this.isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                view.settings.userAgentString = if (wantsDesktop) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(view.context)
            }
            view.loadUrl(url)
        }
    }
    
    fun updateDesktopMode(isDesktopMode: Boolean) {
        this.isDesktopMode = isDesktopMode
        webViews.values.forEach { view ->
            val isMobileFriendly = view.url?.contains("instagram.com") == true || view.url?.contains("tiktok.com") == true
            val wantsDesktop = isDesktopMode && !isMobileFriendly
            val isCurrentlyDesktop = view.settings.userAgentString.contains("Windows NT")
            if (wantsDesktop != isCurrentlyDesktop) {
                if (wantsDesktop) {
                    view.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"
                } else {
                    view.settings.userAgentString = WebSettings.getDefaultUserAgent(view.context)
                }
                view.reload()
            }
        }
    }
    
    fun goBack(): Boolean {
        val wv = getActiveWebView()
        return if (wv?.canGoBack() == true) {
            wv.goBack()
            true
        } else false
    }
}

data class WebTab(val id: String, val url: String)



@android.annotation.SuppressLint("NewApi")
fun Modifier.vrLensDistortion(distortion: Float): Modifier = this.then(
    if (android.os.Build.VERSION.SDK_INT >= 33 && distortion > 0f) {
        androidx.compose.ui.Modifier.graphicsLayer {
            val shader = android.graphics.RuntimeShader("""
                uniform float2 resolution;
                uniform float distortion;
                uniform shader composable;
                
                half4 main(float2 fragCoord) {
                    float halfWidth = resolution.x * 0.5;
                    float isRight = step(halfWidth, fragCoord.x);
                    float offsetX = isRight * halfWidth;
                    
                    float2 uv = float2(fragCoord.x - offsetX, fragCoord.y) / float2(halfWidth, resolution.y);
                    
                    float2 centered = uv - 0.5;
                    float r2 = dot(centered, centered);
                    float2 distorted = centered * (1.0 + distortion * r2);
                    
                    float2 outUv = distorted + 0.5;
                    if (outUv.x < 0.0 || outUv.x > 1.0 || outUv.y < 0.0 || outUv.y > 1.0) {
                        return half4(0.0, 0.0, 0.0, 1.0);
                    }
                    
                    float2 screenUv = float2(outUv.x * halfWidth + offsetX, outUv.y * resolution.y);
                    return composable.eval(screenUv);
                }
            """)
            shader.setFloatUniform("resolution", size.width, size.height)
            shader.setFloatUniform("distortion", distortion)
            renderEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "composable").asComposeRenderEffect()
        }
    } else {
        androidx.compose.ui.Modifier
    }
)


@Composable
fun CameraPassthroughLayer(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) }

    val standardLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        hasPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasPermission) {
            standardLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    if (hasPermission) {
        DisposableEffect(lifecycleOwner) {
            onDispose {
                val cameraProviderFuture = androidx.camera.lifecycle.ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    cameraProvider.unbindAll()
                }, androidx.core.content.ContextCompat.getMainExecutor(context))
            }
        }
        AndroidView(
            modifier = modifier.fillMaxSize(),
            factory = { ctx ->
                androidx.camera.view.PreviewView(ctx).apply {
                    implementationMode = androidx.camera.view.PreviewView.ImplementationMode.COMPATIBLE
                    scaleType = androidx.camera.view.PreviewView.ScaleType.FILL_CENTER
                    val cameraProviderFuture = androidx.camera.lifecycle.ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()
                        val preview = androidx.camera.core.Preview.Builder().build().also {
                            it.setSurfaceProvider(this.surfaceProvider)
                        }
                        val cameraSelector = androidx.camera.core.CameraSelector.DEFAULT_BACK_CAMERA
                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview)
                        } catch(exc: Exception) {}
                    }, androidx.core.content.ContextCompat.getMainExecutor(ctx))
                }
            }
        )
    } else {
        androidx.compose.foundation.layout.Box(modifier = modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Text("Camera Permission Required", color = Color.White)
        }
    }
}


@Composable
fun VrSplitScreenWrapper(
    isRightHandMode: Boolean,
    ipd: Float,
    gyroYawOffset: Float,
    gyroPitchOffset: Float,
    verticalShift: Float,
    lensWrapping: Boolean,
    lensDistortion: Float,
    eyeWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(modifier = modifier.fillMaxSize().vrLensDistortion(if (lensWrapping) lensDistortion else 0f)) {
        Box(
            modifier = Modifier
                .align(if (isRightHandMode) Alignment.CenterEnd else Alignment.CenterStart)
                .width(eyeWidth)
                .fillMaxHeight()
                .drawWithContent {
                    // 1. Draw Active Eye
                    drawContext.canvas.save()
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height)
                    val activeEyeIpdOffset = if (isRightHandMode) ipd else -ipd
                    drawContext.canvas.translate(activeEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset)
                    drawContent()
                    drawContext.canvas.restore()

                    // 2. Draw Mirror Eye
                    drawContext.canvas.save()
                    val baseDistance = if (isRightHandMode) -size.width else size.width
                    drawContext.canvas.translate(baseDistance, 0f) // Shift canvas to the physical location of the other eye
                    drawContext.canvas.clipRect(0f, 0f, size.width, size.height) // Clip it to that physical location
                    val mirrorEyeIpdOffset = if (isRightHandMode) -ipd else ipd
                    drawContext.canvas.translate(mirrorEyeIpdOffset + gyroYawOffset, verticalShift + gyroPitchOffset) // Shift the content inside the clip
                    drawContent()
                    drawContext.canvas.restore()
                }
        ) {
            content()
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    androidx.compose.foundation.layout.Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(
                width = 1.dp,
                color = Color.Gray.copy(alpha = 0.5f),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
            )
            .padding(8.dp)
    ) {
        androidx.compose.material3.Text(
            text = title,
            color = Color.Cyan,
            style = MaterialTheme.typography.titleSmall,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        content()
    }
}

@Composable
fun NewTabPage(
    isPassthroughEnabled: Boolean,
    shortcuts: List<Pair<String, String>>,
    onSearch: (String) -> Unit
) {
    var searchInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isPassthroughEnabled) Color.Transparent else Color.Black),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.layout.Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp).widthIn(max = 600.dp)
        ) {
            Text(
                "VR Browser", 
                color = Color.White, 
                style = MaterialTheme.typography.headlineLarge,
                modifier = Modifier.padding(bottom = 32.dp)
            )
            
            // Search Box
            TextField(
                value = searchInput,
                onValueChange = { searchInput = it },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                placeholder = { Text("Search or type URL", color = Color.Gray) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedTextColor = Color.Black,
                    unfocusedTextColor = Color.Black,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { onSearch(searchInput) })
            )
            
            Spacer(modifier = Modifier.height(48.dp))
            
            // Shortcuts
            androidx.compose.foundation.lazy.LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
            ) {
                items(shortcuts) { shortcut ->
                    ShortcutIcon(shortcut.first, Icons.Default.Public, Color.Blue) { onSearch(shortcut.second) }
                }
            }
        }
    }
}

@Composable
fun ShortcutIcon(name: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, onClick: () -> Unit) {
    androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.material3.FloatingActionButton(
            onClick = onClick,
            containerColor = Color.White,
            contentColor = color,
            modifier = Modifier.size(64.dp)
        ) {
            Icon(icon, contentDescription = name, modifier = Modifier.size(32.dp))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(name, color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}
