import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                override fun getDefaultVideoPoster(): android.graphics.Bitmap? {
                    return android.graphics.Bitmap.createBitmap(1, 1, android.graphics.Bitmap.Config.ARGB_8888)
                }"""

replace = """                override fun getDefaultVideoPoster(): android.graphics.Bitmap? {
                    return android.graphics.Bitmap.createBitmap(50, 50, android.graphics.Bitmap.Config.ARGB_8888).apply {
                        eraseColor(android.graphics.Color.TRANSPARENT)
                    }
                }"""
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
