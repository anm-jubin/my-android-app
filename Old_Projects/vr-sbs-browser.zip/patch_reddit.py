import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Remove Insta fix
target_insta = """                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        view.evaluateJavascript(
                            "var style = document.createElement('style'); " +
                            "style.innerHTML = 'body, #react-root, main { max-width: 500px !important; margin: 0 auto !important; overflow-x: hidden !important; } video { object-fit: contain !important; }'; " +
                            "if (!document.getElementById('vr-custom-style')) { style.id = 'vr-custom-style'; document.head.appendChild(style); }", null
                        )
                    }"""
content = content.replace(target_insta, "")

# 2. Update UA in settings initialization
target_ua1 = 'userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context)'
replace_ua1 = 'userAgentString = if (isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(context).replace("; wv", "").replace("Version/4.0 ", "")'
content = content.replace(target_ua1, replace_ua1)

# 3. Update UA in shouldOverrideUrlLoading
target_ua2 = 'it.settings.userAgentString = if (this@BrowserManager.isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context)'
replace_ua2 = 'it.settings.userAgentString = if (this@BrowserManager.isDesktopMode) "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(it.context).replace("; wv", "").replace("Version/4.0 ", "")'
content = content.replace(target_ua2, replace_ua2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
