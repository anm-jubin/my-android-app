import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    fun updateIncognitoMode(incognito: Boolean) {
        val didChange = isIncognito != incognito
        isIncognito = incognito
        """
replace = """    fun clearIncognitoData() {
        if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.MULTI_PROFILE)) {
            val profileStore = androidx.webkit.ProfileStore.getInstance()
            profileStore.deleteProfile("incognito")
        }
    }

    fun updateIncognitoMode(incognito: Boolean) {
        val didChange = isIncognito != incognito
        isIncognito = incognito
        """
content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
