import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                override fun getDefaultVideoPoster(): android.graphics.Bitmap? {
                    return android.graphics.Bitmap.createBitmap(50, 50, android.graphics.Bitmap.Config.ARGB_8888).apply {
                        eraseColor(android.graphics.Color.TRANSPARENT)
                    }
                }
            }"""

replace = """                override fun getDefaultVideoPoster(): android.graphics.Bitmap? {
                    return android.graphics.Bitmap.createBitmap(50, 50, android.graphics.Bitmap.Config.ARGB_8888).apply {
                        eraseColor(android.graphics.Color.TRANSPARENT)
                    }
                }
                
                override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                    request.grant(request.resources)
                }
            }"""
content = content.replace(target, replace)

target2 = """            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW"""

replace2 = """            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                allowFileAccess = true
                allowContentAccess = true
                setSupportMultipleWindows(true)
                javaScriptCanOpenWindowsAutomatically = true"""

content = content.replace(target2, replace2)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
