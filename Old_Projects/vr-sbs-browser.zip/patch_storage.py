import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = !this@BrowserManager.isIncognito
                databaseEnabled = !this@BrowserManager.isIncognito
                mediaPlaybackRequiresUserGesture = false"""

replace = """            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
