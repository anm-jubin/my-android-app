import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }"""

replace = """                override fun onPageFinished(view: WebView, url: String) {
                    if (this@BrowserManager.isPassthroughEnabled) {
                        view.evaluateJavascript("document.body.style.backgroundColor = 'transparent'; document.documentElement.style.backgroundColor = 'transparent';", null)
                    }
                    
                    if (url.contains("instagram.com") || url.contains("tiktok.com")) {
                        view.evaluateJavascript(
                            "var style = document.createElement('style'); " +
                            "style.innerHTML = 'body { max-width: 500px !important; margin: 0 auto !important; overflow-x: hidden !important; } video { object-fit: contain !important; }'; " +
                            "document.head.appendChild(style);", null
                        )
                    }"""

content = content.replace(target, replace)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
